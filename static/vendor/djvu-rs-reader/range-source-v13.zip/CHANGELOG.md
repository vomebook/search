# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.43.0](https://github.com/matyushkin/djvu-rs/compare/v0.42.0...v0.43.0) (2026-10-16)


### Features

* **npm:** ship THIRD_PARTY_NOTICES for crates linked into the .wasm ([#950](https://github.com/matyushkin/djvu-rs/issues/950)) ([208d9b2](https://github.com/matyushkin/djvu-rs/commit/208d9b259698755e3669bc6d1a65f10cde7e7aeb))


### Bug Fixes

* **deps:** bump zip 2 -&gt; 9; every zip 2.x release is yanked, so fresh ([208d9b2](https://github.com/matyushkin/djvu-rs/commit/208d9b259698755e3669bc6d1a65f10cde7e7aeb))

## [0.42.0](https://github.com/matyushkin/djvu-rs/compare/v0.41.0...v0.42.0) (2026-10-09)


### Bug Fixes

* **npm:** export WasmRenderRequest, ship lazy Range loaders, npm-specific README ([#945](https://github.com/matyushkin/djvu-rs/issues/945)) ([45175c7](https://github.com/matyushkin/djvu-rs/commit/45175c7b9aea7f92d5f06e09f905820ff89f86a3))


### Performance Improvements

* **bzz:** use the inlined ZP bit coder in the BZZ encoder ([#938](https://github.com/matyushkin/djvu-rs/issues/938)) ([51cbe70](https://github.com/matyushkin/djvu-rs/commit/51cbe700a2af84c138a8c0ffa0d6ba858d4447d0))
* **iw44:** convert colour to YCbCr a row at a time in the encoder ([#935](https://github.com/matyushkin/djvu-rs/issues/935)) ([7461e8a](https://github.com/matyushkin/djvu-rs/commit/7461e8a5b92152101ac38ca80b383fd21dd2407f))
* **iw44:** inline the ZP bit coder in the encoder's coefficient passes ([#937](https://github.com/matyushkin/djvu-rs/issues/937)) ([186a385](https://github.com/matyushkin/djvu-rs/commit/186a3850760516d72dad4d7d850f8cc43ea49b7e))
* **iw44:** scatter encoder blocks into zigzag order with NEON transposes ([#939](https://github.com/matyushkin/djvu-rs/issues/939)) ([fe16571](https://github.com/matyushkin/djvu-rs/commit/fe16571da3b1b4c545418b0bc9cbbcae50a17cdb))
* **zp:** emit the encoder's shift bits in one step ([#933](https://github.com/matyushkin/djvu-rs/issues/933)) ([553d03e](https://github.com/matyushkin/djvu-rs/commit/553d03e79d70192bbf6a3bf99be70f5135dc73b1))


### Documentation

* slim README to a task-first landing page ([#942](https://github.com/matyushkin/djvu-rs/issues/942)) ([2ef05f5](https://github.com/matyushkin/djvu-rs/commit/2ef05f570f1316454c1284b74474e5bc6b4f63a7))
* **packaging:** describe the npm README, wasm-lazy default, export check ([#946](https://github.com/matyushkin/djvu-rs/issues/946)) ([8d2a83b](https://github.com/matyushkin/djvu-rs/commit/8d2a83b63631bc6fe958948ea1595ac1d1f61339))
* **py:** slim djvu-py README to a task-first landing page ([#943](https://github.com/matyushkin/djvu-rs/issues/943)) ([e460771](https://github.com/matyushkin/djvu-rs/commit/e4607712cf2430791c7d6331219bb613beb26e7f))

## [0.41.0](https://github.com/matyushkin/djvu-rs/compare/v0.40.3...v0.41.0) (2026-10-05)


### Features

* **scorecard:** compare IW44 with c44 at an equal slice count ([#926](https://github.com/matyushkin/djvu-rs/issues/926)) ([2bfeba5](https://github.com/matyushkin/djvu-rs/commit/2bfeba5e09ab139e31721c08ff7421ce5897e4f9))


### Performance Improvements

* **iw44:** remove a store-forwarding stall in the decoder's row pass ([#930](https://github.com/matyushkin/djvu-rs/issues/930)) ([4536b6c](https://github.com/matyushkin/djvu-rs/commit/4536b6ceb2a513af74e6f0aadb311cc75bc0792f))
* **iw44:** skip quiet blocks in the encoder's slice passes ([#928](https://github.com/matyushkin/djvu-rs/issues/928)) ([4e56bc4](https://github.com/matyushkin/djvu-rs/commit/4e56bc420a40e5086188ba215ac8ff5e90a4f188))
* **iw44:** speed up the encoder's forward wavelet with NEON ([#929](https://github.com/matyushkin/djvu-rs/issues/929)) ([f740368](https://github.com/matyushkin/djvu-rs/commit/f74036853583be1fb7230b11cf6ef9b5b46b1c35))

## [0.40.3](https://github.com/matyushkin/djvu-rs/compare/v0.40.2...v0.40.3) (2026-10-04)


### Performance Improvements

* **iw44:** gather each encoder plane in its own memory ([#919](https://github.com/matyushkin/djvu-rs/issues/919)) ([a924890](https://github.com/matyushkin/djvu-rs/commit/a924890dc7cf86c6ff85021de7e1cf393963c7db))
* **jb2:** code white runs of direct tiles in one ZP call ([#921](https://github.com/matyushkin/djvu-rs/issues/921)) ([4ce7059](https://github.com/matyushkin/djvu-rs/commit/4ce70598439dd671e0d4edf194dc1303e6430109))
* **jb2:** find connected components on packed bits ([#922](https://github.com/matyushkin/djvu-rs/issues/922)) ([659438f](https://github.com/matyushkin/djvu-rs/commit/659438f35507bc18cffec9a453cb63bda3e113f9))
* **jb2:** keep dictionary rows as words for the refinement search ([#923](https://github.com/matyushkin/djvu-rs/issues/923)) ([9214f92](https://github.com/matyushkin/djvu-rs/commit/9214f9244204c9758dfae20000380bff46dde1f5))
* **jb2:** reject refinement candidates by a centre-aligned ink grid ([#924](https://github.com/matyushkin/djvu-rs/issues/924)) ([cdfdd3d](https://github.com/matyushkin/djvu-rs/commit/cdfdd3d5f6b562ec864d14590c876a891a1e4492))

## [0.40.2](https://github.com/matyushkin/djvu-rs/compare/v0.40.1...v0.40.2) (2026-10-03)


### Bug Fixes

* **bench:** decode the large JB2 page with its shared dictionary ([#906](https://github.com/matyushkin/djvu-rs/issues/906)) ([#908](https://github.com/matyushkin/djvu-rs/issues/908)) ([54fde7c](https://github.com/matyushkin/djvu-rs/commit/54fde7cfbc9a5125fed7bd2ec2d1df47a552ec4e))
* **bench:** make bzz_decode and the large IW44 benches measure real work ([#915](https://github.com/matyushkin/djvu-rs/issues/915)) ([#916](https://github.com/matyushkin/djvu-rs/issues/916)) ([3e64096](https://github.com/matyushkin/djvu-rs/commit/3e640960476a3d1991c3179c3ee2565d66fd5881))

## [0.40.1](https://github.com/matyushkin/djvu-rs/compare/v0.40.0...v0.40.1) (2026-10-02)


### Bug Fixes

* **deps:** tract 0.23 for ocr-onnx; that feature now needs Rust 1.91 ([#897](https://github.com/matyushkin/djvu-rs/issues/897)) ([d5ae893](https://github.com/matyushkin/djvu-rs/commit/d5ae8936cf6347ff8d694f702f095a6ff6d035f1))


### Performance Improvements

* a banded background decodes only the columns a tile reads ([#890](https://github.com/matyushkin/djvu-rs/issues/890)) ([6e9095c](https://github.com/matyushkin/djvu-rs/commit/6e9095cecde542eecd8ad9da1e1ebf50aad0a651))
* a Lanczos-3 region filters only its own window ([#887](https://github.com/matyushkin/djvu-rs/issues/887)) ([1dfbbab](https://github.com/matyushkin/djvu-rs/commit/1dfbbaba36fb4c29d21969c7a1b1571df84892b8))

## [0.40.0](https://github.com/matyushkin/djvu-rs/compare/v0.39.0...v0.40.0) (2026-09-30)


### Features

* one render call in the Python and wasm bindings ([#884](https://github.com/matyushkin/djvu-rs/issues/884)) ([d122a36](https://github.com/matyushkin/djvu-rs/commit/d122a360b7aae14eb939d1c145cbd8bcd43a8cfc))

## [0.39.0](https://github.com/matyushkin/djvu-rs/compare/v0.38.1...v0.39.0) (2026-09-30)


### Features

* deprecate the render_* variants in favour of RenderRequest ([#882](https://github.com/matyushkin/djvu-rs/issues/882)) ([86ea96a](https://github.com/matyushkin/djvu-rs/commit/86ea96af1501d8bb448fdd9235603a21b8082f23))
* one RenderRequest for every render ([#881](https://github.com/matyushkin/djvu-rs/issues/881)) ([f9dd177](https://github.com/matyushkin/djvu-rs/commit/f9dd1774ac4cdb2478768675e7ed85f1ab0b4620))
* tiles support anti-aliasing and Lanczos-3 ([#879](https://github.com/matyushkin/djvu-rs/issues/879)) ([0784912](https://github.com/matyushkin/djvu-rs/commit/0784912f0a37365336da6b9f411b737658ef1dac))

## [0.38.1](https://github.com/matyushkin/djvu-rs/compare/v0.38.0...v0.38.1) (2026-09-30)


### Bug Fixes

* Lanczos-3 fallback no longer halves an anti-aliased render ([#877](https://github.com/matyushkin/djvu-rs/issues/877)) ([cbbaa79](https://github.com/matyushkin/djvu-rs/commit/cbbaa79044d37a7bdfe0b15d539f6fc63f697614))

## [0.38.0](https://github.com/matyushkin/djvu-rs/compare/v0.37.0...v0.38.0) (2026-09-29)


### ⚠ BREAKING CHANGES

* render_region with opts.aa now returns a crop of the anti-aliased page, which is opts.width/2 x opts.height/2; the region addresses that halved page. Before, it returned an unsmoothed crop of the full-size canvas.
* render_into / render_into_with_limits / DjVuPage::render_into return RenderError::UnsupportedOption for options that need a whole pixmap (anti-aliasing, Lanczos-3 at a scaled size, or a combined INFO + user rotation), as render_streaming does, instead of writing an unrotated, unfiltered buffer. Check RenderOptions::can_stream or use render_pixmap. The image-crate DjVuDecoder now decodes in display orientation: its default size and with_size are after the INFO rotation. Anti-aliasing now halves progressive frames, ProgressiveDecoder frames and render_coarse output, and render_coarse applies Lanczos-3.
* `DjvmError::ComponentDescriptorCountMismatch` is removed; no writer can produce it any more. `DjvmStreamWriter::add_component` now ignores the name (0x80) and title (0x40) bits and writes unknown component types as shared (0).
* PDF export of a document with a page that cannot be rendered now returns an error instead of writing a blank page.
* on pages with a non-zero INFO rotation, the (x, y, w, h) arguments of Page::render_region (and Python Page.render_region) address the rotated page, not the unrotated one. Upright pages are unchanged.
* on a page with a 90° or 270° INFO rotation, `RenderOptions::fit_to_width/height/box` set `width`/`height` in the native orientation (sides swapped against the requested display size), `Page::size_at_dpi` and the wasm `width_at`/`height_at` return the display size, and PDF pages carry `/Rotate`. Upright pages are unchanged.
* **mut:** `DjVuDocumentMut::set_metadata`/`remove_metadata` and `PageMut::set_metadata`/`remove_metadata` now return `Result<(), MutError>`. They fail when the existing annotation chunk does not parse (new `MutError::Annotation`), for an indirect DJVM, or for a legacy BM44/PM44 root.

### Features

* **async:** lazy loading for indirect DJVM documents ([#856](https://github.com/matyushkin/djvu-rs/issues/856)) ([af7a850](https://github.com/matyushkin/djvu-rs/commit/af7a850331da1b07c2cf34f4f2259f277644e69a))
* **djvm:** write indirect indexes with shared components ([#857](https://github.com/matyushkin/djvu-rs/issues/857)) ([74a72da](https://github.com/matyushkin/djvu-rs/commit/74a72da5b506b71912f131c88bd4eccbcf13d7c2))
* **jb2:** aligned refinement in bundles, colour masks and chunk_encode ([#859](https://github.com/matyushkin/djvu-rs/issues/859)) ([b166f05](https://github.com/matyushkin/djvu-rs/commit/b166f05e8c3a00874cca336519fdd6eb4c412da0))
* **jb2:** lossless dictionary encoding with center-aligned refinement ([#858](https://github.com/matyushkin/djvu-rs/issues/858)) ([75e6d4b](https://github.com/matyushkin/djvu-rs/commit/75e6d4bf411df63028a3e53f7fdfee6036b9a4a4))
* **mut:** write metadata where DjVuLibre reads it ([#853](https://github.com/matyushkin/djvu-rs/issues/853)) ([7e751a9](https://github.com/matyushkin/djvu-rs/commit/7e751a912d6220ebefb47d488c23c64ecc9d50da))
* **py:** ship type stubs with TypedDict shapes ([#855](https://github.com/matyushkin/djvu-rs/issues/855)) ([1067b8a](https://github.com/matyushkin/djvu-rs/commit/1067b8aeae8d9956d2bb53fbb758d5f6ca91e926))
* **wasm:** lazy indirect DJVM documents in the browser ([#862](https://github.com/matyushkin/djvu-rs/issues/862)) ([658d56f](https://github.com/matyushkin/djvu-rs/commit/658d56fa0b504135867d6ee620c27d24b2de05a7))


### Bug Fixes

* bilevel TIFF pages render as they display ([#868](https://github.com/matyushkin/djvu-rs/issues/868)) ([737bc7c](https://github.com/matyushkin/djvu-rs/commit/737bc7cc1e15b3530fd6a51e51d5946d27adee49))
* clear wasm32 clippy drop_non_drop lints ([#863](https://github.com/matyushkin/djvu-rs/issues/863)) ([25d3e8a](https://github.com/matyushkin/djvu-rs/commit/25d3e8a47f89b9d8946e67e647f9a5bca69c4968))
* **jb2:** decode our own output up to the 64 MP page limit ([#860](https://github.com/matyushkin/djvu-rs/issues/860)) ([c77d12f](https://github.com/matyushkin/djvu-rs/commit/c77d12f1e4ee3375ec92190685209f86f383aa0e))
* one page-export loop and error policy for every exporter ([#870](https://github.com/matyushkin/djvu-rs/issues/870)) ([6da938d](https://github.com/matyushkin/djvu-rs/commit/6da938daaf9c74f54902f88a7c1c6c8d0ee5afc9))
* one render pipeline behind every render entry point ([#872](https://github.com/matyushkin/djvu-rs/issues/872)) ([bda7813](https://github.com/matyushkin/djvu-rs/commit/bda7813b0eafdb2bd85ac0c9119efc6476a06b0c))
* one render size for rotated pages ([#866](https://github.com/matyushkin/djvu-rs/issues/866)) ([70d393e](https://github.com/matyushkin/djvu-rs/commit/70d393e6446a80004e5f2b0cc77be75bea8b4840))
* one whole-pixmap rule for streaming and the tile cache ([#867](https://github.com/matyushkin/djvu-rs/issues/867)) ([0e3201d](https://github.com/matyushkin/djvu-rs/commit/0e3201d5b30c7e1eec5ad34423d3969a08d17b4a))
* page regions in display coordinates on rotated pages ([#869](https://github.com/matyushkin/djvu-rs/issues/869)) ([2160b1e](https://github.com/matyushkin/djvu-rs/commit/2160b1ef59f794ebe4a96925d88db3769a3515c5))
* parallel exports report the first failing page ([#874](https://github.com/matyushkin/djvu-rs/issues/874)) ([c496fea](https://github.com/matyushkin/djvu-rs/commit/c496fea8af60785ecdf2f53fcd28287e66b43d68))
* region renders honor anti-aliasing and Lanczos-3 ([#875](https://github.com/matyushkin/djvu-rs/issues/875)) ([b58d9ad](https://github.com/matyushkin/djvu-rs/commit/b58d9ad26f60be4efb4fde6dd3df0c5fff3e6341))


### Performance Improvements

* keep the bilinear row loop out of composite_into ([#873](https://github.com/matyushkin/djvu-rs/issues/873)) ([c79c5ee](https://github.com/matyushkin/djvu-rs/commit/c79c5eee9807e1a7cdf007cb2a20bb662ea62fc8))


### Code Refactoring

* one DIRM component table for every bundle writer ([#871](https://github.com/matyushkin/djvu-rs/issues/871)) ([f4dd12c](https://github.com/matyushkin/djvu-rs/commit/f4dd12c09afc0bb07b9cde0ecf23e7ed5fbca55f))

## [0.37.0](https://github.com/matyushkin/djvu-rs/compare/v0.36.0...v0.37.0) (2026-09-27)


### Features

* **py:** edit annotations, text layers, metadata and bookmarks ([#851](https://github.com/matyushkin/djvu-rs/issues/851)) ([2af3b34](https://github.com/matyushkin/djvu-rs/commit/2af3b341d83f98a74178c13284c8b21fb526df59))


### Bug Fixes

* **mut:** keep NAVM directly after DIRM when writing metadata ([#850](https://github.com/matyushkin/djvu-rs/issues/850)) ([e0b1a92](https://github.com/matyushkin/djvu-rs/commit/e0b1a92b32d03fc240062048177bd2b831b0ecbc))

## [0.36.0](https://github.com/matyushkin/djvu-rs/compare/v0.35.2...v0.36.0) (2026-09-25)


### ⚠ BREAKING CHANGES

* **annotation:** `MapArea` has new public fields `target` and `extra`, and `Annotation` has a new public field `extra`; struct literals must set them. `Border::style` now holds the DjVuLibre option without parentheses (for example `xor`, `border #FF0000`, `shadow_in 4`) and is encoded as `(<style>)`.

### Features

* **annotation:** keep every annotation form DjVuLibre writes ([#843](https://github.com/matyushkin/djvu-rs/issues/843)) ([c0e3efb](https://github.com/matyushkin/djvu-rs/commit/c0e3efbdc42456cd2dfd80cb8d662246957b4521))


### Bug Fixes

* **djvm:** treat legacy FORM:BM44/PM44 image files as pages ([#845](https://github.com/matyushkin/djvu-rs/issues/845)) ([523454f](https://github.com/matyushkin/djvu-rs/commit/523454fa49f71839cee8240c22b86a9f110c0869))

## [0.35.2](https://github.com/matyushkin/djvu-rs/compare/v0.35.1...v0.35.2) (2026-09-24)


### Bug Fixes

* **dirm:** read the shared annotation like DjVuLibre ([#833](https://github.com/matyushkin/djvu-rs/issues/833)) ([#837](https://github.com/matyushkin/djvu-rs/issues/837)) ([25f74c0](https://github.com/matyushkin/djvu-rs/commit/25f74c059ab22f5a7edf8dec622cb071b998077a))
* **djvm:** keep component ids, INCL targets and DIRM types in merge and split ([#841](https://github.com/matyushkin/djvu-rs/issues/841)) ([7b0a2d5](https://github.com/matyushkin/djvu-rs/commit/7b0a2d55204bfc71a417269d9c95a28677e5c405))
* **mut:** update the DIRM size table when a bundled edit resizes a component ([#840](https://github.com/matyushkin/djvu-rs/issues/840)) ([6387a79](https://github.com/matyushkin/djvu-rs/commit/6387a790de995837b8506e8cbad91d96a76dd26e))
* **text:** decode sibling zones against the previous sibling, write version 1 ([#839](https://github.com/matyushkin/djvu-rs/issues/839)) ([a823717](https://github.com/matyushkin/djvu-rs/commit/a8237174c26afb29cbacf76176194af8c37c0ccf))

## [0.35.1](https://github.com/matyushkin/djvu-rs/compare/v0.35.0...v0.35.1) (2026-09-24)


### Bug Fixes

* **iw44:** honour crcb_half like DjVuLibre ([#830](https://github.com/matyushkin/djvu-rs/issues/830)) ([#832](https://github.com/matyushkin/djvu-rs/issues/832)) ([279dad0](https://github.com/matyushkin/djvu-rs/commit/279dad09ad0498a3c6849dddd7693f43daf6525d))
* **iw44:** match DjVuLibre inverse transform on small planes ([#827](https://github.com/matyushkin/djvu-rs/issues/827)) ([#828](https://github.com/matyushkin/djvu-rs/issues/828)) ([75a1fb9](https://github.com/matyushkin/djvu-rs/commit/75a1fb92aced2d59417ddfe737eb0f18208323db))
* **render:** match DjVuLibre's native BG/FG44 upscale ([#831](https://github.com/matyushkin/djvu-rs/issues/831)) ([#834](https://github.com/matyushkin/djvu-rs/issues/834)) ([d2d0496](https://github.com/matyushkin/djvu-rs/commit/d2d049618d02d6ed46ace017dd9c948f9ccf80da))

## [0.35.0](https://github.com/matyushkin/djvu-rs/compare/v0.34.0...v0.35.0) (2026-09-22)


### Features

* **optimizer:** target-size search ([#814](https://github.com/matyushkin/djvu-rs/issues/814)) ([#825](https://github.com/matyushkin/djvu-rs/issues/825)) ([027279f](https://github.com/matyushkin/djvu-rs/commit/027279fe1a87649f15461abbc3d4f1c84659d169))

## [0.34.0](https://github.com/matyushkin/djvu-rs/compare/v0.33.0...v0.34.0) (2026-09-22)


### ⚠ BREAKING CHANGES

* **optimizer:** `OptimizationRequest`, `RewriteAction`, `RewrittenComponent`, `OptimizationPlan` and `OptimizationReport` are now `#[non_exhaustive]`. `RewriteAction` gains `ReencodeBackground` and `ReencodeMask`; `RewrittenComponent` gains `quality: Option<ComponentQuality>` and drops `Eq`; `OptimizationPlan` and `OptimizationReport` gain `min_ssim: Option<f64>`; `OptimizationRequest` gains `lossy_text` (`with_lossy_text`). Match arms on `RewriteAction` need a wildcard; struct literals must go through the constructors. JSON adds `"quality"` per component and `"min_ssim"` at the top level. Recorded in docs/api-compatibility.md §2.

### Features

* **optimizer:** cooperative cancellation between components ([#814](https://github.com/matyushkin/djvu-rs/issues/814)) ([#823](https://github.com/matyushkin/djvu-rs/issues/823)) ([47156ff](https://github.com/matyushkin/djvu-rs/commit/47156ff026d4b95a7a58aec3b3baf2deac5bc6b5))
* **optimizer:** quality-aware archival re-encode ([#814](https://github.com/matyushkin/djvu-rs/issues/814)) ([#824](https://github.com/matyushkin/djvu-rs/issues/824)) ([7944c8a](https://github.com/matyushkin/djvu-rs/commit/7944c8a231e66f7b963892abef646a6bb5b4784e))
* **optimizer:** report progress per component and phase ([#814](https://github.com/matyushkin/djvu-rs/issues/814)) ([#822](https://github.com/matyushkin/djvu-rs/issues/822)) ([db0ffcc](https://github.com/matyushkin/djvu-rs/commit/db0ffcce39e39c0cbd24feda6ef56b8e2f06f02c))
* **pixmap:** add fallible Pixmap::try_new, deprecate new ([#815](https://github.com/matyushkin/djvu-rs/issues/815)) ([#821](https://github.com/matyushkin/djvu-rs/issues/821)) ([aa043be](https://github.com/matyushkin/djvu-rs/commit/aa043beb419b63804f3e811431619c8a501ca479))


### Performance Improvements

* **encode:** transform large pages in bands ([#812](https://github.com/matyushkin/djvu-rs/issues/812)) ([#818](https://github.com/matyushkin/djvu-rs/issues/818)) ([bee8539](https://github.com/matyushkin/djvu-rs/commit/bee8539201a79fcad9cc27f0c95c4dbdc0a48189))
* **render-cache:** evict per layer, not per page ([#813](https://github.com/matyushkin/djvu-rs/issues/813)) ([#820](https://github.com/matyushkin/djvu-rs/issues/820)) ([42749b4](https://github.com/matyushkin/djvu-rs/commit/42749b4fadbd1d3df813f495cc40ba4cd2d70206))
* **render:** composite large backgrounds in bands ([#811](https://github.com/matyushkin/djvu-rs/issues/811)) ([#817](https://github.com/matyushkin/djvu-rs/issues/817)) ([8bf8436](https://github.com/matyushkin/djvu-rs/commit/8bf8436763aeac1483f2c88c2472e0cbe296da62))

## [0.33.0](https://github.com/matyushkin/djvu-rs/compare/v0.32.1...v0.33.0) (2026-09-16)


### ⚠ BREAKING CHANGES

* **render:** `DjVuPage::decoded_bg44`, `decoded_bg44_partial`, `decoded_mask` and `decoded_fg44` return `Option<Arc<T>>` instead of `Option<&T>`. `Arc<T>` derefs to `T`, so most call sites are unchanged. Six eviction methods relax `&mut self` to `&self`, which only admits more callers. Recorded in docs/api-compatibility.md §2 and §7.

### Features

* **python:** export documents to PDF, EPUB, CBZ and TIFF ([#809](https://github.com/matyushkin/djvu-rs/issues/809)) ([bffcf36](https://github.com/matyushkin/djvu-rs/commit/bffcf36e27bb575503f10f9227447057bf496007))
* **render:** bound the page render caches by default ([#807](https://github.com/matyushkin/djvu-rs/issues/807)) ([a031d32](https://github.com/matyushkin/djvu-rs/commit/a031d32a8a2dec6e09f04f7264ab8cb0272bff2f))


### Performance Improvements

* **decode:** reconstruct large IW44 planes in bands ([#808](https://github.com/matyushkin/djvu-rs/issues/808)) ([b921a81](https://github.com/matyushkin/djvu-rs/commit/b921a8184860c3a57247e960dc793c550f504a02))

## [0.32.1](https://github.com/matyushkin/djvu-rs/compare/v0.32.0...v0.32.1) (2026-09-10)


### Bug Fixes

* **render:** count IW44 chroma planes in the render-cache budget ([#799](https://github.com/matyushkin/djvu-rs/issues/799)) ([0d4748d](https://github.com/matyushkin/djvu-rs/commit/0d4748db092b71718d4453e48d939a2e6a581a88))
* **render:** keep the 1:1 bilevel fast path inside the mask ([#805](https://github.com/matyushkin/djvu-rs/issues/805)) ([2bba3c8](https://github.com/matyushkin/djvu-rs/commit/2bba3c88501d8ef8054c84cb05b03c51ee5f40c2))


### Performance Improvements

* **decode:** keep only the non-zero buckets of an IW44 block ([#803](https://github.com/matyushkin/djvu-rs/issues/803)) ([558e2fe](https://github.com/matyushkin/djvu-rs/commit/558e2fe39ca8fa6d0a904c13468f44aeeb90e2f7))
* **encode:** narrow and sparsify PlaneEncoder::recon ([#804](https://github.com/matyushkin/djvu-rs/issues/804)) ([f622725](https://github.com/matyushkin/djvu-rs/commit/f6227251fa2bae8463ff45983267b2d9bf11a945))
* **render:** stop thumbnails from retaining a full-size page decode ([#802](https://github.com/matyushkin/djvu-rs/issues/802)) ([92dc1c4](https://github.com/matyushkin/djvu-rs/commit/92dc1c40eb99ca245744fc4584a82e483fcb3d11))

## [0.32.0](https://github.com/matyushkin/djvu-rs/compare/v0.31.0...v0.32.0) (2026-09-07)


### ⚠ BREAKING CHANGES

* **api:** every public error enum is now #[non_exhaustive]. Downstream code that matches on one exhaustively must add a `_` arm. Variant names, their payloads, and every Display/Error impl are unchanged.

### Features

* **api:** mark every public error enum #[non_exhaustive] ([#796](https://github.com/matyushkin/djvu-rs/issues/796)) ([a9edf57](https://github.com/matyushkin/djvu-rs/commit/a9edf571594364419d912fffbd2c7b1f5a995953))

## [0.31.0](https://github.com/matyushkin/djvu-rs/compare/v0.30.2...v0.31.0) (2026-09-06)


### ⚠ BREAKING CHANGES

* **encode:** EncodeError is now #[non_exhaustive]; downstream matches need a _ arm. It also gained the PageSource variant.

### Features

* **encode:** per-page mask reuse on the multi-page bundle path ([#779](https://github.com/matyushkin/djvu-rs/issues/779) follow-up) ([#784](https://github.com/matyushkin/djvu-rs/issues/784)) ([50f71cd](https://github.com/matyushkin/djvu-rs/commit/50f71cdfcf377cfd9d8bbeabf70c11f61f09bdad))
* **encode:** reuse an existing Sjbz mask on re-encode ([#601](https://github.com/matyushkin/djvu-rs/issues/601) follow-up) ([#779](https://github.com/matyushkin/djvu-rs/issues/779)) ([8696f72](https://github.com/matyushkin/djvu-rs/commit/8696f72a4cf1d4984f11a17bec6efcd3e827b6da))


### Performance Improvements

* **encode:** bounded-window streaming entry point (encoder peak-memory step 4) ([#793](https://github.com/matyushkin/djvu-rs/issues/793)) ([910641f](https://github.com/matyushkin/djvu-rs/commit/910641f8e3b2adee674a55003c9fc5c10c59b2d2))
* **encode:** commit the peak-RSS scaling harness (encoder peak-memory step 1) ([#786](https://github.com/matyushkin/djvu-rs/issues/786)) ([e5ad127](https://github.com/matyushkin/djvu-rs/commit/e5ad127d6d1e2d020fad686bddf392ca541e010f))
* **encode:** precompute the per-CC colour table in phase 1 (encoder peak-memory step 3) ([#792](https://github.com/matyushkin/djvu-rs/issues/792)) ([c100fc8](https://github.com/matyushkin/djvu-rs/commit/c100fc802b067f444a82c5face4449cf2c3f85dc))
* **encode:** stream pages in the CLI encoder (encoder peak-memory step 5) ([#794](https://github.com/matyushkin/djvu-rs/issues/794)) ([9b1c782](https://github.com/matyushkin/djvu-rs/commit/9b1c782e36c1bc551ab2fa01d6228ce532082810))
* **segment:** inline derive_background to restore pre-split codegen ([#782](https://github.com/matyushkin/djvu-rs/issues/782)) ([bf39d5b](https://github.com/matyushkin/djvu-rs/commit/bf39d5ba7a9b1a27bde6d84fccee26a703d81a24))
* **thumbnail:** skip full-res extract_mask on the thumbnail path (round 89 follow-up) ([#785](https://github.com/matyushkin/djvu-rs/issues/785)) ([117c3e5](https://github.com/matyushkin/djvu-rs/commit/117c3e577e7e5d659625671dfb6074d6a0df530c))

## [0.30.2](https://github.com/matyushkin/djvu-rs/compare/v0.30.1...v0.30.2) (2026-08-31)


### Performance Improvements

* **render:** separable bilinear bg resampling with per-column table ([#775](https://github.com/matyushkin/djvu-rs/issues/775)) ([15f3270](https://github.com/matyushkin/djvu-rs/commit/15f327081b68c46c516fc5189449a787b92c9ebd))

## [0.30.1](https://github.com/matyushkin/djvu-rs/compare/v0.30.0...v0.30.1) (2026-08-22)


### Performance Improvements

* migrate constant-size chunks_exact(N) to as_chunks ([#768](https://github.com/matyushkin/djvu-rs/issues/768)) ([#770](https://github.com/matyushkin/djvu-rs/issues/770)) ([41f3b1a](https://github.com/matyushkin/djvu-rs/commit/41f3b1a83c610b8e655c8d78f266ab20c2b1d4a9))

## [0.30.0](https://github.com/matyushkin/djvu-rs/compare/v0.29.0...v0.30.0) (2026-08-18)


### Features

* **ingest:** apply JPEG EXIF orientation exactly once at ingest ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#763](https://github.com/matyushkin/djvu-rs/issues/763)) ([70908a4](https://github.com/matyushkin/djvu-rs/commit/70908a499184de90537b8151cf9d7e602c70ebeb))
* **ingest:** apply TIFF Orientation tag exactly once at ingest ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#760](https://github.com/matyushkin/djvu-rs/issues/760)) ([bf20e3b](https://github.com/matyushkin/djvu-rs/commit/bf20e3b5e28f861a2f772cebc47ce558812cfdf0))
* **ingest:** configurable alpha compositing via encode --background ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#764](https://github.com/matyushkin/djvu-rs/issues/764)) ([0abae18](https://github.com/matyushkin/djvu-rs/commit/0abae18d5b0ea32f3e3855369ab07b6db2694159))
* **ingest:** explicit ICC profile policy via encode --icc ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#765](https://github.com/matyushkin/djvu-rs/issues/765)) ([0e56250](https://github.com/matyushkin/djvu-rs/commit/0e5625060b6ef4a9348870ae414dadc49cfe1e5e))

## [0.29.0](https://github.com/matyushkin/djvu-rs/compare/v0.28.0...v0.29.0) (2026-08-18)


### Features

* **ingest:** decode CCITT G4 and PackBits TIFF strips ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#756](https://github.com/matyushkin/djvu-rs/issues/756)) ([fdd6064](https://github.com/matyushkin/djvu-rs/commit/fdd606445944a7b33d97d0e799f4f654ef250d98))
* **ingest:** map TIFF X/YResolution tags to default DPI ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#758](https://github.com/matyushkin/djvu-rs/issues/758)) ([5ec6a12](https://github.com/matyushkin/djvu-rs/commit/5ec6a12db4251e567f948a6c9767a5c7704ab8cc))


### Performance Improvements

* **ingest:** bilevel TIFF fast path straight to JB2 masks ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#759](https://github.com/matyushkin/djvu-rs/issues/759)) ([afa2c67](https://github.com/matyushkin/djvu-rs/commit/afa2c67b43155b803ec4fce5bea606622a924054))

## [0.28.0](https://github.com/matyushkin/djvu-rs/compare/v0.27.0...v0.28.0) (2026-08-11)


### Features

* **api-stability:** compatibility policy, feature matrix, and CI gates ([#695](https://github.com/matyushkin/djvu-rs/issues/695)) ([adff9cd](https://github.com/matyushkin/djvu-rs/commit/adff9cd9e1b49fe2b0575bb88d36b0af1ee2c6bc))
* **api:** wire configurable ResourceLimits into parse and render ([#695](https://github.com/matyushkin/djvu-rs/issues/695)) ([cdb8222](https://github.com/matyushkin/djvu-rs/commit/cdb82223e765ba55e9b5d132bad467d99a518147))
* **cli:** add `djvu diff` semantic document comparison ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([616f2fe](https://github.com/matyushkin/djvu-rs/commit/616f2fe00ef3aef74cb7c81702cdd3faacea49c0))
* **cli:** add `djvu diff` semantic document comparison ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([cbed5fc](https://github.com/matyushkin/djvu-rs/commit/cbed5fca4320ac6e993fde9600d41ca1ecf479da))
* **cli:** add `djvu inspect` with offset-aware structural JSON ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([779865c](https://github.com/matyushkin/djvu-rs/commit/779865c7b098de48ffc798a620256a90e61b22b6))
* **cli:** add `djvu inspect` with offset-aware structural JSON ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([31e5296](https://github.com/matyushkin/djvu-rs/commit/31e5296cb7456690236eebc5893730defdcffcb7))
* **cli:** layered `djvu validate` with structural/dependency/codec findings ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([583f66a](https://github.com/matyushkin/djvu-rs/commit/583f66ab0fe4edce7068f7b42d566e51f73c4629))
* **cli:** layered `djvu validate` with structural/dependency/codec findings ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([97f4c92](https://github.com/matyushkin/djvu-rs/commit/97f4c92a54f55f6c7dab8dd9200ea4a7ca4ea4dd))
* **djvm:** add bundled -&gt; indirect conversion preserving graph and names ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([d69d680](https://github.com/matyushkin/djvu-rs/commit/d69d6800b4126e11b1e80662f62b2e1c4130ede1))
* **djvm:** add bundled -&gt; indirect conversion preserving graph and names ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([7ab03d2](https://github.com/matyushkin/djvu-rs/commit/7ab03d2863ab8ac9d7ce8fde677ae32e20b57cff))
* **djvm:** bundle single-page extraction with its INCL closure ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([e28795c](https://github.com/matyushkin/djvu-rs/commit/e28795cba705b4418edd82a98f34bbc2ad80754b))
* **djvm:** bundle single-page extraction with its INCL closure ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([777b6cf](https://github.com/matyushkin/djvu-rs/commit/777b6cff2212e4c5ca07d7ec637dc3df40c8c569))
* **djvm:** extract-with-includes uses the component graph closure ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([33d24ad](https://github.com/matyushkin/djvu-rs/commit/33d24ad7362cf73fc0e9c652d06bd29b2ebb2b7d))
* **djvm:** extract-with-includes uses the component graph closure ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([9685512](https://github.com/matyushkin/djvu-rs/commit/96855125a68c5321390342da08fa57804e29d957))
* **djvm:** page deletion with unreachable-component GC policy ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([fee8e06](https://github.com/matyushkin/djvu-rs/commit/fee8e0689a30fbace1b847cc55677191c7e65ba4))
* **djvm:** page deletion with unreachable-component GC policy ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([de8d001](https://github.com/matyushkin/djvu-rs/commit/de8d00133090a3867884a2743742df4961a35277))
* **djvm:** safe byte-exact shared-component deduplication ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([0d0fc92](https://github.com/matyushkin/djvu-rs/commit/0d0fc92ac4ec35068155195be445e3d9af1b9e79))
* **djvm:** safe byte-exact shared-component deduplication ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([a6a99c2](https://github.com/matyushkin/djvu-rs/commit/a6a99c294499e2d9d6eeb2581d1ae67d1e862105))
* **djvm:** spooled streaming bundle writer with bounded memory ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([51a099b](https://github.com/matyushkin/djvu-rs/commit/51a099ba2ac6c4ef7bfbe31a729998a570cef577))
* **djvm:** spooled streaming bundle writer with bounded memory ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([11b6a1e](https://github.com/matyushkin/djvu-rs/commit/11b6a1eeb3dc316853327b8cceb66940db84df7d))
* **document:** add typed indirect component resolver ([a5c2dd1](https://github.com/matyushkin/djvu-rs/commit/a5c2dd11e74e0323778e3400abb1b58eab504b80))
* **document:** add typed indirect component resolver ([#687](https://github.com/matyushkin/djvu-rs/issues/687)) ([781e459](https://github.com/matyushkin/djvu-rs/commit/781e459cffd0ba6572bfc73ebfcd5aa2e4fdb845))
* **document:** add validated component dependency graph ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([4fe8d25](https://github.com/matyushkin/djvu-rs/commit/4fe8d25545c47c6a2cf7dacd912107a044bbc4c2))
* **document:** add validated component dependency graph ([#689](https://github.com/matyushkin/djvu-rs/issues/689)) ([e806d46](https://github.com/matyushkin/djvu-rs/commit/e806d4645d89864e9a974c99fff119560d99da1a))
* **document:** decode legacy FORM:BM44 and FORM:PM44 ([#683](https://github.com/matyushkin/djvu-rs/issues/683)) ([5104fa3](https://github.com/matyushkin/djvu-rs/commit/5104fa35880a73d47a6b479811098695ab4a6f3c))
* **document:** decode legacy FORM:BM44 and FORM:PM44 ([#683](https://github.com/matyushkin/djvu-rs/issues/683)) ([e84ba8e](https://github.com/matyushkin/djvu-rs/commit/e84ba8e7d0bf6213f60d516ca8a8f78f644381b0))
* **editor:** add validated typed edit operations ([1939cca](https://github.com/matyushkin/djvu-rs/commit/1939ccac377ad3a4a4811c632133f3751d4f78f7))
* **editor:** add validated typed edit operations ([#688](https://github.com/matyushkin/djvu-rs/issues/688)) ([9f127c9](https://github.com/matyushkin/djvu-rs/commit/9f127c9e6b86732a563bc6e8357a6d71ddd23651))
* **export:** async writer adapters, injected-failure tests, memory smoke ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([1206492](https://github.com/matyushkin/djvu-rs/commit/120649205511268555697aba475e24714d24012c))
* **export:** async writer adapters, injected-failure tests, memory smoke ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([b064f2b](https://github.com/matyushkin/djvu-rs/commit/b064f2b76de10f8c543fb860324296901952a49a))
* **export:** bound CBZ/EPUB writer memory to active page state ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([e6e7250](https://github.com/matyushkin/djvu-rs/commit/e6e7250f51157b19b0d9af4f5e7d872610a47188))
* **export:** bound CBZ/EPUB writer memory to active page state ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([87d21cc](https://github.com/matyushkin/djvu-rs/commit/87d21cc7e6ffbc9f2822a55110179927faa76cce))
* **export:** uniform progress/cancellation observer and atomic CLI output ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([1c6835c](https://github.com/matyushkin/djvu-rs/commit/1c6835c42c2f59757838bbc6b0d00e99c7644393))
* **export:** uniform progress/cancellation observer and atomic CLI output ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([749a904](https://github.com/matyushkin/djvu-rs/commit/749a9046776a98668358aa0acedcf03b2366492d))
* **ingest:** expand PNG encoder ingestion slice 1 ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([b8e4c0e](https://github.com/matyushkin/djvu-rs/commit/b8e4c0e6f308231d8467a7e86eefae5b3bd23360))
* **ingest:** expand TIFF encoder ingestion slice 2 ([#694](https://github.com/matyushkin/djvu-rs/issues/694)) ([#742](https://github.com/matyushkin/djvu-rs/issues/742)) ([73e1197](https://github.com/matyushkin/djvu-rs/commit/73e1197530209afcf14f989f8624cf32609bc8e8))
* **limits:** configurable ResourceLimits for parse/render ([#695](https://github.com/matyushkin/djvu-rs/issues/695)) ([fc61627](https://github.com/matyushkin/djvu-rs/commit/fc6162738ad7a19aa43b1452e4da3c1daf270765))
* **ocr:** CTC line recognition and TextLayer assembly for the neural pipeline ([#750](https://github.com/matyushkin/djvu-rs/issues/750)) ([beade4c](https://github.com/matyushkin/djvu-rs/commit/beade4c26ce80e53933b1b8d1340fcee2c6ab0f5))
* **ocr:** model manifest with SHA-256 verification + DBNet detection ([#693](https://github.com/matyushkin/djvu-rs/issues/693)) ([#749](https://github.com/matyushkin/djvu-rs/issues/749)) ([2b13106](https://github.com/matyushkin/djvu-rs/commit/2b131064e544cf3a7b5a59c07482a38a525457ef))
* **ocr:** NeuralOcrBackend pipeline wired to CLI as --backend onnx ([#751](https://github.com/matyushkin/djvu-rs/issues/751)) ([bd6e1e6](https://github.com/matyushkin/djvu-rs/commit/bd6e1e644ef58cba05d2b8b2ce1c3f1ac6b7024c))
* **ocr:** synthetic metrics corpus with CER/WER/IoU baseline ([#752](https://github.com/matyushkin/djvu-rs/issues/752)) ([667003e](https://github.com/matyushkin/djvu-rs/commit/667003e2c53e7eab07392bbfc412d77ed26975dc))
* **optimizer:** add lossless cleanup planning ([#686](https://github.com/matyushkin/djvu-rs/issues/686)) ([a332864](https://github.com/matyushkin/djvu-rs/commit/a332864c6c4a8d629c05a9859d930791d4ef7ae8))
* **optimizer:** add lossless cleanup planning ([#686](https://github.com/matyushkin/djvu-rs/issues/686)) ([17b53eb](https://github.com/matyushkin/djvu-rs/commit/17b53ebfde01f8018184c59999844518c530eb70))
* **packaging:** publish Python wheels and npm packages ([#692](https://github.com/matyushkin/djvu-rs/issues/692)) ([adf6cb7](https://github.com/matyushkin/djvu-rs/commit/adf6cb7d98f1568f53a72ba806064afb7fbcf2ff))
* **packaging:** publish Python wheels and npm packages ([#692](https://github.com/matyushkin/djvu-rs/issues/692)) ([cd0adbc](https://github.com/matyushkin/djvu-rs/commit/cd0adbca9f73173a84b58ad70149024197813178))
* publish DjVu conformance dashboard ([ca76318](https://github.com/matyushkin/djvu-rs/commit/ca76318f579f3be34a1a3f7ab54a894c699f2ebd))
* publish DjVu conformance dashboard ([#682](https://github.com/matyushkin/djvu-rs/issues/682)) ([d0666fd](https://github.com/matyushkin/djvu-rs/commit/d0666fdea2e6cc9cc99950c12412495996d8d5b2))
* **render:** structured recovery report from permissive renders ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([ee6dc02](https://github.com/matyushkin/djvu-rs/commit/ee6dc02f3f0839a9178a1ce2c88ee1a3b9d10341))
* **render:** structured recovery report from permissive renders ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([3381f58](https://github.com/matyushkin/djvu-rs/commit/3381f587107dbef712f3ffb208dab1d80cd68727))
* **render:** tile cache budget, invalidation, prefetch ([#691](https://github.com/matyushkin/djvu-rs/issues/691) slice 2) ([#746](https://github.com/matyushkin/djvu-rs/issues/746)) ([fe7914f](https://github.com/matyushkin/djvu-rs/commit/fe7914f466ab08e9420a50e29fe1fc3e94e86d26))
* **render:** tile-first rendering API slice 1 ([#691](https://github.com/matyushkin/djvu-rs/issues/691)) ([#744](https://github.com/matyushkin/djvu-rs/issues/744)) ([2cb629f](https://github.com/matyushkin/djvu-rs/commit/2cb629f9fdc6eb7dcdd3637bfe425c9499cff2ea))
* **tiff:** two-pass bilevel G4 export bounds memory to one page ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([2db57c6](https://github.com/matyushkin/djvu-rs/commit/2db57c6373fda92218aefaf7e3d755d07ec42abb))
* **tiff:** two-pass bilevel G4 export bounds memory to one page ([#690](https://github.com/matyushkin/djvu-rs/issues/690)) ([962c3e3](https://github.com/matyushkin/djvu-rs/commit/962c3e31ac697a80a54e083053388d0738ab1da1))
* **tile:** progressive quality steps and cooperative cancellation ([#691](https://github.com/matyushkin/djvu-rs/issues/691) slice 3a) ([#747](https://github.com/matyushkin/djvu-rs/issues/747)) ([1534ba7](https://github.com/matyushkin/djvu-rs/commit/1534ba766391ded66d999595f4949be307cd54e3))
* **tile:** progressive tile quality, cancellation, async+wasm surfaces ([#748](https://github.com/matyushkin/djvu-rs/issues/748)) ([2f934f1](https://github.com/matyushkin/djvu-rs/commit/2f934f11cd8494e728df256968e0c54f92e51600))
* **validate:** resource estimates and --limits before expensive work ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([8cfdff1](https://github.com/matyushkin/djvu-rs/commit/8cfdff145f3139b09f208843aea3b8f4a4c89de9))
* **validate:** resource-limit layer with pre-decode budget gate ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([1796936](https://github.com/matyushkin/djvu-rs/commit/1796936c1b40c7f34af6bbb6bec99f42fbe37681))
* **validate:** writer pre-commit validation and validator fuzzing ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([01d2852](https://github.com/matyushkin/djvu-rs/commit/01d2852b22508e76bf68817994ec3c75a88d2efd))
* **validate:** writer pre-commit validation and validator fuzzing ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([81f983c](https://github.com/matyushkin/djvu-rs/commit/81f983ca2f57ec2a9c4c1a4176eedaa5a7545f09))
* **writer:** add Smmr and fresh metadata paths ([#685](https://github.com/matyushkin/djvu-rs/issues/685)) ([fb8469d](https://github.com/matyushkin/djvu-rs/commit/fb8469d36eb6bdfc79977a8ada8c9e8c84aa348e))
* **writer:** add Smmr and fresh metadata paths ([#685](https://github.com/matyushkin/djvu-rs/issues/685)) ([0ec3699](https://github.com/matyushkin/djvu-rs/commit/0ec3699973790ae58f5a8cf95605ae657d664afe))


### Bug Fixes

* align conformance gate with pinned baseline ([6fed285](https://github.com/matyushkin/djvu-rs/commit/6fed285649b509d75b1e050dd417f55039f3c87c))
* **conformance:** close [#682](https://github.com/matyushkin/djvu-rs/issues/682) acceptance gaps ([2a204b4](https://github.com/matyushkin/djvu-rs/commit/2a204b48485a5e39b58f2a57831fc191a6474689))
* **deps:** require tract-onnx &gt;=0.22.2 (RUSTSEC-2026-0217) ([#743](https://github.com/matyushkin/djvu-rs/issues/743)) ([e9c4d37](https://github.com/matyushkin/djvu-rs/commit/e9c4d377c96ce8ecd68302d3b52d0a2898d63e63))
* **iw44:** use `|V| >= s` significance gate to close dense-page plateau ([#684](https://github.com/matyushkin/djvu-rs/issues/684)) ([43a443e](https://github.com/matyushkin/djvu-rs/commit/43a443e067f4e0012a6181f0c66f786b30f94063))
* **iw44:** use `|V| >= s` significance gate to close dense-page plateau ([#684](https://github.com/matyushkin/djvu-rs/issues/684)) ([e34d5f2](https://github.com/matyushkin/djvu-rs/commit/e34d5f2082039ca60bbe1fe4cf8796c0d5fb74ba))
* **iw44:** use DjVuLibre Pigeon RGB-&gt;YCbCr in colour encode ([#684](https://github.com/matyushkin/djvu-rs/issues/684)) ([dd7c436](https://github.com/matyushkin/djvu-rs/commit/dd7c4361797af51aaa2e33b1c0d917a21d96a7ac))
* **iw44:** use DjVuLibre Pigeon RGB-&gt;YCbCr in colour encode ([#684](https://github.com/matyushkin/djvu-rs/issues/684)) ([813b1b2](https://github.com/matyushkin/djvu-rs/commit/813b1b20156100bb2175140b2574b3fb9344faf7))
* **optimizer:** warn that max_ssim_loss is not an active gate yet ([5614ee7](https://github.com/matyushkin/djvu-rs/commit/5614ee748c870f569879758c4e8785d81478c934))
* **test:** make sub4 JB2 decode counters work under parallel ([d19a09b](https://github.com/matyushkin/djvu-rs/commit/d19a09b2010665f65b5a647d86b858f023800f88))
* two 32-bit overflow bugs found by the new sanitizer CI ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([4995268](https://github.com/matyushkin/djvu-rs/commit/49952687d9942e0023fab319c6ca2329adf8357d))
* two 32-bit overflow bugs found by the new sanitizer CI ([#696](https://github.com/matyushkin/djvu-rs/issues/696)) ([bfe2c00](https://github.com/matyushkin/djvu-rs/commit/bfe2c00a2437cfa0b4da9587af2c2450072a9dfd))
* **validate:** include parse error in indirect-DJVM warning message ([b8b25f8](https://github.com/matyushkin/djvu-rs/commit/b8b25f80bf17cb0e546e50519f21b1ad3021af49))


### Performance Improvements

* **#684:** add encoder parity scorecard ([723c18f](https://github.com/matyushkin/djvu-rs/commit/723c18fd46230735251df1d65264cd34df716c05))
* **#684:** add encoder parity scorecard ([50b4d20](https://github.com/matyushkin/djvu-rs/commit/50b4d20508dee9d1992af3a7d764149a4e8f43f3))

## [0.27.0](https://github.com/matyushkin/djvu-rs/compare/v0.26.2...v0.27.0) (2026-07-12)


### Features

* **cli:** expose TH44 thumbnail embedding via djvu encode --thumbnails ([#590](https://github.com/matyushkin/djvu-rs/issues/590)) ([#653](https://github.com/matyushkin/djvu-rs/issues/653)) ([51ff48d](https://github.com/matyushkin/djvu-rs/commit/51ff48d4f3513e4ab54c7445f9de25d7121ea82c))
* **encode:** automatic content-type detection for the encode profile ([#570](https://github.com/matyushkin/djvu-rs/issues/570)) ([#648](https://github.com/matyushkin/djvu-rs/issues/648)) ([4ac02e0](https://github.com/matyushkin/djvu-rs/commit/4ac02e02ef1690b99577fd94988fbe493bb47776))
* **encode:** DjVuPhoto profile -- mask-less BG44-only encode with grayscale path ([#571](https://github.com/matyushkin/djvu-rs/issues/571)) ([#647](https://github.com/matyushkin/djvu-rs/issues/647)) ([29c747c](https://github.com/matyushkin/djvu-rs/commit/29c747c5de305eeea3e63ddf51d9f2a7ae1eae06))
* **py:** region/tile render and progressive decode in djvu-py ([#583](https://github.com/matyushkin/djvu-rs/issues/583)) ([#650](https://github.com/matyushkin/djvu-rs/issues/650)) ([2c364ab](https://github.com/matyushkin/djvu-rs/commit/2c364ab75df8676a7d2b32d51058488cf22c78a2))
* **segment:** opt-in projection-profile deskew -- skew costs +150-384% Sjbz at 1 degree ([#592](https://github.com/matyushkin/djvu-rs/issues/592)) ([#663](https://github.com/matyushkin/djvu-rs/issues/663)) ([c3995ce](https://github.com/matyushkin/djvu-rs/commit/c3995ce45f6f32c127f62991940f3c9f9117a3d8))
* **wasm:** lazy Range-based document open -- WasmLazyDocument, 11-19x TTFP in Chrome ([#588](https://github.com/matyushkin/djvu-rs/issues/588)) ([#652](https://github.com/matyushkin/djvu-rs/issues/652)) ([6358073](https://github.com/matyushkin/djvu-rs/commit/63580737fed702f3703da469dc9d9f27b3382cfc))


### Bug Fixes

* **bench:** fail closed on missing Criterion results ([#616](https://github.com/matyushkin/djvu-rs/issues/616)) ([7e123bf](https://github.com/matyushkin/djvu-rs/commit/7e123bfb2d90c853fac65b71af81355d444d1d87))
* **bench:** measure both sides of the suspect re-check back-to-back ([#636](https://github.com/matyushkin/djvu-rs/issues/636)) ([3795fc5](https://github.com/matyushkin/djvu-rs/commit/3795fc558cd716246cc929dbd1b7ef056d43b5f0))
* **bench:** re-check flagged regressions against the merge base on the same runner ([#634](https://github.com/matyushkin/djvu-rs/issues/634)) ([63a471d](https://github.com/matyushkin/djvu-rs/commit/63a471da5183315ef880bd6f6386349f9e2b4303))
* **decode:** resolve the shared dictionary across all INCL chunks -- czech.djvu masks restored ([#624](https://github.com/matyushkin/djvu-rs/issues/624)) ([#661](https://github.com/matyushkin/djvu-rs/issues/661)) ([644d9bb](https://github.com/matyushkin/djvu-rs/commit/644d9bbd253e8f47842fc1f23ca7db8ce514acb7))
* **djvm:** DjVuLibre-clean DIRM for merge/split -- fill offsets/sizes, write directory version 1 ([#657](https://github.com/matyushkin/djvu-rs/issues/657)) ([#659](https://github.com/matyushkin/djvu-rs/issues/659)) ([2c822d8](https://github.com/matyushkin/djvu-rs/commit/2c822d8abc6941829240e94aa90f2c968fafa83a))
* **iw44:** decode v1.2 chroma at full resolution ([#614](https://github.com/matyushkin/djvu-rs/issues/614)) ([4ae4435](https://github.com/matyushkin/djvu-rs/commit/4ae44357f42d7d76397b76130921c37fd60d889c))
* **pdf:** paint FGbz-coloured foreground text with per-colour stencils ([#559](https://github.com/matyushkin/djvu-rs/issues/559)) ([#619](https://github.com/matyushkin/djvu-rs/issues/619)) ([d24c9fa](https://github.com/matyushkin/djvu-rs/commit/d24c9fadb29501889e199fdd5c6143bef3499b9b))
* **pdf:** restore lost and invisible foreground masks in PDF export ([#620](https://github.com/matyushkin/djvu-rs/issues/620), [#621](https://github.com/matyushkin/djvu-rs/issues/621)) ([#622](https://github.com/matyushkin/djvu-rs/issues/622)) ([d0598ac](https://github.com/matyushkin/djvu-rs/commit/d0598ac39590404993483a48f6998f34bf0bd385))


### Performance Improvements

* **async:** index bundled DJVM from the DIRM size table -- 103x TTFP over HTTP Range ([#584](https://github.com/matyushkin/djvu-rs/issues/584)) ([#651](https://github.com/matyushkin/djvu-rs/issues/651)) ([ad041b5](https://github.com/matyushkin/djvu-rs/commit/ad041b50e38eafb26c2ccb6554774e482c0b9c6a))
* **cache:** preserve the 1/4-res JB2 mask across render-cache downgrade ([#607](https://github.com/matyushkin/djvu-rs/issues/607)) ([#627](https://github.com/matyushkin/djvu-rs/issues/627)) ([9355aa6](https://github.com/matyushkin/djvu-rs/commit/9355aa69dd12ff3a364f62eb77f3a6593231af47))
* **cli:** parallelize CBZ export via a new cbz library module ([#598](https://github.com/matyushkin/djvu-rs/issues/598)) ([#625](https://github.com/matyushkin/djvu-rs/issues/625)) ([ddfd111](https://github.com/matyushkin/djvu-rs/commit/ddfd11101611e67ca35020e9cc7c690bb8499b9f))
* **encode:** build the FGbz palette from encoder blit metadata ([#612](https://github.com/matyushkin/djvu-rs/issues/612)) ([#626](https://github.com/matyushkin/djvu-rs/issues/626)) ([238ae11](https://github.com/matyushkin/djvu-rs/commit/238ae1169b07ba54fbfbe83fca96edf4199ce8a5))
* **encode:** two-pass layered bundle encode drops backgrounds and mask clones ([#565](https://github.com/matyushkin/djvu-rs/issues/565)) ([#637](https://github.com/matyushkin/djvu-rs/issues/637)) ([344efc6](https://github.com/matyushkin/djvu-rs/commit/344efc673876adf6633e4561f9ee4233d612a700))
* **export:** render whole-document exports on cold page clones -- 504-page PDF peak RSS 2.24 GB -&gt; 45 MB ([#629](https://github.com/matyushkin/djvu-rs/issues/629)) ([#654](https://github.com/matyushkin/djvu-rs/issues/654)) ([037c9fc](https://github.com/matyushkin/djvu-rs/commit/037c9fc457f30e8172a0e32deb107d6b872cb90b))
* **iw44:** resume full decode from the cached first-chunk state ([#608](https://github.com/matyushkin/djvu-rs/issues/608)) ([#643](https://github.com/matyushkin/djvu-rs/issues/643)) ([2c4b269](https://github.com/matyushkin/djvu-rs/commit/2c4b2690d7f25fb429c784d7bbc6051fcea8ddea))
* **metadata:** cache decoded TXTz and ANTz layers per page ([#605](https://github.com/matyushkin/djvu-rs/issues/605)) ([#635](https://github.com/matyushkin/djvu-rs/issues/635)) ([6d4141f](https://github.com/matyushkin/djvu-rs/commit/6d4141f1848c94403af27914c2aceb13ea2fb047))
* **mut:** incremental byte-range save for bundled DJVM -- same-size edits write 1 byte instead of the file ([#595](https://github.com/matyushkin/djvu-rs/issues/595)) ([#658](https://github.com/matyushkin/djvu-rs/issues/658)) ([2990793](https://github.com/matyushkin/djvu-rs/commit/2990793189824703fc9d5a8f93b7c28d9c7af2fd))
* **ocr:** parallelize OCR across pages in the CLI ([#573](https://github.com/matyushkin/djvu-rs/issues/573)) ([#645](https://github.com/matyushkin/djvu-rs/issues/645)) ([9520458](https://github.com/matyushkin/djvu-rs/commit/9520458486160360eb128ae9290bd4e9e5aa79f1))
* **pdf:** stream PDF objects to a writer to bound serialization memory ([#606](https://github.com/matyushkin/djvu-rs/issues/606)) ([#630](https://github.com/matyushkin/djvu-rs/issues/630)) ([a63b680](https://github.com/matyushkin/djvu-rs/commit/a63b680ba15a6f43ec2c0153444c03b2161a477d))
* **render:** LRU tile-cache eviction + hit-rate telemetry and budget sweep ([#576](https://github.com/matyushkin/djvu-rs/issues/576)) ([#644](https://github.com/matyushkin/djvu-rs/issues/644)) ([17f7d95](https://github.com/matyushkin/djvu-rs/commit/17f7d953ef14ba462ba0fb216120ddcd66175d59))
* **segment:** parallelize the Sauvola threshold pass ([#575](https://github.com/matyushkin/djvu-rs/issues/575)) ([#623](https://github.com/matyushkin/djvu-rs/issues/623)) ([5b24f50](https://github.com/matyushkin/djvu-rs/commit/5b24f50939690d2e2ca100919e6407f1e47917e5))
* **wasm:** coarse-grained batch page rendering ([#610](https://github.com/matyushkin/djvu-rs/issues/610)) ([#642](https://github.com/matyushkin/djvu-rs/issues/642)) ([db65a1a](https://github.com/matyushkin/djvu-rs/commit/db65a1a492177657c9acfafb20466cbf94f56fcd))
* **wasm:** open documents through the lazy shared backing ([#609](https://github.com/matyushkin/djvu-rs/issues/609)) ([#632](https://github.com/matyushkin/djvu-rs/issues/632)) ([8b81993](https://github.com/matyushkin/djvu-rs/commit/8b8199314199b212a1a37751b9b0fce26a477d80))
* **wasm:** reusable Rust-owned pixel buffer with zero-copy view ([#611](https://github.com/matyushkin/djvu-rs/issues/611)) ([#631](https://github.com/matyushkin/djvu-rs/issues/631)) ([dea47a5](https://github.com/matyushkin/djvu-rs/commit/dea47a56de03c8246e0e9ab2199948c37d57b332))
* **wasm:** ship simd128 package variant ([1b2e4db](https://github.com/matyushkin/djvu-rs/commit/1b2e4dbe80866b5a489c003c338242868936f8dc))
* **wasm:** ship simd128 package variant ([#581](https://github.com/matyushkin/djvu-rs/issues/581)) ([81acb78](https://github.com/matyushkin/djvu-rs/commit/81acb7824dff6f8eef1d36a56ae86f429d55c8f2))

## [0.26.2](https://github.com/matyushkin/djvu-rs/compare/v0.26.1...v0.26.2) (2026-07-10)


### Performance Improvements

* BG-heavy colour-encode bench + land PAR_PAGE_LAYERS (Sjbz ∥ BG44 join) ([#496](https://github.com/matyushkin/djvu-rs/issues/496)) ([#555](https://github.com/matyushkin/djvu-rs/issues/555)) ([ad29126](https://github.com/matyushkin/djvu-rs/commit/ad29126b411a81cdeda60040e137da3321d368f1))

## [0.26.1](https://github.com/matyushkin/djvu-rs/compare/v0.26.0...v0.26.1) (2026-07-09)


### Bug Fixes

* decode ANTa/ANTz annotation payloads leniently — one bad byte no longer drops all annotations ([#553](https://github.com/matyushkin/djvu-rs/issues/553)) ([#554](https://github.com/matyushkin/djvu-rs/issues/554)) ([9806824](https://github.com/matyushkin/djvu-rs/commit/98068241cec25820fe628efbd63d148c6af7ca03))
* decode non-structural strings leniently — CP1252 fallback for NAVM/TXTz/METa ([#524](https://github.com/matyushkin/djvu-rs/issues/524)) ([#551](https://github.com/matyushkin/djvu-rs/issues/551)) ([a461a8a](https://github.com/matyushkin/djvu-rs/commit/a461a8a411e6124660ae5e8be3a9428b7f45f1a8))

## [0.26.0](https://github.com/matyushkin/djvu-rs/compare/v0.25.0...v0.26.0) (2026-07-09)


### ⚠ BREAKING CHANGES

* `djvu_rs::pdf` now requires the `pdf` feature (`djvu-rs = { version = "…", features = ["pdf"] }`); the `cli` feature enables it automatically.

### Features

* decouple writer-side deps from std — pdf/epub/cli own them ([#509](https://github.com/matyushkin/djvu-rs/issues/509)) ([#547](https://github.com/matyushkin/djvu-rs/issues/547)) ([62f30f6](https://github.com/matyushkin/djvu-rs/commit/62f30f690d6d8035e04398c8c654af0bbe54274e))

## [0.25.0](https://github.com/matyushkin/djvu-rs/compare/v0.24.4...v0.25.0) (2026-07-06)


### Features

* **encode:** TXTZ_OCR — encode-time OCR text layer via PageEncoder (round 51) ([#540](https://github.com/matyushkin/djvu-rs/issues/540)) ([3cad5c3](https://github.com/matyushkin/djvu-rs/commit/3cad5c306218884c8ea5b16981269509cc18250f))
* **fgbz:** median-cut foreground palette quantiser (opt-in) ([#522](https://github.com/matyushkin/djvu-rs/issues/522)) ([440ed07](https://github.com/matyushkin/djvu-rs/commit/440ed0772d4ed571d9f71d5862bd59b2be2c56d9))
* **jb2:** lossy_text() preset — expose the −22% text lossy lever (Branch B complete) ([#514](https://github.com/matyushkin/djvu-rs/issues/514)) ([fad0c28](https://github.com/matyushkin/djvu-rs/commit/fad0c28ff5345847ce0a19e85e245d9061963c55))
* **pdf:** PDF_G4 — CCITT Group 4 encoding for bilevel PDF masks (round 51) ([#543](https://github.com/matyushkin/djvu-rs/issues/543)) ([470b40b](https://github.com/matyushkin/djvu-rs/commit/470b40b31538b0011be52bf69b155ab75f36e935))
* **render:** D_AA_ZOOM — opt-in bilinear mask-coverage AA at upscale ([#517](https://github.com/matyushkin/djvu-rs/issues/517)) ([54a0939](https://github.com/matyushkin/djvu-rs/commit/54a09398e46402ef4b096ef59ce7237906d8ec23))
* **render:** streaming ProgressiveDecoder — the deferred B5 stateful API ([#510](https://github.com/matyushkin/djvu-rs/issues/510)) ([1760bd0](https://github.com/matyushkin/djvu-rs/commit/1760bd0ebd72bc14276c85a862dd027bb9fda5c9))
* **render:** TH44_GRID — fast thumbnail-grid decode path via embedded TH44 (opt-in) ([#533](https://github.com/matyushkin/djvu-rs/issues/533)) ([1c36093](https://github.com/matyushkin/djvu-rs/commit/1c360930df68588707fa44a3e31c3a4d4e520979))
* **wasm:** WASM_THREADS — opt-in rayon thread pool via wasm-bindgen-rayon (feasibility + infra) ([#528](https://github.com/matyushkin/djvu-rs/issues/528)) ([e7d523b](https://github.com/matyushkin/djvu-rs/commit/e7d523b6bd72f84a9edbdc7b32f2c103d73f44b5))


### Bug Fixes

* **iff,interop:** INTEROP_INFO — INFO version ceiling + gamma clamp vs DjVuLibre ([#538](https://github.com/matyushkin/djvu-rs/issues/538)) ([518834b](https://github.com/matyushkin/djvu-rs/commit/518834b4f67ba74c36ee22224dc6856f7718e893))
* **iff,test:** carte.djvu short-INFO parse rejection + mmap/parallel decode-count test ([#531](https://github.com/matyushkin/djvu-rs/issues/531)) ([097f9de](https://github.com/matyushkin/djvu-rs/commit/097f9de953b56958fb9195cc2e6360419560dd19))
* **iw44:** INTEROP_STREAMS — BG44/IW44 serial + dimension checks, JB2 divergence root-caused (round 46) ([#539](https://github.com/matyushkin/djvu-rs/issues/539)) ([c524585](https://github.com/matyushkin/djvu-rs/commit/c5245857bf2e9909ff71b1d7f3aaf62f5d80fbdf))
* **iw44:** tolerate zero-length BG44 refinement chunk payload (BUG-ZPSHORT) ([#518](https://github.com/matyushkin/djvu-rs/issues/518)) ([2387d88](https://github.com/matyushkin/djvu-rs/commit/2387d88e2919866a2e741e56c811c91ae072d421))


### Performance Improvements

* **bench:** large single-page colour-encode bench + PAR_PAGE_LAYERS revisit ([#513](https://github.com/matyushkin/djvu-rs/issues/513)) ([b5363b1](https://github.com/matyushkin/djvu-rs/commit/b5363b150c06c2304f8747ac132ad42130c44367))
* **diag:** BZZ encoder + PDF JPEG-background diagnostics (no shipped-code changes) ([#515](https://github.com/matyushkin/djvu-rs/issues/515)) ([2012345](https://github.com/matyushkin/djvu-rs/commit/2012345f0391ae77a33b6f2728d232acec95e2f8))
* **diag:** JB2_DICT_ORDER — shared-dict index permutation, no size win (Round 24) ([#520](https://github.com/matyushkin/djvu-rs/issues/520)) ([d1463ac](https://github.com/matyushkin/djvu-rs/commit/d1463ac171677a3bf8f625f5d4b573ef6a15c42d))
* **fuzz:** DIFF_FUZZ — corpus-mutation differential fuzzer vs DjVuLibre ([#534](https://github.com/matyushkin/djvu-rs/issues/534)) ([01570eb](https://github.com/matyushkin/djvu-rs/commit/01570ebc5b4f35f38f61d18b7ffce23b11e71f3d))
* gray/Lanczos/memory sweep + D1 quality harness (rounds 7-14) ([cfd018a](https://github.com/matyushkin/djvu-rs/commit/cfd018a23c40e7fdfef7c6d368ec1771321b5e9b))
* **iw44:** AVX2_IDWT — rejected (runtime dispatch regresses IDWT, round 51) ([#541](https://github.com/matyushkin/djvu-rs/issues/541)) ([d749712](https://github.com/matyushkin/djvu-rs/commit/d7497125b2a1b39db06684d8dc241ac246b02af1))
* **iw44:** harmonic BG diffusion for masked cells (−52% to −97% BG44, quality up) ([#505](https://github.com/matyushkin/djvu-rs/issues/505)) ([5d09e0c](https://github.com/matyushkin/djvu-rs/commit/5d09e0cd44a2ac0fba0b1102a188e4f5fa6db42c))
* **iw44:** IW44_ENTROPY_PROBE — localize textured-content size gap vs c44 (round 51, diagnostic) ([#542](https://github.com/matyushkin/djvu-rs/issues/542)) ([a94fc84](https://github.com/matyushkin/djvu-rs/commit/a94fc84d1648d8db9ddda3b641426f5f8d84308b))
* **jb2:** borrow shared dict instead of cloning per page (byte-identical) ([#504](https://github.com/matyushkin/djvu-rs/issues/504)) ([da9bbd5](https://github.com/matyushkin/djvu-rs/commit/da9bbd5e8e76eb5f177139f61ec49cb41dd95495))
* **jb2:** hash-index shared-symbol clustering — −81% (≈5.2×) on 517-page corpus ([#503](https://github.com/matyushkin/djvu-rs/issues/503)) ([f45a607](https://github.com/matyushkin/djvu-rs/commit/f45a607a0e37f31ecbc40567c5f337f5c254fc2e))
* **jb2:** JB2_AUTO_REC6 — density-probe auto-policy for same-size rec-6 ([#516](https://github.com/matyushkin/djvu-rs/issues/516)) ([33606db](https://github.com/matyushkin/djvu-rs/commit/33606dbed54cf92bb82e5a39944f16f148b2ae33))
* **jb2:** JB2_DESPECKLE — speck-removal pre-pass for lossy JB2 on noisy scans ([#521](https://github.com/matyushkin/djvu-rs/issues/521)) ([8aa8b2f](https://github.com/matyushkin/djvu-rs/commit/8aa8b2f0a653d9034ef585b392cfe51f821b5807))
* **jb2:** OCR_QA — OCR-agreement metric for lossy JB2 levers (round 41) ([#532](https://github.com/matyushkin/djvu-rs/issues/532)) ([353bc01](https://github.com/matyushkin/djvu-rs/commit/353bc01a773dd09f9a09df374489206a1c72c2a7))
* **jb2:** same-size rec-6 refinement — validated lossless −11.7% Sjbz on text ([#512](https://github.com/matyushkin/djvu-rs/issues/512)) ([25736a3](https://github.com/matyushkin/djvu-rs/commit/25736a3043e7df14af7f117d509e2d4a2b51512d))
* **mmap:** COLD_OPEN — cold-start harness + madvise (neutral) / prefetch (+24-90%) levers ([#529](https://github.com/matyushkin/djvu-rs/issues/529)) ([e237d50](https://github.com/matyushkin/djvu-rs/commit/e237d501dcd11463c603328651176411194f7df0))
* **pdf:** PDF_ADAPTIVE_RASTER — opt-in per-page Deflate-vs-JPEG choice ([#519](https://github.com/matyushkin/djvu-rs/issues/519)) ([47fec99](https://github.com/matyushkin/djvu-rs/commit/47fec996986c479aacce84e0f1d66603f1fc466a))
* **py:** PY_ZEROCOPY — GIL release + buffer-protocol zero-copy Pixmap in djvu-py ([#530](https://github.com/matyushkin/djvu-rs/issues/530)) ([bde8421](https://github.com/matyushkin/djvu-rs/commit/bde84217af65601c0ff8c095b6017ef619780eff))
* **quality:** QUALITY_COLOR — colour-aware D1 metric (Y/Cb/Cr SSIM + CIE76 ΔE) ([#525](https://github.com/matyushkin/djvu-rs/issues/525)) ([bd90536](https://github.com/matyushkin/djvu-rs/commit/bd90536fb7c01aaa677ce022b9434c8485a53de9))
* **render:** C5_COMPRESS — opt-in downgrade-on-evict render-cache tier (round 47) ([#537](https://github.com/matyushkin/djvu-rs/issues/537)) ([2ae8cf2](https://github.com/matyushkin/djvu-rs/commit/2ae8cf2cacc994e4c7a2a9fbdac9dd1cd09e2f63))
* **render:** D3_BICUBIC — FG44 bicubic upsampling measured, rejected ([#523](https://github.com/matyushkin/djvu-rs/issues/523)) ([37d42e6](https://github.com/matyushkin/djvu-rs/commit/37d42e6a9e1074e34df43c9f6930bb714da22361))
* **render:** Lanczos RGBA-interleaved accumulate — −22 to −27%, bit-identical ([#508](https://github.com/matyushkin/djvu-rs/issues/508)) ([95de0c4](https://github.com/matyushkin/djvu-rs/commit/95de0c4ab555078e2dad344580d3ce7db0dda3ce))
* **render:** VIEWER_BENCH + C4_TILE_CACHE — pan/zoom scenario bench justifies a composited-tile cache ([#527](https://github.com/matyushkin/djvu-rs/issues/527)) ([7304d9a](https://github.com/matyushkin/djvu-rs/commit/7304d9aeb4c63d2459b2cac1e4b6fdc910ad66d0))
* **zp:** ZP_U64 — u64 bit_buf widening investigated, reverted (round 54) ([#544](https://github.com/matyushkin/djvu-rs/issues/544)) ([f6e0f57](https://github.com/matyushkin/djvu-rs/commit/f6e0f571ff07fffbb189972b3c9a67237442362e))

## [0.24.4](https://github.com/matyushkin/djvu-rs/compare/v0.24.3...v0.24.4) (2026-07-03)


### Performance Improvements

* **build:** fat LTO + codegen-units=1 profile (−65% jb2 encode) ([#494](https://github.com/matyushkin/djvu-rs/issues/494)) ([6c6138a](https://github.com/matyushkin/djvu-rs/commit/6c6138a21334b60e29ead46a56cf4c4af40c02b0))
* **encode:** parallel per-page encoding in DJVM bundlers (−35…43% / −39%) ([#493](https://github.com/matyushkin/djvu-rs/issues/493)) ([a6d252a](https://github.com/matyushkin/djvu-rs/commit/a6d252a44f36abe6c4f1049fb4cd72e12f0dc199))
* parallelism sweep round 4 — clustering, EPUB/TIFF export, segmentation ([#497](https://github.com/matyushkin/djvu-rs/issues/497)) ([5deb1c2](https://github.com/matyushkin/djvu-rs/commit/5deb1c2ca3aa82cf6e10b7b721d833440b4822dd))
* rounds 5-6 decode/render/open sweep — lazy open (−48%), shared-dict (−37%), PGO (−15%) ([#498](https://github.com/matyushkin/djvu-rs/issues/498)) ([eb1fed4](https://github.com/matyushkin/djvu-rs/commit/eb1fed4a4e363df72c030df6a911159f4824c7fa))

## [0.24.3](https://github.com/matyushkin/djvu-rs/compare/v0.24.2...v0.24.3) (2026-07-02)


### Performance Improvements

* **encode:** row-slice foreground_fgbz blit-colour scan (~2% color encode) ([#490](https://github.com/matyushkin/djvu-rs/issues/490)) ([33ee923](https://github.com/matyushkin/djvu-rs/commit/33ee9230c317b0c9ff4ac9fd542f949e5d245a7c))

## [0.24.2](https://github.com/matyushkin/djvu-rs/compare/v0.24.1...v0.24.2) (2026-07-02)


### Performance Improvements

* **jb2:** byte-unpack extract_ccs mask expansion (~26% dict encode) ([#484](https://github.com/matyushkin/djvu-rs/issues/484)) ([f8a476f](https://github.com/matyushkin/djvu-rs/commit/f8a476f17a3a5cacae3bddb08e0ed84acd055d44))
* **segment:** row-slice mask fill + block-mean scan (~14% segment_page) ([#486](https://github.com/matyushkin/djvu-rs/issues/486)) ([b567a59](https://github.com/matyushkin/djvu-rs/commit/b567a5957273871377ed0e0f48629d23cd49d28a))

## [0.24.1](https://github.com/matyushkin/djvu-rs/compare/v0.24.0...v0.24.1) (2026-07-01)


### Performance Improvements

* **bzz:** MTF shift via copy_within memmove (~2% bzz_decode) ([#479](https://github.com/matyushkin/djvu-rs/issues/479)) ([b284d6b](https://github.com/matyushkin/djvu-rs/commit/b284d6bf3020d44ee4ad77f0b5121d178f8b16a5))
* **jb2:** byte-unpack bitmap expansion in encode_bitmap_direct (~20-26%) ([#481](https://github.com/matyushkin/djvu-rs/issues/481)) ([d5ab4ce](https://github.com/matyushkin/djvu-rs/commit/d5ab4ce5bd963d504a0cbc11eceae173d233b6b5))

## [0.24.0](https://github.com/matyushkin/djvu-rs/compare/v0.23.0...v0.24.0) (2026-07-01)


### Features

* **encode:** accept JPEG and TIFF inputs in addition to PNG ([#477](https://github.com/matyushkin/djvu-rs/issues/477)) ([9e1af97](https://github.com/matyushkin/djvu-rs/commit/9e1af97913f68fa3abd1a8827481e7c2b6c36d35))
* **encode:** generate TH44 per-page thumbnails during multi-page bundle encoding ([#476](https://github.com/matyushkin/djvu-rs/issues/476)) ([4b3486a](https://github.com/matyushkin/djvu-rs/commit/4b3486aaf4e1696b1cdbf5720e4ec14a5841de88))
* **iw44:** add Iw44Target::Bpp byte-budget encode-stopping criterion ([#475](https://github.com/matyushkin/djvu-rs/issues/475)) ([a1e3d54](https://github.com/matyushkin/djvu-rs/commit/a1e3d54b0462344772a115e5f05f20aca4ef48a5))

## [0.23.0](https://github.com/matyushkin/djvu-rs/compare/v0.22.5...v0.23.0) (2026-06-30)


### ⚠ BREAKING CHANGES

* **encode:** `encode_djvm_bundle_jb2` and `encode_djvm_bundle_jb2_with_shared` gain a trailing `dpi: u16` parameter. Pass `jb2_encode::BUNDLE_DEFAULT_DPI` to preserve prior intent. Bundled-mask DjVu output now carries the supplied dpi and gamma 2.2 (previously a hard-coded dpi 100 / gamma 0.1).

### Bug Fixes

* **encode:** address post-merge review of [#469](https://github.com/matyushkin/djvu-rs/issues/469)-[#472](https://github.com/matyushkin/djvu-rs/issues/472) ([#474](https://github.com/matyushkin/djvu-rs/issues/474)) ([3f510c3](https://github.com/matyushkin/djvu-rs/commit/3f510c3145d9c9845133ec0dd7f3023bab66f588))
* **encode:** single canonical INFO serializer across encode paths ([#470](https://github.com/matyushkin/djvu-rs/issues/470)) ([0b376cb](https://github.com/matyushkin/djvu-rs/commit/0b376cbe79f29a8e6ef878a553f2453e9f6d4e47))


### Performance Improvements

* **jb2:** hash-bucket dedup to drop per-CC bitmap clone (~2-3%, byte-identical) ([#467](https://github.com/matyushkin/djvu-rs/issues/467)) ([95bf134](https://github.com/matyushkin/djvu-rs/commit/95bf1345211c7424797deb3221e475ae8ab7b40e))

## [0.22.5](https://github.com/matyushkin/djvu-rs/compare/v0.22.4...v0.22.5) (2026-06-30)


### Performance Improvements

* **iw44:** default chroma_delay=10 (match c44; recover full-chroma cost) ([#465](https://github.com/matyushkin/djvu-rs/issues/465)) ([566e610](https://github.com/matyushkin/djvu-rs/commit/566e610fe45ce7b98c780aac468cf5f5ec5d5a9c))

## [0.22.4](https://github.com/matyushkin/djvu-rs/compare/v0.22.3...v0.22.4) (2026-06-30)


### Bug Fixes

* **iw44:** emit DjVuLibre-compatible IW44 major version (encoder interop) ([#462](https://github.com/matyushkin/djvu-rs/issues/462)) ([901a106](https://github.com/matyushkin/djvu-rs/commit/901a10681902803bbaa5581430e6f7e78ef97412))
* **iw44:** full-resolution chroma by default for DjVuLibre interop ([#464](https://github.com/matyushkin/djvu-rs/issues/464)) ([ed85953](https://github.com/matyushkin/djvu-rs/commit/ed859530a5839928187e8420dc587a82cfb23872))

## [0.22.3](https://github.com/matyushkin/djvu-rs/compare/v0.22.2...v0.22.3) (2026-06-30)


### Bug Fixes

* **jb2:** consume all comment-record octets to keep ZP coder aligned (correctness) ([#460](https://github.com/matyushkin/djvu-rs/issues/460)) ([c4f69a6](https://github.com/matyushkin/djvu-rs/commit/c4f69a68addb0e696a94b8d89ac38f49ad570e16))

## [0.22.2](https://github.com/matyushkin/djvu-rs/compare/v0.22.1...v0.22.2) (2026-06-30)


### Bug Fixes

* **decoders:** bound IFF/NAVM recursion + IFF length overflow (security review) ([#458](https://github.com/matyushkin/djvu-rs/issues/458)) ([3dc43f3](https://github.com/matyushkin/djvu-rs/commit/3dc43f3e42bf22a003d96ed773eb9eee348d29d9))
* **decoders:** cap allocations + fix overflow on untrusted input (security review) ([#459](https://github.com/matyushkin/djvu-rs/issues/459)) ([a034890](https://github.com/matyushkin/djvu-rs/commit/a03489051c7b296324ce31c5b422b746fd38dddd))
* **jb2:** enforce per-page symbol cap before decode (codex review) ([#456](https://github.com/matyushkin/djvu-rs/issues/456)) ([59896a1](https://github.com/matyushkin/djvu-rs/commit/59896a1b964114af6196114c95d98471cf7999c3))

## [0.22.1](https://github.com/matyushkin/djvu-rs/compare/v0.22.0...v0.22.1) (2026-06-26)


### Bug Fixes

* **jb2:** lower per-page symbol cap 32-&gt;16 MP to stop fuzz_jb2 flake ([c21bf06](https://github.com/matyushkin/djvu-rs/commit/c21bf062ea7ecd88a3a2cdebc10f2f24ae5c2df9))

## [0.22.0](https://github.com/matyushkin/djvu-rs/compare/v0.21.0...v0.22.0) (2026-06-25)


### Features

* **encode:** [#452](https://github.com/matyushkin/djvu-rs/issues/452) shared Djbz dictionary for layered multi-page encode ([3466abd](https://github.com/matyushkin/djvu-rs/commit/3466abd1af9150bb0cfd528ce26c666c5e960f2b))
* **iw44:** [#422](https://github.com/matyushkin/djvu-rs/issues/422) bilinear chroma upsampling for chroma_half pages ([0e96d56](https://github.com/matyushkin/djvu-rs/commit/0e96d56b18cc435fc8f41923d749d934b152ed34))


### Bug Fixes

* **jb2:** bound per-page symbol decode to stop fuzz_jb2 timeout (DoS) ([0710594](https://github.com/matyushkin/djvu-rs/commit/0710594deb7ad8a15493c15adac1b5ba8dd621d1))


### Performance Improvements

* **iw44:** match activation-prediction threshold to real gate (-9.1% BG44) ([20d1372](https://github.com/matyushkin/djvu-rs/commit/20d1372d97a2c41ab32ba18daa070293669ac59f))

## [0.21.0](https://github.com/matyushkin/djvu-rs/compare/v0.20.5...v0.21.0) (2026-06-24)


### Features

* **render:** [#439](https://github.com/matyushkin/djvu-rs/issues/439) anti-aliased color downscale via proportional fg/bg blend ([3e8c508](https://github.com/matyushkin/djvu-rs/commit/3e8c508f64fc895d9dbb76e3f77fd62e631f7c88))


### Bug Fixes

* **pixmap:** import vec! under no_std for scale_lanczos3 ([#448](https://github.com/matyushkin/djvu-rs/issues/448) follow-up) ([b58ae83](https://github.com/matyushkin/djvu-rs/commit/b58ae8341bd5c076f13b153948e728ad058b5ed9))


### Performance Improvements

* **jb2:** [#446](https://github.com/matyushkin/djvu-rs/issues/446) O(1) page-dedup in cluster_shared_symbols_tunable (O(P^2)-&gt;O(P)) ([0618bf7](https://github.com/matyushkin/djvu-rs/commit/0618bf7013d5164b79bf4e90dd1b7ac60f734290))
* **pdf:** [#449](https://github.com/matyushkin/djvu-rs/issues/449) stream page render-&gt;emit-&gt;drop in sequential PDF path ([fdb427b](https://github.com/matyushkin/djvu-rs/commit/fdb427b2f471a5e2145860c6cc6f961370537d4c))
* **render:** [#435](https://github.com/matyushkin/djvu-rs/issues/435) all-bg row fast path in B-series bilinear path (F2 analog) ([71aea00](https://github.com/matyushkin/djvu-rs/commit/71aea00a7be9ca46d1cbd2737d2cb684d127e24a))
* **render:** [#438](https://github.com/matyushkin/djvu-rs/issues/438) all-bg row fast path in area-average compositor (F2/I3 analog) ([93ab095](https://github.com/matyushkin/djvu-rs/commit/93ab095ddc21d683588c99ff9e6196cc1453e955))
* **render:** [#440](https://github.com/matyushkin/djvu-rs/issues/440) parallel BG44/FG44 layer decode via rayon::join (~22% cold) ([9c2d79c](https://github.com/matyushkin/djvu-rs/commit/9c2d79c489d16e9df8546074c72aea04c74ff124))
* **render:** [#443](https://github.com/matyushkin/djvu-rs/issues/443) extend F2 all-bg fast path to non-identity gamma ([7aa47f2](https://github.com/matyushkin/djvu-rs/commit/7aa47f2cc615f0586a4c21d47066a6175c91f5b4))
* **render:** [#447](https://github.com/matyushkin/djvu-rs/issues/447) 32x32 tiled transpose in rotate_pixmap Cw90/Ccw90 ([17727b0](https://github.com/matyushkin/djvu-rs/commit/17727b029953dacb3a7f38efe10a97b60878d704))
* **render:** [#448](https://github.com/matyushkin/djvu-rs/issues/448) hoist Lanczos vertical-pass weights + row-major accumulate (~22%) ([0c2c0c5](https://github.com/matyushkin/djvu-rs/commit/0c2c0c59259a086d28541cc1479b7026bad998f5))

## [0.20.5](https://github.com/matyushkin/djvu-rs/compare/v0.20.4...v0.20.5) (2026-06-24)


### Bug Fixes

* **render:** satisfy lint after downscale optimization ([819f4a3](https://github.com/matyushkin/djvu-rs/commit/819f4a3abeae1550c35317d4450df50d3b31f7c0))


### Performance Improvements

* **jb2:** [#429](https://github.com/matyushkin/djvu-rs/issues/429) byte-aligned crop_bitmap fast path in direct encoder (~14-15% multitile) ([a9946b0](https://github.com/matyushkin/djvu-rs/commit/a9946b0f8a0d313ab95149b955289c4d0df1dc2e))
* record F1 NEON color compositor fast path as Rejected ([79e9b6c](https://github.com/matyushkin/djvu-rs/commit/79e9b6c98a06d2b514227b441ced9f42c7f9ff15))
* **render:** [#426](https://github.com/matyushkin/djvu-rs/issues/426) cache decoded BG44 RGB Pixmap at subsample=2 (~7-9% downscale) ([08fb3e9](https://github.com/matyushkin/djvu-rs/commit/08fb3e99f868d7469b105fa401ab24d7ed3f1ac6))
* **render:** [#427](https://github.com/matyushkin/djvu-rs/issues/427) cache indexed JB2 mask + blit-map for FGbz-palette pages (~5%) ([2758b67](https://github.com/matyushkin/djvu-rs/commit/2758b671fffcd5a4d38afd4280027c0290b8179d))
* **render:** [#428](https://github.com/matyushkin/djvu-rs/issues/428) all-white band fast path in bilevel downscale compositor ([ca8c9dd](https://github.com/matyushkin/djvu-rs/commit/ca8c9dd2241470b7897fc909a43d7443eb17a0ed))
* **render:** [#433](https://github.com/matyushkin/djvu-rs/issues/433) generalize P2 BILEVEL_RGBA fast path to byte-aligned offset_x ([1f6bd49](https://github.com/matyushkin/djvu-rs/commit/1f6bd49e95a480f7cb15f93f0be6d6fdc806dbe2))
* **render:** byte-level POPCNT in mask_box_coverage (~24% at 72 DPI) ([4f3e902](https://github.com/matyushkin/djvu-rs/commit/4f3e9025865aacf9b6464f2e1fd3accb67a45c01))
* **render:** C3 mask-row hoist in general 1:1 bilinear path ([b4f77bb](https://github.com/matyushkin/djvu-rs/commit/b4f77bb831cf5c98bb04199a3e56e272fd9d24fd))
* **render:** cache BG44 decoded RGB Pixmap at sub=1 in PageLayers ([d24d83e](https://github.com/matyushkin/djvu-rs/commit/d24d83eb328df226656de6ec63f3a8eb7b98ad99))
* **render:** eliminate BG44 Pixmap clone via Cow&lt;'a, Pixmap&gt; ([9eb6c7b](https://github.com/matyushkin/djvu-rs/commit/9eb6c7b3e01f3543a1d694b8ed2e8f5b9fe5f9ad))
* **render:** eliminate FG44 + mask clones via Cow&lt;'a, …&gt; ([691b14c](https://github.com/matyushkin/djvu-rs/commit/691b14c109b023cbe552e20d3beb8cd557451a64))
* **render:** F2 all-bg row fast path in general 1:1 bilinear path ([195dfb1](https://github.com/matyushkin/djvu-rs/commit/195dfb103a6ce6ee9b9110780697f5176f04d578))
* **render:** G1 pre-expand mask row to bytes in general 1:1 bilinear path (~25%) ([84d4c18](https://github.com/matyushkin/djvu-rs/commit/84d4c187847717ac23cfc5ab02d582d2833f68a7))
* **render:** I3 all-white row fast path in bilevel 1:1 compositor ([53d6189](https://github.com/matyushkin/djvu-rs/commit/53d618980a67cb2e25fe59cf8bb7302c6f2782a2))
* **render:** inline alpha in bilinear compositor, remove fill_alpha_255 ([24461b3](https://github.com/matyushkin/djvu-rs/commit/24461b3d5e582f60de3b4d0fd09d791bb198e7fa))
* **render:** P2 BILEVEL_RGBA table for bilevel 1:1 compositor (~24%) ([57c8069](https://github.com/matyushkin/djvu-rs/commit/57c80693ce97b71d13829c3491d3cbded32a4614))
* **tiff:** [#430](https://github.com/matyushkin/djvu-rs/issues/430) Deflate-compressed bilevel TIFF export (~149x smaller) ([2d05853](https://github.com/matyushkin/djvu-rs/commit/2d058536e2c788c373db4039a1f8cf4aec1334a9))
* **tiff:** [#431](https://github.com/matyushkin/djvu-rs/issues/431) LUT byte-expansion in extract_bilevel_pixels (~18% bilevel export) ([908c2b5](https://github.com/matyushkin/djvu-rs/commit/908c2b5714edaccaa294b392d7ac3f02c2e14e6c))

## [0.20.4](https://github.com/matyushkin/djvu-rs/compare/v0.20.3...v0.20.4) (2026-06-21)


### Performance Improvements

* **render:** precompute area-average bounds and fuse downscale alpha writes (issue [#416](https://github.com/matyushkin/djvu-rs/issues/416))

## [0.20.3](https://github.com/matyushkin/djvu-rs/compare/v0.20.2...v0.20.3) (2026-06-18)


### Bug Fixes

* **render:** replace to_ne_bytes() with per-byte writes in bilevel compositor ([2ee62d4](https://github.com/matyushkin/djvu-rs/commit/2ee62d4f7d909e45821336ef04ba5c179d0a758e))
* **render:** use saturating_sub to avoid usize underflow in bilinear 1:1 path ([14de98c](https://github.com/matyushkin/djvu-rs/commit/14de98c0ce29a263658535f25e43433d87cebb82))
* resolve clippy warnings in WIP test additions ([a173164](https://github.com/matyushkin/djvu-rs/commit/a1731646671243b925455d6ef5398bd2e0ae5226))
* route raw IFF framing through iff::partial_emit in tests ([e718bd8](https://github.com/matyushkin/djvu-rs/commit/e718bd823c14f6f447e596a66738f89503239629))
* **text:** restore alloc String/ToString imports in no-std path ([1384ce4](https://github.com/matyushkin/djvu-rs/commit/1384ce4e9b04a5b587041a0d1ac4f07601b47dd5))


### Performance Improvements

* **render:** close 1.2–2.1× DjVuLibre gap (issue [#408](https://github.com/matyushkin/djvu-rs/issues/408)) ([ef7a676](https://github.com/matyushkin/djvu-rs/commit/ef7a6766ed5986bc8f19aa95c4635ba44b39396d))
* **render:** close 1.2–2.1× DjVuLibre gap (issue [#408](https://github.com/matyushkin/djvu-rs/issues/408)) ([5daf560](https://github.com/matyushkin/djvu-rs/commit/5daf56037126a00fe0e52aba43b11c4614534539))
* **render:** fix area-avg box bounds — −52% colorbook, −10% corpus color ([db84134](https://github.com/matyushkin/djvu-rs/commit/db841345542e736bf076a490cbe099e2085949e1))
* **render:** fix area-avg box bounds (inclusive→exclusive) + pow2 shift ([db84134](https://github.com/matyushkin/djvu-rs/commit/db841345542e736bf076a490cbe099e2085949e1))
* **render:** fix area-avg box bounds (inclusive→exclusive) + pow2 shift ([2e6e24d](https://github.com/matyushkin/djvu-rs/commit/2e6e24d3f181bb8cde29339eeeb70d74f89f17de))

## [0.20.2](https://github.com/matyushkin/djvu-rs/compare/v0.20.1...v0.20.2) (2026-06-17)


### Bug Fixes

* derive IW44 decode scale from native width, not display width ([5b111dc](https://github.com/matyushkin/djvu-rs/commit/5b111dc22c957e9eec5ef0ee06ac8341065829a6))

## [0.20.1](https://github.com/matyushkin/djvu-rs/compare/v0.20.0...v0.20.1) (2026-06-16)


### Bug Fixes

* **jb2:** accept valid pages whose large final symbol decodes at EOF ([2d55a7b](https://github.com/matyushkin/djvu-rs/commit/2d55a7b695f828db043f7f54787675e1b4afe2ef))
* **jb2:** accept valid pages whose large final symbol decodes at EOF ([c984927](https://github.com/matyushkin/djvu-rs/commit/c984927be605f5685e4a9b7f59835d128937e07e))

## [0.20.0](https://github.com/matyushkin/djvu-rs/compare/v0.19.1...v0.20.0) (2026-06-16)


### ⚠ BREAKING CHANGES

* **render:** `Page::render_aa` drops its ignored `_boldness` parameter, and six redundant `Page` render methods are deprecated in favor of `render_with` and `RenderOptions::fit_to_*`.

### Features

* **mut:** indirect DJVM rebundling + explicit external-file rewrite plan ([6df6e79](https://github.com/matyushkin/djvu-rs/commit/6df6e79a0252701e57c73f947008e83ef2e99b87))


### Bug Fixes

* **examples:** construct Jb2EncodeOptions with ..Default::default() ([cb864f7](https://github.com/matyushkin/djvu-rs/commit/cb864f786eb0d89d8733bcec50fc96e90caf81b4))
* **examples:** restore encode_quality_jb2 build after Jb2EncodeOptions gained a field ([7b4f8f2](https://github.com/matyushkin/djvu-rs/commit/7b4f8f2bfc62cc8adbec2957946a38cd3c430186))
* repair main CI — pyo3 advisory bump + broken jb2 example ([c1fc322](https://github.com/matyushkin/djvu-rs/commit/c1fc3229cb9d87b47c53e1c84895fcb385e19951))


### Code Refactoring

* **render:** shrink the Page render interface and seal internal duplication ([#346](https://github.com/matyushkin/djvu-rs/issues/346)) ([21fabd2](https://github.com/matyushkin/djvu-rs/commit/21fabd29ade6ff83830ed45ae226778902305507))

## [0.19.1](https://github.com/matyushkin/djvu-rs/compare/v0.19.0...v0.19.1) (2026-06-09)


### Bug Fixes

* **iw44:** decode all slices — drop ZP-exhaustion early-exit ([bd9b736](https://github.com/matyushkin/djvu-rs/commit/bd9b736dce1bdf0ef42030fefe62e2e79e8899d1))
* **iw44:** decode all slices — drop ZP-exhaustion early-exit in decode_chunk ([7365f26](https://github.com/matyushkin/djvu-rs/commit/7365f26227d2ecc7029b34f7168aaa30d834ad05))

## [0.19.0](https://github.com/matyushkin/djvu-rs/compare/v0.18.0...v0.19.0) (2026-05-17)


### Features

* **cli:** expose adaptive segmentation flags ([#317](https://github.com/matyushkin/djvu-rs/issues/317)) ([aee5450](https://github.com/matyushkin/djvu-rs/commit/aee5450690c224375f27d6376a5790e55c432890)), closes [#297](https://github.com/matyushkin/djvu-rs/issues/297)
* embed OCR text layers in DjVu output ([#315](https://github.com/matyushkin/djvu-rs/issues/315)) ([bfb9257](https://github.com/matyushkin/djvu-rs/commit/bfb9257b31d4eb4c70ebef0976d30333ecbeb73a))


### Performance Improvements

* **iw44:** record ARM64 NEON validation ([418d4fb](https://github.com/matyushkin/djvu-rs/commit/418d4fb06ac79518dc6a933c6386a9f02b3803fa))
* **iw44:** record rejected AVX2 row-pass spike ([5b6cdf3](https://github.com/matyushkin/djvu-rs/commit/5b6cdf38e6609949a74255604bb1e3a1dd08e289))
* **pdf:** record export memory baseline ([#318](https://github.com/matyushkin/djvu-rs/issues/318)) ([3b29f6b](https://github.com/matyushkin/djvu-rs/commit/3b29f6b119e363845d0d79ce2a8754f05b469277)), closes [#298](https://github.com/matyushkin/djvu-rs/issues/298)
* **pdf:** stream RGB staging for color pages ([#319](https://github.com/matyushkin/djvu-rs/issues/319)) ([445ed11](https://github.com/matyushkin/djvu-rs/commit/445ed11c2457bd563c10fd579052c93729b2d273)), closes [#299](https://github.com/matyushkin/djvu-rs/issues/299)

## [0.18.0](https://github.com/matyushkin/djvu-rs/compare/v0.17.0...v0.18.0) (2026-05-17)


### Features

* add archival FGbz scan profile ([#287](https://github.com/matyushkin/djvu-rs/issues/287)) ([6e0b850](https://github.com/matyushkin/djvu-rs/commit/6e0b8508689893e01124372ec6fac1dcfed423cd))
* emit per-blit FGbz color indices ([#291](https://github.com/matyushkin/djvu-rs/issues/291)) ([f9120c8](https://github.com/matyushkin/djvu-rs/commit/f9120c8cb132675b5dc0a45e1f378de8a718f076))
* **encode:** add adaptive segmentation options ([7b71793](https://github.com/matyushkin/djvu-rs/commit/7b71793bfa7c4378d22587da9fade166790979d4))
* **encode:** support layered directory bundles ([404054c](https://github.com/matyushkin/djvu-rs/commit/404054c4a848db1452f49d050492858da7b4be69))
* **ocr:** narrow experimental backends ([913e100](https://github.com/matyushkin/djvu-rs/commit/913e1001ac75078a49ee41e06e3b73cc5217d9f6))


### Bug Fixes

* **render:** reduce native colorbook diff ([63fe3dc](https://github.com/matyushkin/djvu-rs/commit/63fe3dc01064917d364647942d244d6773591c86))


### Performance Improvements

* add JB2 cross-size refinement probe ([#285](https://github.com/matyushkin/djvu-rs/issues/285)) ([a1805a9](https://github.com/matyushkin/djvu-rs/commit/a1805a990e71aa35a26f53c9ee87f1c932a9475d))
* **export:** stream TIFF color rendering ([4e3f955](https://github.com/matyushkin/djvu-rs/commit/4e3f9552010a13dd3aa4304a02367c10dda960cf))
* **render:** composite pixmap output directly ([39fbe27](https://github.com/matyushkin/djvu-rs/commit/39fbe27cd46792b7b69d4bfa808406c37bed3619))

## [0.17.0](https://github.com/matyushkin/djvu-rs/compare/v0.16.1...v0.17.0) (2026-05-04)


### Features

* add BZZ encoder with ZP arithmetic coding ([582432f](https://github.com/matyushkin/djvu-rs/commit/582432f601cf546c9404228af1541ec2067b503e))
* add fit_to_width/height/box to RenderOptions ([#33](https://github.com/matyushkin/djvu-rs/issues/33)) ([b371a93](https://github.com/matyushkin/djvu-rs/commit/b371a93099276cab573244cc262dc6ba093276cf))
* add NAVM bookmark encoder and ANTa/ANTz annotation encoder ([#133](https://github.com/matyushkin/djvu-rs/issues/133)) ([#136](https://github.com/matyushkin/djvu-rs/issues/136)) ([9e6bf66](https://github.com/matyushkin/djvu-rs/commit/9e6bf662125194fe57be02bed2ce42d87b8c16b7))
* **api:** bundled DJVM mutation + set_bookmarks (PR3 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#268](https://github.com/matyushkin/djvu-rs/issues/268)) ([6672a93](https://github.com/matyushkin/djvu-rs/commit/6672a936202f66b32e0e77dafdf467503547de6e))
* **api:** DjVuDocumentMut::from_bytes — chunk-replacement primitive (PR1 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#263](https://github.com/matyushkin/djvu-rs/issues/263)) ([b6279ae](https://github.com/matyushkin/djvu-rs/commit/b6279aed03de0eae42b1df7ee22da0bb56efaf08))
* **api:** high-level setters for DjVuDocumentMut (PR2 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#267](https://github.com/matyushkin/djvu-rs/issues/267)) ([eec0815](https://github.com/matyushkin/djvu-rs/commit/eec08153575052d81f71eb5382176816f1592aff))
* **api:** raw_chunk / all_chunks / chunk_ids on DjVuPage and DjVuDocument (Issue [#43](https://github.com/matyushkin/djvu-rs/issues/43)) ([#54](https://github.com/matyushkin/djvu-rs/issues/54)) ([3135627](https://github.com/matyushkin/djvu-rs/commit/31356279ad2739ae13ab36a144fbaabe5b5f63ab))
* **async:** add native lazy page loader ([735a226](https://github.com/matyushkin/djvu-rs/commit/735a22615ad91c89b2a38c865407a46319c46815))
* **async:** add wasm lazy reader entrypoint ([77fc6ff](https://github.com/matyushkin/djvu-rs/commit/77fc6ffecd57cb5760f9a7e75333987b3530c872))
* **async:** async render API via tokio::task::spawn_blocking (Issue [#51](https://github.com/matyushkin/djvu-rs/issues/51)) ([#61](https://github.com/matyushkin/djvu-rs/issues/61)) ([452636f](https://github.com/matyushkin/djvu-rs/commit/452636f143c56f4fc674968be5d5a4d8bd15d14a))
* **async:** load_document_async — buffered AsyncRead constructor ([#196](https://github.com/matyushkin/djvu-rs/issues/196) Phase 1) ([#231](https://github.com/matyushkin/djvu-rs/issues/231)) ([2d85e65](https://github.com/matyushkin/djvu-rs/commit/2d85e65e1963efb88bb86fe4b1b7e706228e910d))
* **async:** page_byte_range API + streaming async loader ([#196](https://github.com/matyushkin/djvu-rs/issues/196) Phase 2) ([#237](https://github.com/matyushkin/djvu-rs/issues/237)) ([a365abb](https://github.com/matyushkin/djvu-rs/commit/a365abb64b06a1c86de87e230623e05f465909e1))
* **async:** progressive stream render API (Issue [#81](https://github.com/matyushkin/djvu-rs/issues/81)) ([#112](https://github.com/matyushkin/djvu-rs/issues/112)) ([eaff91d](https://github.com/matyushkin/djvu-rs/commit/eaff91d5f5b8ccfa3cf86429339e7c21bcde5f72))
* **async:** resolve lazy shared dictionaries ([30d8ac9](https://github.com/matyushkin/djvu-rs/commit/30d8ac9f2a4be61c5e82b4bea5f1d8083d4bcd07))
* **bench:** add render_scaled and pdf_export benchmarks + BENCHMARKS.md (Issue [#52](https://github.com/matyushkin/djvu-rs/issues/52)) ([#62](https://github.com/matyushkin/djvu-rs/issues/62)) ([a8523c7](https://github.com/matyushkin/djvu-rs/commit/a8523c711c2fc3fc12d1089c5becf1b68af25595))
* **ci:** add ocr-tesseract integration test + CI job ([#178](https://github.com/matyushkin/djvu-rs/issues/178)) ([220671d](https://github.com/matyushkin/djvu-rs/commit/220671d0ae6d21f05a2a847945e062ae27eb931c))
* **ci:** continuous benchmark tracking — PR regression detection (Issue [#88](https://github.com/matyushkin/djvu-rs/issues/88)) ([#109](https://github.com/matyushkin/djvu-rs/issues/109)) ([0dfade5](https://github.com/matyushkin/djvu-rs/commit/0dfade5a8c4ec125bac50ff9deb5df37a159c56f))
* **cli:** implement djvu info/render/text — 24/24 tests green ([eb2e9d6](https://github.com/matyushkin/djvu-rs/commit/eb2e9d61f0a12285f9c6d7de4a4665b31f19a32a))
* **cli:** multi-page djvu encode from a directory of PNGs ([#223](https://github.com/matyushkin/djvu-rs/issues/223) follow-up) ([#245](https://github.com/matyushkin/djvu-rs/issues/245)) ([b8858bb](https://github.com/matyushkin/djvu-rs/commit/b8858bb36366be29441c17a06f0ea75daa4a210a))
* **cos-djvu:** benchmark suite, corpus infrastructure, BENCHMARKS.md (closes [#282](https://github.com/matyushkin/djvu-rs/issues/282)) ([#332](https://github.com/matyushkin/djvu-rs/issues/332)) ([50b6933](https://github.com/matyushkin/djvu-rs/commit/50b69330c73e5883a2954fe646f2cc7b7ec4e654))
* **cos-djvu:** phase 1 — IFF parser, typed errors, MIT skeleton (closes [#267](https://github.com/matyushkin/djvu-rs/issues/267)) ([#277](https://github.com/matyushkin/djvu-rs/issues/277)) ([1943f3f](https://github.com/matyushkin/djvu-rs/commit/1943f3f1cbef880038065ea377ccdfdff4ee33d0))
* **cos-djvu:** phase 2a — ZP arithmetic coder + BZZ decompressor (closes [#268](https://github.com/matyushkin/djvu-rs/issues/268)) ([#279](https://github.com/matyushkin/djvu-rs/issues/279)) ([4983056](https://github.com/matyushkin/djvu-rs/commit/498305678a0d13947e6fe5473d2bc6250383595d))
* **cos-djvu:** phase-5 rendering pipeline — compositing, gamma, scaling, AA (closes [#273](https://github.com/matyushkin/djvu-rs/issues/273)) ([7f5e161](https://github.com/matyushkin/djvu-rs/commit/7f5e161dd7f13c94ed1fb680966416e339eb80d5))
* **cos-djvu:** phase-6 quality — fuzz targets, benchmarks, no_std, full docs (closes [#274](https://github.com/matyushkin/djvu-rs/issues/274)) ([#324](https://github.com/matyushkin/djvu-rs/issues/324)) ([67fab7f](https://github.com/matyushkin/djvu-rs/commit/67fab7fdce945d972c574f61f9e460c32998a189))
* **cos-djvu:** text layer + annotations extraction (closes [#272](https://github.com/matyushkin/djvu-rs/issues/272)) ([#316](https://github.com/matyushkin/djvu-rs/issues/316)) ([5beeba9](https://github.com/matyushkin/djvu-rs/commit/5beeba96034a55396769d044ff1c20f20dc379a6))
* **djvm:** add merge and split commands for DjVu documents ([#126](https://github.com/matyushkin/djvu-rs/issues/126)) ([37eefd8](https://github.com/matyushkin/djvu-rs/commit/37eefd89f969ade36e3547fce0222a9d23d9c215)), closes [#76](https://github.com/matyushkin/djvu-rs/issues/76)
* djvu render --format pdf|cbz, roadmap v0.1 finalised ([7d823f6](https://github.com/matyushkin/djvu-rs/commit/7d823f634a1efbc75f743d5d5a8a4f6056e0b0a0))
* DjVu to PDF converter with text, bookmarks, and hyperlinks ([#2](https://github.com/matyushkin/djvu-rs/issues/2)-[#6](https://github.com/matyushkin/djvu-rs/issues/6)) ([#29](https://github.com/matyushkin/djvu-rs/issues/29)) ([a6f0a74](https://github.com/matyushkin/djvu-rs/commit/a6f0a7486d85146e677ae094396e96b44675e894))
* **djvu-enc:** high-level PageEncoder for bilevel Lossless ([#218](https://github.com/matyushkin/djvu-rs/issues/218)) ([#243](https://github.com/matyushkin/djvu-rs/issues/243)) ([afefcef](https://github.com/matyushkin/djvu-rs/commit/afefcef00cb2026772b4b22eb896c5533f87b844))
* **djvu-enc:** minimal layered Quality (segment → Sjbz + BG44) ([#246](https://github.com/matyushkin/djvu-rs/issues/246)) ([2febd04](https://github.com/matyushkin/djvu-rs/commit/2febd0486b839d800390e0abc1729965f02ad66c))
* document model — DjVuDocument, Page, DIRM, NAVM (closes [#271](https://github.com/matyushkin/djvu-rs/issues/271)) ([#283](https://github.com/matyushkin/djvu-rs/issues/283)) ([e36fd41](https://github.com/matyushkin/djvu-rs/commit/e36fd4169b591cb5f4146fc58bd3aaacf464d82b))
* **epub:** DPI-aware rendering, language tag, hyperlinks, cover image ([191e386](https://github.com/matyushkin/djvu-rs/commit/191e3869623a091998d75761f9be30d75c9576a8))
* **epub:** EPUB 3 export — page images, text overlay, navigation (Issue [#74](https://github.com/matyushkin/djvu-rs/issues/74)) ([9a6d155](https://github.com/matyushkin/djvu-rs/commit/9a6d1555c43041b86a783c5967a55607e0090768))
* **epub:** opt-in reflowable text section per page ([#228](https://github.com/matyushkin/djvu-rs/issues/228)) ([#240](https://github.com/matyushkin/djvu-rs/issues/240)) ([8207fb9](https://github.com/matyushkin/djvu-rs/commit/8207fb9e3046f594e5fb13150fa2d1220c5b35cf))
* **ffi:** add C FFI bindings via extern "C" functions ([#127](https://github.com/matyushkin/djvu-rs/issues/127)) ([2226bdf](https://github.com/matyushkin/djvu-rs/commit/2226bdfad34ef39a08bb9a3b1b220cac2942b30a)), closes [#72](https://github.com/matyushkin/djvu-rs/issues/72)
* **fgbz-enc:** FGbz foreground palette encoder ([#217](https://github.com/matyushkin/djvu-rs/issues/217)) ([#241](https://github.com/matyushkin/djvu-rs/issues/241)) ([e43bc9f](https://github.com/matyushkin/djvu-rs/commit/e43bc9f81ed3bc5e3cfaf5fa249c651749583a36))
* **fuzz:** add render to fuzz_full, add CI fuzz workflow (60 s/target) ([7e3e4eb](https://github.com/matyushkin/djvu-rs/commit/7e3e4eb0d51404d0c460b71ac5a359d4eac6da8b))
* hOCR and ALTO XML export for text layer (Issue [#75](https://github.com/matyushkin/djvu-rs/issues/75)) ([#98](https://github.com/matyushkin/djvu-rs/issues/98)) ([263cf14](https://github.com/matyushkin/djvu-rs/commit/263cf1492b57caa2b1d986a7eec8fd4a6cc8305b))
* implement ImageDecoder trait for image-rs integration (Issue [#80](https://github.com/matyushkin/djvu-rs/issues/80)) ([#97](https://github.com/matyushkin/djvu-rs/issues/97)) ([d7e4a64](https://github.com/matyushkin/djvu-rs/commit/d7e4a64e427454f4353f5124d1d03ba4ae31fe8c))
* import cos-djvu history, remove GPL legacy code ([0f33110](https://github.com/matyushkin/djvu-rs/commit/0f33110d1846e7114c6a46726c9e088cbef25bea))
* indirect DJVM — create_indirect() and parse_from_dir() ([#135](https://github.com/matyushkin/djvu-rs/issues/135)) ([#137](https://github.com/matyushkin/djvu-rs/issues/137)) ([d7fbf74](https://github.com/matyushkin/djvu-rs/commit/d7fbf74e45b9f5a85d0f162796709126131ab8a0))
* IW44 wavelet decoder with planar YCbCr (closes [#270](https://github.com/matyushkin/djvu-rs/issues/270)) ([#281](https://github.com/matyushkin/djvu-rs/issues/281)) ([f799e70](https://github.com/matyushkin/djvu-rs/commit/f799e7098dfbffdabada8e0c19fea2e31cdac351))
* IW44 wavelet encoder — BG44/FG44 chunk encoding (issue [#131](https://github.com/matyushkin/djvu-rs/issues/131)) ([#139](https://github.com/matyushkin/djvu-rs/issues/139)) ([10adc4f](https://github.com/matyushkin/djvu-rs/commit/10adc4f61bf8a79f9c4ba74559fb004b31d8968c))
* JB2 bilevel decoder (closes [#269](https://github.com/matyushkin/djvu-rs/issues/269)) ([#280](https://github.com/matyushkin/djvu-rs/issues/280)) ([e2a6898](https://github.com/matyushkin/djvu-rs/commit/e2a6898618765fe96a07ddaac51a40b665b64efb))
* JB2 bilevel image encoder — Sjbz chunk encoding (issue [#132](https://github.com/matyushkin/djvu-rs/issues/132)) ([#140](https://github.com/matyushkin/djvu-rs/issues/140)) ([cf280ba](https://github.com/matyushkin/djvu-rs/commit/cf280ba6e1356f1d8f7498c84c57e2759f603b3c))
* **jb2-enc:** expose tunable shared-Djbz clustering + corpus harness ([#194](https://github.com/matyushkin/djvu-rs/issues/194) Phase 2) ([#219](https://github.com/matyushkin/djvu-rs/issues/219)) ([9aafe42](https://github.com/matyushkin/djvu-rs/commit/9aafe42f04b6d474fefa0bbc73f06b4c666c9d1f))
* **jb2-enc:** multi-page shared Djbz dictionary in DJVM bundle, Phase 1 ([#194](https://github.com/matyushkin/djvu-rs/issues/194)) ([#216](https://github.com/matyushkin/djvu-rs/issues/216)) ([507b061](https://github.com/matyushkin/djvu-rs/commit/507b0618b27dc6619ce33736d01a9e920f2fdb32))
* **jb2-enc:** symbol-dictionary encoder Phases 1-3 ([#188](https://github.com/matyushkin/djvu-rs/issues/188)) ([#213](https://github.com/matyushkin/djvu-rs/issues/213)) ([8a2ed15](https://github.com/matyushkin/djvu-rs/commit/8a2ed150ad86bde2d0305c0b18e1297523590ce2))
* **jb2:** DJVI shared dictionary support via INCL chunks (Issue [#45](https://github.com/matyushkin/djvu-rs/issues/45)) ([#56](https://github.com/matyushkin/djvu-rs/issues/56)) ([86a63cb](https://github.com/matyushkin/djvu-rs/commit/86a63cb975303c14159340da4718ed3e23182e3e))
* mask and foreground/background layer extraction API ([#36](https://github.com/matyushkin/djvu-rs/issues/36)) ([d4c6527](https://github.com/matyushkin/djvu-rs/commit/d4c6527eb03aa9397a681ccdf03a27cf9ed77b0b))
* **mask:** wire Smmr (G4/MMR) decoder into both render pipelines ([07272b3](https://github.com/matyushkin/djvu-rs/commit/07272b32f44da9b4382bd9f1d4ff7828ce6223d3))
* **metadata:** METa/METz document metadata parsing (Issue [#44](https://github.com/matyushkin/djvu-rs/issues/44)) ([#55](https://github.com/matyushkin/djvu-rs/issues/55)) ([eb4515b](https://github.com/matyushkin/djvu-rs/commit/eb4515b49819c3b75824738989c07153a7c2c0d6))
* **mmap:** add memory-mapped I/O via MmapDocument ([387a2ea](https://github.com/matyushkin/djvu-rs/commit/387a2ea40696d88906dc5ead848154cf42189c6a)), closes [#70](https://github.com/matyushkin/djvu-rs/issues/70)
* **ocr:** pluggable OCR backend trait with Tesseract, ONNX, and Candle backends ([#125](https://github.com/matyushkin/djvu-rs/issues/125)) ([bf26603](https://github.com/matyushkin/djvu-rs/commit/bf26603b714d1721f63beedcf2ad54a5f95e21a0)), closes [#77](https://github.com/matyushkin/djvu-rs/issues/77)
* **pdf:** DCTDecode background encoding — smaller PDF output (Issue [#49](https://github.com/matyushkin/djvu-rs/issues/49)) ([#59](https://github.com/matyushkin/djvu-rs/issues/59)) ([de90a9f](https://github.com/matyushkin/djvu-rs/commit/de90a9fd94ef98fdeb8822aef174e945ebe5a3ea))
* **pdf:** parallel page rendering with rayon ([#148](https://github.com/matyushkin/djvu-rs/issues/148)) ([ae79a7c](https://github.com/matyushkin/djvu-rs/commit/ae79a7c6539fd2173885b18aa4e3beb7146b70b4))
* progressive DjVu rendering, multi-book cache, cos-diagnostics crate ([32432d8](https://github.com/matyushkin/djvu-rs/commit/32432d8c240f4a4673310a70158cf12cb9643635))
* **python:** add Python bindings via PyO3 ([#128](https://github.com/matyushkin/djvu-rs/issues/128)) ([e250fff](https://github.com/matyushkin/djvu-rs/commit/e250fffcef36531d8641e1ab8031198c30c7d372)), closes [#71](https://github.com/matyushkin/djvu-rs/issues/71)
* **render:** add rayon-based parallel page rendering ([3dc06f9](https://github.com/matyushkin/djvu-rs/commit/3dc06f991d7e26099ea4623580ebded7022f8775)), closes [#69](https://github.com/matyushkin/djvu-rs/issues/69)
* **render:** BGjp/FGjp JPEG background/foreground decoder (Issue [#47](https://github.com/matyushkin/djvu-rs/issues/47)) ([#57](https://github.com/matyushkin/djvu-rs/issues/57)) ([b65bd81](https://github.com/matyushkin/djvu-rs/commit/b65bd817270c21248aa3ec46b140b6fb97a9b683))
* **render:** grayscale output mode — GrayPixmap + render_gray8 ([c13ebb7](https://github.com/matyushkin/djvu-rs/commit/c13ebb75ffa0673e670530bdd7ebe53f311a5044))
* **render:** grayscale output mode — GrayPixmap + render_gray8 (Issue [#15](https://github.com/matyushkin/djvu-rs/issues/15)) ([75d7b37](https://github.com/matyushkin/djvu-rs/commit/75d7b37aed6ce0a6d4d118abc8050b731089a8bf))
* **render:** Lanczos-3 separable resampling (Issue [#50](https://github.com/matyushkin/djvu-rs/issues/50)) ([#60](https://github.com/matyushkin/djvu-rs/issues/60)) ([56817d1](https://github.com/matyushkin/djvu-rs/commit/56817d162a335fe9597d2e65f84e0778ee147c65))
* **render:** permissive render mode — skip corrupted chunks ([dc5734a](https://github.com/matyushkin/djvu-rs/commit/dc5734a088f82b6c5bf7b6cfc06a599a2f342a2b))
* **render:** permissive render mode — skip corrupted chunks (Issue [#19](https://github.com/matyushkin/djvu-rs/issues/19)) ([df5a8d7](https://github.com/matyushkin/djvu-rs/commit/df5a8d715ba8534856d50f570752b8722118c2a0))
* **render:** public render_streaming API (Phase 2 of [#225](https://github.com/matyushkin/djvu-rs/issues/225)) ([#260](https://github.com/matyushkin/djvu-rs/issues/260)) ([b92fac7](https://github.com/matyushkin/djvu-rs/commit/b92fac7c962c57115673eb31b6f84a5e7b36c085))
* **render:** zero-copy region render — render_region API (Issue [#86](https://github.com/matyushkin/djvu-rs/issues/86)) ([#111](https://github.com/matyushkin/djvu-rs/issues/111)) ([b2aa2a8](https://github.com/matyushkin/djvu-rs/commit/b2aa2a860dc28a63409785af8ef2be55cca40a11))
* **segment + cli:** FG/BG segmentation v1 + djvu encode subcommand ([#220](https://github.com/matyushkin/djvu-rs/issues/220), [#223](https://github.com/matyushkin/djvu-rs/issues/223)) ([#244](https://github.com/matyushkin/djvu-rs/issues/244)) ([4945b06](https://github.com/matyushkin/djvu-rs/commit/4945b0670938f4623e5368c14aa5ba41a0b107a5))
* serde support for metadata, annotations, bookmarks, and text zones (Issue [#82](https://github.com/matyushkin/djvu-rs/issues/82)) ([#96](https://github.com/matyushkin/djvu-rs/issues/96)) ([e872ecd](https://github.com/matyushkin/djvu-rs/commit/e872ecdefbee38e0862c899da3955c2ee98ca233))
* **smmr-enc:** public Smmr (G4/MMR) encoder API ([#221](https://github.com/matyushkin/djvu-rs/issues/221)) ([#242](https://github.com/matyushkin/djvu-rs/issues/242)) ([009c706](https://github.com/matyushkin/djvu-rs/commit/009c70681eb9c34992ed8a438343638a694cd98b))
* **smmr:** add G4/MMR bilevel image decoder (issue [#134](https://github.com/matyushkin/djvu-rs/issues/134)) ([#138](https://github.com/matyushkin/djvu-rs/issues/138)) ([8bd6e41](https://github.com/matyushkin/djvu-rs/commit/8bd6e4157c885e7a03c0443657d294099fbe7619))
* **text:** add reflowable_text() for paragraph reading-order extraction ([#228](https://github.com/matyushkin/djvu-rs/issues/228)) ([#239](https://github.com/matyushkin/djvu-rs/issues/239)) ([221a49a](https://github.com/matyushkin/djvu-rs/commit/221a49a1c066bdef59d5dcabc26961e8d6283752))
* **text:** TextLayer::transform — rotate + scale zone rects for rendered pages (Issue [#46](https://github.com/matyushkin/djvu-rs/issues/46)) ([#53](https://github.com/matyushkin/djvu-rs/issues/53)) ([c4a514e](https://github.com/matyushkin/djvu-rs/commit/c4a514e8bbdd4bccdb0032130b949580ef5306cc))
* **tiff:** embed DPI resolution tags in exported TIFF files ([87efb14](https://github.com/matyushkin/djvu-rs/commit/87efb140cc603a3ad4bd0f13b5e7a12c995ca516))
* **tiff:** TIFF export — multi-page color and bilevel modes (Issue [#48](https://github.com/matyushkin/djvu-rs/issues/48)) ([#58](https://github.com/matyushkin/djvu-rs/issues/58)) ([dc90cc0](https://github.com/matyushkin/djvu-rs/commit/dc90cc049ee7bd299ce6156c9c390c8616bdabca))
* transfer from cos-djvu, remove legacy GPL code, add PD corpus, benchmarks ([33fd496](https://github.com/matyushkin/djvu-rs/commit/33fd4969a691b5445c708b6c5f1ae2f877304f73))
* **ui:** table of contents navigation panel (closes [#60](https://github.com/matyushkin/djvu-rs/issues/60)) ([#298](https://github.com/matyushkin/djvu-rs/issues/298)) ([3fb0b2a](https://github.com/matyushkin/djvu-rs/commit/3fb0b2a94ff19891d6469f95aa381dcf66b7b712))
* user-controllable rotation in RenderOptions ([#35](https://github.com/matyushkin/djvu-rs/issues/35)) ([e0f79a8](https://github.com/matyushkin/djvu-rs/commit/e0f79a80bd3d3b2cc43933debb9a0b290aaea285))
* **wasm:** add WasmPage::text_zones_json() — text selection overlay API ([e513bbf](https://github.com/matyushkin/djvu-rs/commit/e513bbfc4052161f0b61f0c2cc429c58869d7170)), closes [#119](https://github.com/matyushkin/djvu-rs/issues/119)
* **wasm:** add WasmPage::text() — expose page text layer to JS ([35a776d](https://github.com/matyushkin/djvu-rs/commit/35a776d16804b39e1ae8cfddbf18073e4711204c))
* **wasm:** progressive IW44 render API ([#150](https://github.com/matyushkin/djvu-rs/issues/150)) ([35d3a30](https://github.com/matyushkin/djvu-rs/commit/35d3a30d285fd699781d9c4e5373b584b29f544d))
* **wasm:** WebAssembly bindings via wasm-bindgen (Issue [#73](https://github.com/matyushkin/djvu-rs/issues/73)) ([#118](https://github.com/matyushkin/djvu-rs/issues/118)) ([4300939](https://github.com/matyushkin/djvu-rs/commit/4300939b9085725005f7ce0a62d4e34f836367ff))


### Bug Fixes

* add missing chunk_data binding in iw44_new doctest ([d1a210b](https://github.com/matyushkin/djvu-rs/commit/d1a210b8b61fabc5c7634282f0bfb8062503dfa3))
* **annotation:** add MAX_SEXPR_DEPTH=64 guard to prevent stack overflow on deeply nested S-expressions ([#200](https://github.com/matyushkin/djvu-rs/issues/200)) ([2f03789](https://github.com/matyushkin/djvu-rs/commit/2f03789638a65f9ac2e6c7cf5763f63ec9a3a0f6))
* apply gamma correction in all legacy render paths ([#9](https://github.com/matyushkin/djvu-rs/issues/9)) ([#22](https://github.com/matyushkin/djvu-rs/issues/22)) ([dfba614](https://github.com/matyushkin/djvu-rs/commit/dfba614c510d8da150ee76cf62f629f89cff48bc))
* apply page rotation from INFO chunk in render_pixmap and render_coarse ([#10](https://github.com/matyushkin/djvu-rs/issues/10)) ([#24](https://github.com/matyushkin/djvu-rs/issues/24)) ([adec5ee](https://github.com/matyushkin/djvu-rs/commit/adec5eed27bf5f096bad4187a2d88a5349bd07a4))
* **ci:** enable cli feature for nextest to build djvu binary ([576f12f](https://github.com/matyushkin/djvu-rs/commit/576f12faf154662a3992ac3a20c3c126e32fc798))
* **ci:** exclude djvu-py from nextest, fix audit advisories ([788b0d3](https://github.com/matyushkin/djvu-rs/commit/788b0d39fc04d1ed28dc5052f2bc88004f106117))
* **ci:** exclude fuzz/ from workspace to fix cargo-fuzz builds ([330ff0a](https://github.com/matyushkin/djvu-rs/commit/330ff0a28a601629718cf0c12d4e90ab93524621))
* **ci:** IJG license allowlist, no_std BTreeMap, clippy errors ([6a2a391](https://github.com/matyushkin/djvu-rs/commit/6a2a39199dffd1aa60cbe916bd2b28a516185dcd))
* **ci:** install libleptonica-dev + libtesseract-dev for ocr-tesseract job ([0410f70](https://github.com/matyushkin/djvu-rs/commit/0410f70f0ed73be0425906685c3af1e0b6397374))
* **ci:** split test into test-stable + test-beta jobs (matrix.rust not allowed in job if) ([0d60c76](https://github.com/matyushkin/djvu-rs/commit/0d60c7662a78bff90dad81d9847e07d93dfb3b15))
* **ci:** use core::mem::take in no_std context; fix clippy redundant-Some in ocr_export test ([#101](https://github.com/matyushkin/djvu-rs/issues/101)) ([cc1cdf1](https://github.com/matyushkin/djvu-rs/commit/cc1cdf136e4eaaf9311170a20cd1f3b5ffd4ce54))
* clippy errors and fmt — let-chain, ref on let, line wrapping ([b4ba2f8](https://github.com/matyushkin/djvu-rs/commit/b4ba2f87acc234e7b7467f394169775b846c03b5))
* **clippy:** use `contains()` instead of `iter().any()` in tiff_export ([f9b4c2b](https://github.com/matyushkin/djvu-rs/commit/f9b4c2b7b9ad3aadbc9539aec09ef651f5545312))
* **docs:** resolve all remaining broken intra-doc links (0 warnings) ([4ac8bb1](https://github.com/matyushkin/djvu-rs/commit/4ac8bb162d922529ac4e58757155d556fbe3e7fc))
* **docs:** resolve broken intra-doc links in djvu_document ([8dbfda0](https://github.com/matyushkin/djvu-rs/commit/8dbfda050a72df34dbe3f149427aec4a6e4252a9))
* eliminate memory leaks and add OOM protection ([25f041d](https://github.com/matyushkin/djvu-rs/commit/25f041d78c513f1e3dfbd87aa69dc4fc261488da))
* exclude .cargo/config.toml from published package (fixes docs.rs build) ([b9dd0da](https://github.com/matyushkin/djvu-rs/commit/b9dd0dafac62f0d6e12064f431d6b962b6a93e08))
* FGbz multi-color foreground palette — use per-glyph blit index ([#12](https://github.com/matyushkin/djvu-rs/issues/12)) ([#26](https://github.com/matyushkin/djvu-rs/issues/26)) ([7897164](https://github.com/matyushkin/djvu-rs/commit/789716408799e39c0e78e3caeedb051f913d26ac))
* **fuzz:** add [workspace] to fuzz/Cargo.toml to fix cargo-fuzz build ([be7a5a8](https://github.com/matyushkin/djvu-rs/commit/be7a5a80d23ca77c6c326c1c9065e1498ab41b5d))
* **fuzz:** revert to cargo install cargo-fuzz, add explicit binary cache ([84e6eef](https://github.com/matyushkin/djvu-rs/commit/84e6eef4b18c6f957f327d34fc2f87ab560a5f3c))
* **fuzz:** use correct public module djvu_rs::jb2 in fuzz_jb2 target ([9133de6](https://github.com/matyushkin/djvu-rs/commit/9133de69f3af8ee05f2c8f9239efcf87e2ed0a76))
* **hard-rule:** eliminate last 5 .expect()/.unwrap() in production code (Issue [#443](https://github.com/matyushkin/djvu-rs/issues/443)) ([#444](https://github.com/matyushkin/djvu-rs/issues/444)) ([e4247ea](https://github.com/matyushkin/djvu-rs/commit/e4247eafc1eabadfac42fb04c318252ac0ebcc71))
* **iff:** preserve FORM length parity for byte-identical mutation (PR4 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#269](https://github.com/matyushkin/djvu-rs/issues/269)) ([df1e95e](https://github.com/matyushkin/djvu-rs/commit/df1e95e51c08ebe4e85cb1899352aae0cf5a5692))
* **iw44:** correct vext lane in prelim_flags_band0_neon horizontal-OR ([#266](https://github.com/matyushkin/djvu-rs/issues/266)) ([b390681](https://github.com/matyushkin/djvu-rs/commit/b3906813dbe4d4c9946c93b9b9e6884c1da62efc))
* **jb2_encode:** return empty Vec for zero-dimension bitmaps; unreachable dead branch ([#142](https://github.com/matyushkin/djvu-rs/issues/142)) ([#143](https://github.com/matyushkin/djvu-rs/issues/143)) ([091b657](https://github.com/matyushkin/djvu-rs/commit/091b6573467c67c3c8d487ee82dba24b7c59f136))
* **jb2-enc:** cap cluster_shared_symbols pixel budget at decoder limit ([#270](https://github.com/matyushkin/djvu-rs/issues/270)) ([#271](https://github.com/matyushkin/djvu-rs/issues/271)) ([78e5c79](https://github.com/matyushkin/djvu-rs/commit/78e5c793d3d7a86512e42820d8e3cf0c9870c48e))
* **jb2-enc:** tile direct encoder to ≤1MP records ([#198](https://github.com/matyushkin/djvu-rs/issues/198)) ([#214](https://github.com/matyushkin/djvu-rs/issues/214)) ([24ac60f](https://github.com/matyushkin/djvu-rs/commit/24ac60fce1c139a8b55a3d30e71a7c36cac5d6d8))
* **jb2,iw44:** cap comment bytes and IW44 pixel limit to prevent fuzz timeouts ([49c7b1b](https://github.com/matyushkin/djvu-rs/commit/49c7b1bd29505528d53b70e7ab820e5a9c0eae2e))
* **jb2,iw44:** prevent DoS via refinement bitmaps and uncapped total pixel budget ([3e72cf6](https://github.com/matyushkin/djvu-rs/commit/3e72cf6c33d21661db1198013d789217d8978580))
* **jb2:** add blit-pixel budget to prevent type-7 dict-copy DoS ([1c03505](https://github.com/matyushkin/djvu-rs/commit/1c0350543b870c3b29fe87c1b59370410ba5e464))
* **jb2:** cap decode loop at 1 M records to prevent infinite spin on exhausted ZP input ([0b84f2d](https://github.com/matyushkin/djvu-rs/commit/0b84f2dcadaf4cbbae75bd2e53cb82f7f99d4f2d))
* **jb2:** correct regression test comment for fuzz2 fix ([ee380ae](https://github.com/matyushkin/djvu-rs/commit/ee380ae87d3f589627182b5a1350ae76072eb901))
* **jb2:** guard blit against negative symbol dimensions ([49a3792](https://github.com/matyushkin/djvu-rs/commit/49a3792c764e25594165a10b127612a446d7a732))
* **jb2:** guard blit fast path against i32 overflow and data buffer overread ([be72d29](https://github.com/matyushkin/djvu-rs/commit/be72d29584170afb0f12a951c10d3f24859ae02f))
* **jb2:** limit symbol bitmap size to 4 MP to prevent DoS via crafted input ([943f25e](https://github.com/matyushkin/djvu-rs/commit/943f25eaacc7c91234caea2e99ff87950f7d632f))
* **jb2:** prevent infinite loop in decode_num on corrupt streams ([d7bee1e](https://github.com/matyushkin/djvu-rs/commit/d7bee1e8c8c612583a055d40c4aa7a8c81666e47)), closes [#122](https://github.com/matyushkin/djvu-rs/issues/122)
* **jb2:** reduce MAX_RECORDS and MAX_SYMBOL_PIXELS to prevent fuzz timeouts ([3292193](https://github.com/matyushkin/djvu-rs/commit/3292193237d733976ea24c879ade958b1021caaa))
* **ocr:** resolve all clippy errors in ocr_neural, ocr_onnx, ocr_tesseract ([65a0cee](https://github.com/matyushkin/djvu-rs/commit/65a0cee338411a608c0c8a92d02c3638cb18c153))
* **pdf:** Unicode-aware glyph width for invisible text layer ([2398c38](https://github.com/matyushkin/djvu-rs/commit/2398c3851d8cef9c5a2b41dbcdaf5352baf9575a))
* remove deprecated [[licenses.deny]] syntax from deny.toml (cargo-deny v2) ([7971e44](https://github.com/matyushkin/djvu-rs/commit/7971e448cdeb82d8be78910e9f275ecc1b975d65))
* **render:** add #[allow(unsafe_code)] + unsafe blocks for Rust 2024 SIMD ([#169](https://github.com/matyushkin/djvu-rs/issues/169)) ([179d171](https://github.com/matyushkin/djvu-rs/commit/179d17132c31b5ec31eaa99156acc4ac4cdda1f6))
* **render:** correct gamma LUT formula to match DjVuLibre ([#161](https://github.com/matyushkin/djvu-rs/issues/161)) ([cd3228d](https://github.com/matyushkin/djvu-rs/commit/cd3228d812e77f6d9bdcc48e1d9a92f8ff34077e))
* **render:** resolve unsafe_code / unsafe_op_in_unsafe_fn CI conflicts ([889f28f](https://github.com/matyushkin/djvu-rs/commit/889f28fb67c5b13c8f5b4a66ae32b1546a498988))
* **render:** restore bilevel composite fast path, recover 2× regression from [#165](https://github.com/matyushkin/djvu-rs/issues/165) ([46b6931](https://github.com/matyushkin/djvu-rs/commit/46b69318d0e1181d4eec5d9fc428cc5eee9723f6))
* **render:** scale page-space coords into FG44 + BG plane space ([#199](https://github.com/matyushkin/djvu-rs/issues/199)) ([#248](https://github.com/matyushkin/djvu-rs/issues/248)) ([e2c07df](https://github.com/matyushkin/djvu-rs/commit/e2c07df45d5cfbc1edbef07553549e4fbf0fd2fc))
* **render:** use core::arch instead of std::arch for no_std compatibility ([122b989](https://github.com/matyushkin/djvu-rs/commit/122b989708e475658a764b2b145a887605590e37))
* replace all internal cos-djvu/cos_djvu references with djvu-rs/djvu_rs ([03fb17a](https://github.com/matyushkin/djvu-rs/commit/03fb17ae4460ca6baff50235993c6f005ddc08e4))
* resolve issues [#164](https://github.com/matyushkin/djvu-rs/issues/164) [#169](https://github.com/matyushkin/djvu-rs/issues/169) [#170](https://github.com/matyushkin/djvu-rs/issues/170) [#174](https://github.com/matyushkin/djvu-rs/issues/174) [#176](https://github.com/matyushkin/djvu-rs/issues/176) [#177](https://github.com/matyushkin/djvu-rs/issues/177) ([774cbdb](https://github.com/matyushkin/djvu-rs/commit/774cbdb834c703c27ca82ed9f8f3bb4a17504aeb))
* **smmr:** replace manual div_ceil with .div_ceil() per clippy ([a8d24ca](https://github.com/matyushkin/djvu-rs/commit/a8d24ca5fa470e9f9c59bee7ef7a605786a8fe79))
* update MSRV to 1.88 (let-chains stabilized in 1.88) ([8d5b94f](https://github.com/matyushkin/djvu-rs/commit/8d5b94f9d84c9065662e2464003aa75a95613421))
* update tesseract API and optimize JB2 inner loop ([f64d884](https://github.com/matyushkin/djvu-rs/commit/f64d88423aff0d4861a6dd50c1ec7a4c45e1d10b))
* vendor djvu-rs into crates/cos-djvu and fix production panics ([5f6d7fe](https://github.com/matyushkin/djvu-rs/commit/5f6d7fecadb7ea3bdcfa5cd530215ff28ea5e133)), closes [#4](https://github.com/matyushkin/djvu-rs/issues/4)
* wasm CI job, open_dir API, DPI scaling in OCR export, jb2_new cleanup ([6cbe038](https://github.com/matyushkin/djvu-rs/commit/6cbe038909858f4c523f13d7204998a7109cd84d))
* **wasm:** correct render() pixel layout and Uint8ClampedArray allocation ([1a967d2](https://github.com/matyushkin/djvu-rs/commit/1a967d2003bb74f0e42bccc8f108b2f1303617c1))
* **zp:** widen a/c/fence fields from u16 to u32 to match jb2 inline decoder ([fb0db12](https://github.com/matyushkin/djvu-rs/commit/fb0db122daa4dccd97f49a971103de0add5a2366))


### Performance Improvements

* allow 1.5× upscale in IW44 subsample selection for faster downscaled renders ([8f0baa2](https://github.com/matyushkin/djvu-rs/commit/8f0baa2a06eadce23974d973b7ee635b5939a5f0))
* area-averaging downscale for better quality when rendering at reduced size ([#13](https://github.com/matyushkin/djvu-rs/issues/13)) ([#28](https://github.com/matyushkin/djvu-rs/issues/28)) ([b822ded](https://github.com/matyushkin/djvu-rs/commit/b822ded71372b0f70071f8245768d09b89e62a17))
* **bitmap:** packed bitwise dilation with ping-pong buffers ([2887689](https://github.com/matyushkin/djvu-rs/commit/288768968e910eccfe313785aa316ef8eb0fbdac))
* **bitmap:** packed bitwise dilation with ping-pong buffers (Issue [#17](https://github.com/matyushkin/djvu-rs/issues/17)) ([0814f55](https://github.com/matyushkin/djvu-rs/commit/0814f5519475073c4b426ca91360491c8ad69830))
* **bzz:** inline ZP state locals in MTF decode hot loop ([bad5b21](https://github.com/matyushkin/djvu-rs/commit/bad5b215bfa5384589f2252b3da2ee0ecb9a3ac2))
* **bzz:** parallel inverse-BWT via rayon (Issue [#89](https://github.com/matyushkin/djvu-rs/issues/89)) ([#110](https://github.com/matyushkin/djvu-rs/issues/110)) ([eb5bab0](https://github.com/matyushkin/djvu-rs/commit/eb5bab0024029e494a7ab069db46425e8e75b2f9))
* **ci:** single nextest pass on main avoids sequential overhead ([f17d901](https://github.com/matyushkin/djvu-rs/commit/f17d901b1055c3cc2fb8e6dbfa3b6d445b6aa357))
* **deps:** split ocr-neural into lightweight stub + ocr-neural-candle ([#175](https://github.com/matyushkin/djvu-rs/issues/175)) ([3a930b2](https://github.com/matyushkin/djvu-rs/commit/3a930b2e38ca939eb15af2eefbb55156a158224b))
* downsampled mask pyramid for composite — 8 ms vs 23 ms for 150 dpi renders ([1374f27](https://github.com/matyushkin/djvu-rs/commit/1374f2707ead48b1db2a0eea48c12c8872bf9527))
* eliminate bounds checks in JB2 hot loops and ZP renormalize ([7e94000](https://github.com/matyushkin/djvu-rs/commit/7e94000ace8ed67b5410586563e7168031fa595e))
* eliminate redundant mask sampling in 3-layer composite ([#14](https://github.com/matyushkin/djvu-rs/issues/14)) ([#27](https://github.com/matyushkin/djvu-rs/issues/27)) ([f601036](https://github.com/matyushkin/djvu-rs/commit/f601036e8988c2ea0c4f2a5742cd4b1321bc8065))
* **iw44-enc:** NEON forward wavelet + parallel Y/Cb/Cr + skip empty passes ([#206](https://github.com/matyushkin/djvu-rs/issues/206)) ([d1f2765](https://github.com/matyushkin/djvu-rs/commit/d1f27658d9eecfcd741a63788a56be7a891e8ed0))
* **iw44:** allocate chroma planes at half resolution when chroma_half=true (Issue [#85](https://github.com/matyushkin/djvu-rs/issues/85)) ([#99](https://github.com/matyushkin/djvu-rs/issues/99)) ([927e7c0](https://github.com/matyushkin/djvu-rs/commit/927e7c01580412e45a1487ddb98d62b524eed059))
* **iw44:** compact-plane wavelet for sub≥2 + correct start_scale (Issue [#115](https://github.com/matyushkin/djvu-rs/issues/115)) ([#116](https://github.com/matyushkin/djvu-rs/issues/116)) ([4fc8921](https://github.com/matyushkin/djvu-rs/commit/4fc8921a7892834b3be97ed952d30000ea467b21))
* **iw44:** NEON decoder — column pass s=2/4, scatter, YCbCr, lifting (~25% to_rgb) ([#207](https://github.com/matyushkin/djvu-rs/issues/207)) ([f570297](https://github.com/matyushkin/djvu-rs/commit/f5702973fd0833ed195554335853325ece4e5f12))
* **iw44:** SIMD row pass — 8 rows at a time with i32x8 ([#107](https://github.com/matyushkin/djvu-rs/issues/107)) ([1418ff4](https://github.com/matyushkin/djvu-rs/commit/1418ff4f3c2cdfd1e0ee7a1210bc3852d0240239))
* **iw44:** SIMD YCbCr→RGB using wide::i32x8 (Issue [#1](https://github.com/matyushkin/djvu-rs/issues/1)) ([#64](https://github.com/matyushkin/djvu-rs/issues/64)) ([abceef4](https://github.com/matyushkin/djvu-rs/commit/abceef47d2bca524a20d13f4926f4dbf84e3c79b))
* **iw44:** SIMD-accelerate inverse wavelet transform column pass ([2ac4318](https://github.com/matyushkin/djvu-rs/commit/2ac4318c2c6e56af93ad5fe52670e032a70d378f)), closes [#68](https://github.com/matyushkin/djvu-rs/issues/68)
* **iw44:** WASM simd128 ycbcr_raw kernels (Phase 1 of [#190](https://github.com/matyushkin/djvu-rs/issues/190)) ([#253](https://github.com/matyushkin/djvu-rs/issues/253)) ([d59fcee](https://github.com/matyushkin/djvu-rs/commit/d59fcee1c770011a726ee41d77cf8964629dbc94))
* **iw44:** x86_64 AVX2 ports of prelim_flags kernels (Phase 3 of [#189](https://github.com/matyushkin/djvu-rs/issues/189)) ([#261](https://github.com/matyushkin/djvu-rs/issues/261)) ([0ed7a36](https://github.com/matyushkin/djvu-rs/commit/0ed7a36e3c117d83c9bf9dde6df5bd347a2652cf))
* **iw44:** x86_64 AVX2 ycbcr_raw kernels (Phase 1 of [#189](https://github.com/matyushkin/djvu-rs/issues/189)) ([#251](https://github.com/matyushkin/djvu-rs/issues/251)) ([7f3d867](https://github.com/matyushkin/djvu-rs/commit/7f3d8679e68f7c1daa8d7973e82d475ab3974c47))
* **jb2-enc:** eliminate bounds checks from JB2 encode hot loop ([#205](https://github.com/matyushkin/djvu-rs/issues/205)) ([5cbeaf0](https://github.com/matyushkin/djvu-rs/commit/5cbeaf0f64afbb2d39b86f568c73d04df9c9d35a))
* **jb2-enc:** opt-in lossy rec-7 near-duplicate substitution (Phase 4 of [#224](https://github.com/matyushkin/djvu-rs/issues/224)) ([#256](https://github.com/matyushkin/djvu-rs/issues/256)) ([98fb8c7](https://github.com/matyushkin/djvu-rs/commit/98fb8c76c22a3eb4a7306585f030605a0941673b))
* **jb2-enc:** per-CC accounting harness for shared-Djbz ([#194](https://github.com/matyushkin/djvu-rs/issues/194) Phase 2.5) ([#255](https://github.com/matyushkin/djvu-rs/issues/255)) ([f09bfdf](https://github.com/matyushkin/djvu-rs/commit/f09bfdf71ff0ce9959baa67aedb0c2fe73535f99))
* **jb2:** bit-pack Jbm to 1 bit/pixel — 8x memory, corpus −3.9% ([#187](https://github.com/matyushkin/djvu-rs/issues/187)) ([17f331f](https://github.com/matyushkin/djvu-rs/commit/17f331f3d44e9e8b6f2d179b77e7212ba5b47433))
* **jb2:** close performance gap vs DjVuLibre + CLI improvements ([#159](https://github.com/matyushkin/djvu-rs/issues/159)) ([3efc430](https://github.com/matyushkin/djvu-rs/commit/3efc430234f8848ecc597302c7f6ece8ae9ac887))
* **jb2:** local-copy ZP state for register-allocation + hardware CLZ ([0590d3c](https://github.com/matyushkin/djvu-rs/commit/0590d3cd00dce042132d8759204421a7b1750f33))
* **jb2:** reuse scratch buffer across symbol decodes to eliminate per-symbol heap allocations (Issue [#90](https://github.com/matyushkin/djvu-rs/issues/90)) ([#100](https://github.com/matyushkin/djvu-rs/issues/100)) ([12575d0](https://github.com/matyushkin/djvu-rs/commit/12575d095e73e650a5b04f4a5a56624b15c541f9))
* **jb2:** shared dict cache + split_at_mut inner loop (Issue [#87](https://github.com/matyushkin/djvu-rs/issues/87)) ([#106](https://github.com/matyushkin/djvu-rs/issues/106)) ([08ca0f4](https://github.com/matyushkin/djvu-rs/commit/08ca0f43f557024411e765afd9f419c2681f6275))
* partial BG44 chunk decode for sub=4 renders — skip high-frequency refinement ([b371e4e](https://github.com/matyushkin/djvu-rs/commit/b371e4eebe5cd766114d81dac3480430bc8712ed))
* **pdf:** output_dpi option + bilevel fast path — 2× faster export ([cfccbc6](https://github.com/matyushkin/djvu-rs/commit/cfccbc6deefbf288bcd2055ee27c3fed5d7c9b54)), closes [#147](https://github.com/matyushkin/djvu-rs/issues/147)
* **render:** 66% speedup on 600 dpi bilevel pages (Issue [#104](https://github.com/matyushkin/djvu-rs/issues/104)) ([#105](https://github.com/matyushkin/djvu-rs/issues/105)) ([8e5a2f4](https://github.com/matyushkin/djvu-rs/commit/8e5a2f42fdb0872b5a13d2560330346b0dc09989))
* **render:** eliminate redundant mask sampling in 3-layer composite (Issue [#14](https://github.com/matyushkin/djvu-rs/issues/14)) ([#37](https://github.com/matyushkin/djvu-rs/issues/37)) ([585991d](https://github.com/matyushkin/djvu-rs/commit/585991d961978277b8fdaf2b87236f6d1b825ac0))
* **render:** internal row-streaming refactor (Phase 1 of [#225](https://github.com/matyushkin/djvu-rs/issues/225)) ([#259](https://github.com/matyushkin/djvu-rs/issues/259)) ([3d22a59](https://github.com/matyushkin/djvu-rs/commit/3d22a59ae90ccff0cfcc0b4eb3fb21c7bb693dc6))
* **render:** NEON bilinear vertical pass + 4-byte RGBX stride ([#93](https://github.com/matyushkin/djvu-rs/issues/93)) ([b0dfdb8](https://github.com/matyushkin/djvu-rs/commit/b0dfdb8de78e34f5f7478bc06bf3c3dfad21d1df))
* **render:** precomputed coord tables, zero-copy BG path, remove PageMapper ([cf1a8e9](https://github.com/matyushkin/djvu-rs/commit/cf1a8e99eebf86d47c35fa403603354cbd23a5d7))
* **render:** x86_64 SSE2/SSSE3 fast paths for alpha fill and RGB→RGBA ([#169](https://github.com/matyushkin/djvu-rs/issues/169)) ([0ea3f3e](https://github.com/matyushkin/djvu-rs/commit/0ea3f3e674ae1eb112fb73368038e3fd0b2e0dde))
* replace bg_subsample division with shift in composite hot path ([0e0f2a3](https://github.com/matyushkin/djvu-rs/commit/0e0f2a3aa52da045126588ec4094fe436ce739c3))
* replace mask division with bit-shift in composite hot path ([e4b7982](https://github.com/matyushkin/djvu-rs/commit/e4b7982903dbaa040e3285ecb5ace4f24ca06b73))
* use chunks_exact_mut in composite loops — eliminate per-pixel bounds checks ([0176860](https://github.com/matyushkin/djvu-rs/commit/01768603ded218496c95678c40b5cc892a9dae9e))

## [0.16.1](https://github.com/matyushkin/djvu-rs/compare/v0.16.0...v0.16.1) (2026-05-04)

### Fixed

* Gate the async lazy example behind the `async` feature so default CI and
  release validation do not build it without `tokio`.
* Fix no-default-features wasm builds after the workspace crate split.
* Publish all extracted workspace crates in dependency order before publishing
  the umbrella `djvu-rs` crate.

## [0.16.0](https://github.com/matyushkin/djvu-rs/compare/v0.15.0...v0.16.0) (2026-05-04)


### Features

* **async:** add native lazy page loader ([735a226](https://github.com/matyushkin/djvu-rs/commit/735a22615ad91c89b2a38c865407a46319c46815))
* **async:** add wasm lazy reader entrypoint ([77fc6ff](https://github.com/matyushkin/djvu-rs/commit/77fc6ffecd57cb5760f9a7e75333987b3530c872))
* **async:** resolve lazy shared dictionaries ([30d8ac9](https://github.com/matyushkin/djvu-rs/commit/30d8ac9f2a4be61c5e82b4bea5f1d8083d4bcd07))

## [Unreleased]

### Changed

* **crates:** split codec primitives into publishable workspace crates: `djvu-zp`,
  `djvu-bzz`, `djvu-iff`, `djvu-bitmap`, `djvu-jb2`, `djvu-pixmap`, and
  `djvu-iw44` ([#229](https://github.com/matyushkin/djvu-rs/issues/229)).
  The umbrella `djvu-rs` crate keeps the historical module paths as re-export
  shims, while consumers that only need `djvu_iff::parse_form` can depend on
  `djvu-iff` directly; a path-dependency cold `cargo check` for an iff-only
  consumer measured 3.67 s.

## [0.15.0](https://github.com/matyushkin/djvu-rs/compare/v0.14.0...v0.15.0) (2026-05-03)


### Features

* **api:** bundled DJVM mutation + set_bookmarks (PR3 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#268](https://github.com/matyushkin/djvu-rs/issues/268)) ([6672a93](https://github.com/matyushkin/djvu-rs/commit/6672a936202f66b32e0e77dafdf467503547de6e))
* **api:** DjVuDocumentMut::from_bytes — chunk-replacement primitive (PR1 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#263](https://github.com/matyushkin/djvu-rs/issues/263)) ([b6279ae](https://github.com/matyushkin/djvu-rs/commit/b6279aed03de0eae42b1df7ee22da0bb56efaf08))
* **api:** high-level setters for DjVuDocumentMut (PR2 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#267](https://github.com/matyushkin/djvu-rs/issues/267)) ([eec0815](https://github.com/matyushkin/djvu-rs/commit/eec08153575052d81f71eb5382176816f1592aff))
* **async:** load_document_async — buffered AsyncRead constructor ([#196](https://github.com/matyushkin/djvu-rs/issues/196) Phase 1) ([#231](https://github.com/matyushkin/djvu-rs/issues/231)) ([2d85e65](https://github.com/matyushkin/djvu-rs/commit/2d85e65e1963efb88bb86fe4b1b7e706228e910d))
* **async:** page_byte_range API + streaming async loader ([#196](https://github.com/matyushkin/djvu-rs/issues/196) Phase 2) ([#237](https://github.com/matyushkin/djvu-rs/issues/237)) ([a365abb](https://github.com/matyushkin/djvu-rs/commit/a365abb64b06a1c86de87e230623e05f465909e1))
* **cli:** multi-page djvu encode from a directory of PNGs ([#223](https://github.com/matyushkin/djvu-rs/issues/223) follow-up) ([#245](https://github.com/matyushkin/djvu-rs/issues/245)) ([b8858bb](https://github.com/matyushkin/djvu-rs/commit/b8858bb36366be29441c17a06f0ea75daa4a210a))
* **djvu-enc:** high-level PageEncoder for bilevel Lossless ([#218](https://github.com/matyushkin/djvu-rs/issues/218)) ([#243](https://github.com/matyushkin/djvu-rs/issues/243)) ([afefcef](https://github.com/matyushkin/djvu-rs/commit/afefcef00cb2026772b4b22eb896c5533f87b844))
* **djvu-enc:** minimal layered Quality (segment → Sjbz + BG44) ([#246](https://github.com/matyushkin/djvu-rs/issues/246)) ([2febd04](https://github.com/matyushkin/djvu-rs/commit/2febd0486b839d800390e0abc1729965f02ad66c))
* **epub:** opt-in reflowable text section per page ([#228](https://github.com/matyushkin/djvu-rs/issues/228)) ([#240](https://github.com/matyushkin/djvu-rs/issues/240)) ([8207fb9](https://github.com/matyushkin/djvu-rs/commit/8207fb9e3046f594e5fb13150fa2d1220c5b35cf))
* **fgbz-enc:** FGbz foreground palette encoder ([#217](https://github.com/matyushkin/djvu-rs/issues/217)) ([#241](https://github.com/matyushkin/djvu-rs/issues/241)) ([e43bc9f](https://github.com/matyushkin/djvu-rs/commit/e43bc9f81ed3bc5e3cfaf5fa249c651749583a36))
* **jb2-enc:** expose tunable shared-Djbz clustering + corpus harness ([#194](https://github.com/matyushkin/djvu-rs/issues/194) Phase 2) ([#219](https://github.com/matyushkin/djvu-rs/issues/219)) ([9aafe42](https://github.com/matyushkin/djvu-rs/commit/9aafe42f04b6d474fefa0bbc73f06b4c666c9d1f))
* **render:** public render_streaming API (Phase 2 of [#225](https://github.com/matyushkin/djvu-rs/issues/225)) ([#260](https://github.com/matyushkin/djvu-rs/issues/260)) ([b92fac7](https://github.com/matyushkin/djvu-rs/commit/b92fac7c962c57115673eb31b6f84a5e7b36c085))
* **segment + cli:** FG/BG segmentation v1 + djvu encode subcommand ([#220](https://github.com/matyushkin/djvu-rs/issues/220), [#223](https://github.com/matyushkin/djvu-rs/issues/223)) ([#244](https://github.com/matyushkin/djvu-rs/issues/244)) ([4945b06](https://github.com/matyushkin/djvu-rs/commit/4945b0670938f4623e5368c14aa5ba41a0b107a5))
* **smmr-enc:** public Smmr (G4/MMR) encoder API ([#221](https://github.com/matyushkin/djvu-rs/issues/221)) ([#242](https://github.com/matyushkin/djvu-rs/issues/242)) ([009c706](https://github.com/matyushkin/djvu-rs/commit/009c70681eb9c34992ed8a438343638a694cd98b))
* **text:** add reflowable_text() for paragraph reading-order extraction ([#228](https://github.com/matyushkin/djvu-rs/issues/228)) ([#239](https://github.com/matyushkin/djvu-rs/issues/239)) ([221a49a](https://github.com/matyushkin/djvu-rs/commit/221a49a1c066bdef59d5dcabc26961e8d6283752))


### Bug Fixes

* **iff:** preserve FORM length parity for byte-identical mutation (PR4 of [#222](https://github.com/matyushkin/djvu-rs/issues/222)) ([#269](https://github.com/matyushkin/djvu-rs/issues/269)) ([df1e95e](https://github.com/matyushkin/djvu-rs/commit/df1e95e51c08ebe4e85cb1899352aae0cf5a5692))
* **iw44:** correct vext lane in prelim_flags_band0_neon horizontal-OR ([#266](https://github.com/matyushkin/djvu-rs/issues/266)) ([b390681](https://github.com/matyushkin/djvu-rs/commit/b3906813dbe4d4c9946c93b9b9e6884c1da62efc))
* **jb2-enc:** cap cluster_shared_symbols pixel budget at decoder limit ([#270](https://github.com/matyushkin/djvu-rs/issues/270)) ([#271](https://github.com/matyushkin/djvu-rs/issues/271)) ([78e5c79](https://github.com/matyushkin/djvu-rs/commit/78e5c793d3d7a86512e42820d8e3cf0c9870c48e))
* **render:** scale page-space coords into FG44 + BG plane space ([#199](https://github.com/matyushkin/djvu-rs/issues/199)) ([#248](https://github.com/matyushkin/djvu-rs/issues/248)) ([e2c07df](https://github.com/matyushkin/djvu-rs/commit/e2c07df45d5cfbc1edbef07553549e4fbf0fd2fc))


### Performance Improvements

* **iw44:** WASM simd128 inverse wavelet load/store (Phase 2 of [#190](https://github.com/matyushkin/djvu-rs/issues/190)) ([#257](https://github.com/matyushkin/djvu-rs/issues/257)) ([353813e](https://github.com/matyushkin/djvu-rs/commit/353813eac5460f1e1f4976fc639881ca8a98a306))
* **iw44:** WASM simd128 ycbcr_raw kernels (Phase 1 of [#190](https://github.com/matyushkin/djvu-rs/issues/190)) ([#253](https://github.com/matyushkin/djvu-rs/issues/253)) ([d59fcee](https://github.com/matyushkin/djvu-rs/commit/d59fcee1c770011a726ee41d77cf8964629dbc94))
* **iw44:** x86_64 AVX2 ports of prelim_flags kernels (Phase 3 of [#189](https://github.com/matyushkin/djvu-rs/issues/189)) ([#261](https://github.com/matyushkin/djvu-rs/issues/261)) ([0ed7a36](https://github.com/matyushkin/djvu-rs/commit/0ed7a36e3c117d83c9bf9dde6df5bd347a2652cf))
* **iw44:** x86_64 AVX2 stride-1 load/store (Phase 2 of [#189](https://github.com/matyushkin/djvu-rs/issues/189)) ([#252](https://github.com/matyushkin/djvu-rs/issues/252)) ([3edf027](https://github.com/matyushkin/djvu-rs/commit/3edf02784f68710f9eb1eeb7762a986a322b0ab3))
* **iw44:** x86_64 AVX2 ycbcr_raw kernels (Phase 1 of [#189](https://github.com/matyushkin/djvu-rs/issues/189)) ([#251](https://github.com/matyushkin/djvu-rs/issues/251)) ([7f3d867](https://github.com/matyushkin/djvu-rs/commit/7f3d8679e68f7c1daa8d7973e82d475ab3974c47))
* **jb2-enc:** opt-in lossy rec-7 near-duplicate substitution (Phase 4 of [#224](https://github.com/matyushkin/djvu-rs/issues/224)) ([#256](https://github.com/matyushkin/djvu-rs/issues/256)) ([98fb8c7](https://github.com/matyushkin/djvu-rs/commit/98fb8c76c22a3eb4a7306585f030605a0941673b))
* **jb2-enc:** per-CC accounting harness for shared-Djbz ([#194](https://github.com/matyushkin/djvu-rs/issues/194) Phase 2.5) ([#255](https://github.com/matyushkin/djvu-rs/issues/255)) ([f09bfdf](https://github.com/matyushkin/djvu-rs/commit/f09bfdf71ff0ce9959baa67aedb0c2fe73535f99))
* **render:** internal row-streaming refactor (Phase 1 of [#225](https://github.com/matyushkin/djvu-rs/issues/225)) ([#259](https://github.com/matyushkin/djvu-rs/issues/259)) ([3d22a59](https://github.com/matyushkin/djvu-rs/commit/3d22a59ae90ccff0cfcc0b4eb3fb21c7bb693dc6))

## [0.14.0](https://github.com/matyushkin/djvu-rs/compare/v0.13.0...v0.14.0) (2026-04-28)


### Features

* **jb2-enc:** multi-page shared Djbz dictionary in DJVM bundle, Phase 1 ([#194](https://github.com/matyushkin/djvu-rs/issues/194)) ([#216](https://github.com/matyushkin/djvu-rs/issues/216)) ([507b061](https://github.com/matyushkin/djvu-rs/commit/507b0618b27dc6619ce33736d01a9e920f2fdb32))
* **jb2-enc:** symbol-dictionary encoder Phases 1-3 ([#188](https://github.com/matyushkin/djvu-rs/issues/188)) ([#213](https://github.com/matyushkin/djvu-rs/issues/213)) ([8a2ed15](https://github.com/matyushkin/djvu-rs/commit/8a2ed150ad86bde2d0305c0b18e1297523590ce2))


### Bug Fixes

* **annotation:** add MAX_SEXPR_DEPTH=64 guard to prevent stack overflow on deeply nested S-expressions ([#200](https://github.com/matyushkin/djvu-rs/issues/200)) ([2f03789](https://github.com/matyushkin/djvu-rs/commit/2f03789638a65f9ac2e6c7cf5763f63ec9a3a0f6))
* **jb2-enc:** tile direct encoder to ≤1MP records ([#198](https://github.com/matyushkin/djvu-rs/issues/198)) ([#214](https://github.com/matyushkin/djvu-rs/issues/214)) ([24ac60f](https://github.com/matyushkin/djvu-rs/commit/24ac60fce1c139a8b55a3d30e71a7c36cac5d6d8))


### Performance Improvements

* **iw44-enc:** NEON forward wavelet + parallel Y/Cb/Cr + skip empty passes ([#206](https://github.com/matyushkin/djvu-rs/issues/206)) ([d1f2765](https://github.com/matyushkin/djvu-rs/commit/d1f27658d9eecfcd741a63788a56be7a891e8ed0))
* **iw44:** NEON decoder — column pass s=2/4, scatter, YCbCr, lifting (~25% to_rgb) ([#207](https://github.com/matyushkin/djvu-rs/issues/207)) ([f570297](https://github.com/matyushkin/djvu-rs/commit/f5702973fd0833ed195554335853325ece4e5f12))
* **jb2-enc:** eliminate bounds checks from JB2 encode hot loop ([#205](https://github.com/matyushkin/djvu-rs/issues/205)) ([5cbeaf0](https://github.com/matyushkin/djvu-rs/commit/5cbeaf0f64afbb2d39b86f568c73d04df9c9d35a))

## [0.13.0](https://github.com/matyushkin/djvu-rs/compare/v0.12.0...v0.13.0) (2026-04-18)


### Features

* **ci:** add ocr-tesseract integration test + CI job ([#178](https://github.com/matyushkin/djvu-rs/issues/178)) ([220671d](https://github.com/matyushkin/djvu-rs/commit/220671d0ae6d21f05a2a847945e062ae27eb931c))
* **epub:** DPI-aware rendering, language tag, hyperlinks, cover image ([191e386](https://github.com/matyushkin/djvu-rs/commit/191e3869623a091998d75761f9be30d75c9576a8))
* **mask:** wire Smmr (G4/MMR) decoder into both render pipelines ([07272b3](https://github.com/matyushkin/djvu-rs/commit/07272b32f44da9b4382bd9f1d4ff7828ce6223d3))
* **tiff:** embed DPI resolution tags in exported TIFF files ([87efb14](https://github.com/matyushkin/djvu-rs/commit/87efb140cc603a3ad4bd0f13b5e7a12c995ca516))


### Bug Fixes

* **ci:** install libleptonica-dev + libtesseract-dev for ocr-tesseract job ([0410f70](https://github.com/matyushkin/djvu-rs/commit/0410f70f0ed73be0425906685c3af1e0b6397374))
* **ci:** split test into test-stable + test-beta jobs (matrix.rust not allowed in job if) ([0d60c76](https://github.com/matyushkin/djvu-rs/commit/0d60c7662a78bff90dad81d9847e07d93dfb3b15))
* **docs:** resolve all remaining broken intra-doc links (0 warnings) ([4ac8bb1](https://github.com/matyushkin/djvu-rs/commit/4ac8bb162d922529ac4e58757155d556fbe3e7fc))
* **docs:** resolve broken intra-doc links in djvu_document ([8dbfda0](https://github.com/matyushkin/djvu-rs/commit/8dbfda050a72df34dbe3f149427aec4a6e4252a9))
* **fuzz:** revert to cargo install cargo-fuzz, add explicit binary cache ([84e6eef](https://github.com/matyushkin/djvu-rs/commit/84e6eef4b18c6f957f327d34fc2f87ab560a5f3c))
* **fuzz:** use correct public module djvu_rs::jb2 in fuzz_jb2 target ([9133de6](https://github.com/matyushkin/djvu-rs/commit/9133de69f3af8ee05f2c8f9239efcf87e2ed0a76))
* **pdf:** Unicode-aware glyph width for invisible text layer ([2398c38](https://github.com/matyushkin/djvu-rs/commit/2398c3851d8cef9c5a2b41dbcdaf5352baf9575a))
* **render:** add #[allow(unsafe_code)] + unsafe blocks for Rust 2024 SIMD ([#169](https://github.com/matyushkin/djvu-rs/issues/169)) ([179d171](https://github.com/matyushkin/djvu-rs/commit/179d17132c31b5ec31eaa99156acc4ac4cdda1f6))
* **render:** correct gamma LUT formula to match DjVuLibre ([#161](https://github.com/matyushkin/djvu-rs/issues/161)) ([cd3228d](https://github.com/matyushkin/djvu-rs/commit/cd3228d812e77f6d9bdcc48e1d9a92f8ff34077e))
* **render:** resolve unsafe_code / unsafe_op_in_unsafe_fn CI conflicts ([889f28f](https://github.com/matyushkin/djvu-rs/commit/889f28fb67c5b13c8f5b4a66ae32b1546a498988))
* **render:** restore bilevel composite fast path, recover 2× regression from [#165](https://github.com/matyushkin/djvu-rs/issues/165) ([46b6931](https://github.com/matyushkin/djvu-rs/commit/46b69318d0e1181d4eec5d9fc428cc5eee9723f6))
* **render:** use core::arch instead of std::arch for no_std compatibility ([122b989](https://github.com/matyushkin/djvu-rs/commit/122b989708e475658a764b2b145a887605590e37))
* resolve issues [#164](https://github.com/matyushkin/djvu-rs/issues/164) [#169](https://github.com/matyushkin/djvu-rs/issues/169) [#170](https://github.com/matyushkin/djvu-rs/issues/170) [#174](https://github.com/matyushkin/djvu-rs/issues/174) [#176](https://github.com/matyushkin/djvu-rs/issues/176) [#177](https://github.com/matyushkin/djvu-rs/issues/177) ([774cbdb](https://github.com/matyushkin/djvu-rs/commit/774cbdb834c703c27ca82ed9f8f3bb4a17504aeb))
* wasm CI job, open_dir API, DPI scaling in OCR export, jb2_new cleanup ([6cbe038](https://github.com/matyushkin/djvu-rs/commit/6cbe038909858f4c523f13d7204998a7109cd84d))
* **zp:** widen a/c/fence fields from u16 to u32 to match jb2 inline decoder ([fb0db12](https://github.com/matyushkin/djvu-rs/commit/fb0db122daa4dccd97f49a971103de0add5a2366))


### Performance Improvements

* **bzz:** inline ZP state locals in MTF decode hot loop ([bad5b21](https://github.com/matyushkin/djvu-rs/commit/bad5b215bfa5384589f2252b3da2ee0ecb9a3ac2))
* **ci:** single nextest pass on main avoids sequential overhead ([f17d901](https://github.com/matyushkin/djvu-rs/commit/f17d901b1055c3cc2fb8e6dbfa3b6d445b6aa357))
* **deps:** split ocr-neural into lightweight stub + ocr-neural-candle ([#175](https://github.com/matyushkin/djvu-rs/issues/175)) ([3a930b2](https://github.com/matyushkin/djvu-rs/commit/3a930b2e38ca939eb15af2eefbb55156a158224b))
* **jb2:** bit-pack Jbm to 1 bit/pixel — 8x memory, corpus −3.9% ([#187](https://github.com/matyushkin/djvu-rs/issues/187)) ([17f331f](https://github.com/matyushkin/djvu-rs/commit/17f331f3d44e9e8b6f2d179b77e7212ba5b47433))
* **render:** x86_64 SSE2/SSSE3 fast paths for alpha fill and RGB→RGBA ([#169](https://github.com/matyushkin/djvu-rs/issues/169)) ([0ea3f3e](https://github.com/matyushkin/djvu-rs/commit/0ea3f3e674ae1eb112fb73368038e3fd0b2e0dde))

## [0.12.0](https://github.com/matyushkin/djvu-rs/compare/v0.11.1...v0.12.0) (2026-04-14)


### Features

* **pdf:** parallel page rendering with rayon ([#148](https://github.com/matyushkin/djvu-rs/issues/148)) ([ae79a7c](https://github.com/matyushkin/djvu-rs/commit/ae79a7c6539fd2173885b18aa4e3beb7146b70b4))
* **wasm:** progressive IW44 render API ([#150](https://github.com/matyushkin/djvu-rs/issues/150)) ([35d3a30](https://github.com/matyushkin/djvu-rs/commit/35d3a30d285fd699781d9c4e5373b584b29f544d))


### Bug Fixes

* **ocr:** resolve all clippy errors in ocr_neural, ocr_onnx, ocr_tesseract ([65a0cee](https://github.com/matyushkin/djvu-rs/commit/65a0cee338411a608c0c8a92d02c3638cb18c153))
* update tesseract API and optimize JB2 inner loop ([f64d884](https://github.com/matyushkin/djvu-rs/commit/f64d88423aff0d4861a6dd50c1ec7a4c45e1d10b))


### Performance Improvements

* allow 1.5× upscale in IW44 subsample selection for faster downscaled renders ([8f0baa2](https://github.com/matyushkin/djvu-rs/commit/8f0baa2a06eadce23974d973b7ee635b5939a5f0))
* downsampled mask pyramid for composite — 8 ms vs 23 ms for 150 dpi renders ([1374f27](https://github.com/matyushkin/djvu-rs/commit/1374f2707ead48b1db2a0eea48c12c8872bf9527))
* eliminate bounds checks in JB2 hot loops and ZP renormalize ([7e94000](https://github.com/matyushkin/djvu-rs/commit/7e94000ace8ed67b5410586563e7168031fa595e))
* **jb2:** close performance gap vs DjVuLibre + CLI improvements ([#159](https://github.com/matyushkin/djvu-rs/issues/159)) ([3efc430](https://github.com/matyushkin/djvu-rs/commit/3efc430234f8848ecc597302c7f6ece8ae9ac887))
* **jb2:** local-copy ZP state for register-allocation + hardware CLZ ([0590d3c](https://github.com/matyushkin/djvu-rs/commit/0590d3cd00dce042132d8759204421a7b1750f33))
* partial BG44 chunk decode for sub=4 renders — skip high-frequency refinement ([b371e4e](https://github.com/matyushkin/djvu-rs/commit/b371e4eebe5cd766114d81dac3480430bc8712ed))
* **pdf:** output_dpi option + bilevel fast path — 2× faster export ([cfccbc6](https://github.com/matyushkin/djvu-rs/commit/cfccbc6deefbf288bcd2055ee27c3fed5d7c9b54)), closes [#147](https://github.com/matyushkin/djvu-rs/issues/147)
* replace bg_subsample division with shift in composite hot path ([0e0f2a3](https://github.com/matyushkin/djvu-rs/commit/0e0f2a3aa52da045126588ec4094fe436ce739c3))
* replace mask division with bit-shift in composite hot path ([e4b7982](https://github.com/matyushkin/djvu-rs/commit/e4b7982903dbaa040e3285ecb5ace4f24ca06b73))
* use chunks_exact_mut in composite loops — eliminate per-pixel bounds checks ([0176860](https://github.com/matyushkin/djvu-rs/commit/01768603ded218496c95678c40b5cc892a9dae9e))

## [0.11.1](https://github.com/matyushkin/djvu-rs/compare/v0.11.0...v0.11.1) (2026-04-13)


### Bug Fixes

* **fuzz:** add [workspace] to fuzz/Cargo.toml to fix cargo-fuzz build ([be7a5a8](https://github.com/matyushkin/djvu-rs/commit/be7a5a80d23ca77c6c326c1c9065e1498ab41b5d))
* **smmr:** replace manual div_ceil with .div_ceil() per clippy ([a8d24ca](https://github.com/matyushkin/djvu-rs/commit/a8d24ca5fa470e9f9c59bee7ef7a605786a8fe79))

## [0.11.0](https://github.com/matyushkin/djvu-rs/compare/v0.10.0...v0.11.0) (2026-04-13)


### Features

* add BZZ encoder with ZP arithmetic coding ([582432f](https://github.com/matyushkin/djvu-rs/commit/582432f601cf546c9404228af1541ec2067b503e))
* add NAVM bookmark encoder and ANTa/ANTz annotation encoder ([#133](https://github.com/matyushkin/djvu-rs/issues/133)) ([#136](https://github.com/matyushkin/djvu-rs/issues/136)) ([9e6bf66](https://github.com/matyushkin/djvu-rs/commit/9e6bf662125194fe57be02bed2ce42d87b8c16b7))
* indirect DJVM — create_indirect() and parse_from_dir() ([#135](https://github.com/matyushkin/djvu-rs/issues/135)) ([#137](https://github.com/matyushkin/djvu-rs/issues/137)) ([d7fbf74](https://github.com/matyushkin/djvu-rs/commit/d7fbf74e45b9f5a85d0f162796709126131ab8a0))
* IW44 wavelet encoder — BG44/FG44 chunk encoding (issue [#131](https://github.com/matyushkin/djvu-rs/issues/131)) ([#139](https://github.com/matyushkin/djvu-rs/issues/139)) ([10adc4f](https://github.com/matyushkin/djvu-rs/commit/10adc4f61bf8a79f9c4ba74559fb004b31d8968c))
* JB2 bilevel image encoder — Sjbz chunk encoding (issue [#132](https://github.com/matyushkin/djvu-rs/issues/132)) ([#140](https://github.com/matyushkin/djvu-rs/issues/140)) ([cf280ba](https://github.com/matyushkin/djvu-rs/commit/cf280ba6e1356f1d8f7498c84c57e2759f603b3c))
* **smmr:** add G4/MMR bilevel image decoder (issue [#134](https://github.com/matyushkin/djvu-rs/issues/134)) ([#138](https://github.com/matyushkin/djvu-rs/issues/138)) ([8bd6e41](https://github.com/matyushkin/djvu-rs/commit/8bd6e4157c885e7a03c0443657d294099fbe7619))


### Bug Fixes

* **ci:** enable cli feature for nextest to build djvu binary ([576f12f](https://github.com/matyushkin/djvu-rs/commit/576f12faf154662a3992ac3a20c3c126e32fc798))
* **ci:** exclude djvu-py from nextest, fix audit advisories ([788b0d3](https://github.com/matyushkin/djvu-rs/commit/788b0d39fc04d1ed28dc5052f2bc88004f106117))
* **ci:** exclude fuzz/ from workspace to fix cargo-fuzz builds ([330ff0a](https://github.com/matyushkin/djvu-rs/commit/330ff0a28a601629718cf0c12d4e90ab93524621))
* **jb2_encode:** return empty Vec for zero-dimension bitmaps; unreachable dead branch ([#142](https://github.com/matyushkin/djvu-rs/issues/142)) ([#143](https://github.com/matyushkin/djvu-rs/issues/143)) ([091b657](https://github.com/matyushkin/djvu-rs/commit/091b6573467c67c3c8d487ee82dba24b7c59f136))

## [0.10.0](https://github.com/matyushkin/djvu-rs/compare/v0.9.0...v0.10.0) (2026-04-10)


### Features

* **djvm:** add merge and split commands for DjVu documents ([#126](https://github.com/matyushkin/djvu-rs/issues/126)) ([37eefd8](https://github.com/matyushkin/djvu-rs/commit/37eefd89f969ade36e3547fce0222a9d23d9c215)), closes [#76](https://github.com/matyushkin/djvu-rs/issues/76)
* **ffi:** add C FFI bindings via extern "C" functions ([#127](https://github.com/matyushkin/djvu-rs/issues/127)) ([2226bdf](https://github.com/matyushkin/djvu-rs/commit/2226bdfad34ef39a08bb9a3b1b220cac2942b30a)), closes [#72](https://github.com/matyushkin/djvu-rs/issues/72)
* **ocr:** pluggable OCR backend trait with Tesseract, ONNX, and Candle backends ([#125](https://github.com/matyushkin/djvu-rs/issues/125)) ([bf26603](https://github.com/matyushkin/djvu-rs/commit/bf26603b714d1721f63beedcf2ad54a5f95e21a0)), closes [#77](https://github.com/matyushkin/djvu-rs/issues/77)
* **python:** add Python bindings via PyO3 ([#128](https://github.com/matyushkin/djvu-rs/issues/128)) ([e250fff](https://github.com/matyushkin/djvu-rs/commit/e250fffcef36531d8641e1ab8031198c30c7d372)), closes [#71](https://github.com/matyushkin/djvu-rs/issues/71)


### Bug Fixes

* eliminate memory leaks and add OOM protection ([25f041d](https://github.com/matyushkin/djvu-rs/commit/25f041d78c513f1e3dfbd87aa69dc4fc261488da))
* **jb2:** prevent infinite loop in decode_num on corrupt streams ([d7bee1e](https://github.com/matyushkin/djvu-rs/commit/d7bee1e8c8c612583a055d40c4aa7a8c81666e47)), closes [#122](https://github.com/matyushkin/djvu-rs/issues/122)

## [0.9.0](https://github.com/matyushkin/djvu-rs/compare/v0.8.0...v0.9.0) (2026-04-09)


### Features

* **epub:** EPUB 3 export — page images, text overlay, navigation (Issue [#74](https://github.com/matyushkin/djvu-rs/issues/74)) ([9a6d155](https://github.com/matyushkin/djvu-rs/commit/9a6d1555c43041b86a783c5967a55607e0090768))
* **wasm:** add WasmPage::text_zones_json() — text selection overlay API ([e513bbf](https://github.com/matyushkin/djvu-rs/commit/e513bbfc4052161f0b61f0c2cc429c58869d7170)), closes [#119](https://github.com/matyushkin/djvu-rs/issues/119)
* **wasm:** add WasmPage::text() — expose page text layer to JS ([35a776d](https://github.com/matyushkin/djvu-rs/commit/35a776d16804b39e1ae8cfddbf18073e4711204c))


### Bug Fixes

* **wasm:** correct render() pixel layout and Uint8ClampedArray allocation ([1a967d2](https://github.com/matyushkin/djvu-rs/commit/1a967d2003bb74f0e42bccc8f108b2f1303617c1))

## [0.8.0](https://github.com/matyushkin/djvu-rs/compare/v0.7.1...v0.8.0) (2026-04-09)


### Features

* **epub:** EPUB 3 export — page images, text overlay, navigation (Issue [#74](https://github.com/matyushkin/djvu-rs/issues/74)) ([9a6d155](https://github.com/matyushkin/djvu-rs/commit/9a6d1555c43041b86a783c5967a55607e0090768))
* **wasm:** add WasmPage::text_zones_json() — text selection overlay API ([e513bbf](https://github.com/matyushkin/djvu-rs/commit/e513bbfc4052161f0b61f0c2cc429c58869d7170)), closes [#119](https://github.com/matyushkin/djvu-rs/issues/119)
* **wasm:** add WasmPage::text() — expose page text layer to JS ([35a776d](https://github.com/matyushkin/djvu-rs/commit/35a776d16804b39e1ae8cfddbf18073e4711204c))
* **wasm:** WebAssembly bindings via wasm-bindgen (Issue [#73](https://github.com/matyushkin/djvu-rs/issues/73)) ([#118](https://github.com/matyushkin/djvu-rs/issues/118)) ([4300939](https://github.com/matyushkin/djvu-rs/commit/4300939b9085725005f7ce0a62d4e34f836367ff))


### Bug Fixes

* **wasm:** correct render() pixel layout and Uint8ClampedArray allocation ([1a967d2](https://github.com/matyushkin/djvu-rs/commit/1a967d2003bb74f0e42bccc8f108b2f1303617c1))

## [0.7.1](https://github.com/matyushkin/djvu-rs/compare/v0.7.0...v0.7.1) (2026-04-08)


### Performance Improvements

* **iw44:** compact-plane wavelet for sub≥2 + correct start_scale (Issue [#115](https://github.com/matyushkin/djvu-rs/issues/115)) ([#116](https://github.com/matyushkin/djvu-rs/issues/116)) ([4fc8921](https://github.com/matyushkin/djvu-rs/commit/4fc8921a7892834b3be97ed952d30000ea467b21))

## [0.7.0](https://github.com/matyushkin/djvu-rs/compare/v0.6.0...v0.7.0) (2026-04-08)


### Features

* **async:** progressive stream render API (Issue [#81](https://github.com/matyushkin/djvu-rs/issues/81)) ([#112](https://github.com/matyushkin/djvu-rs/issues/112)) ([eaff91d](https://github.com/matyushkin/djvu-rs/commit/eaff91d5f5b8ccfa3cf86429339e7c21bcde5f72))
* **ci:** continuous benchmark tracking — PR regression detection (Issue [#88](https://github.com/matyushkin/djvu-rs/issues/88)) ([#109](https://github.com/matyushkin/djvu-rs/issues/109)) ([0dfade5](https://github.com/matyushkin/djvu-rs/commit/0dfade5a8c4ec125bac50ff9deb5df37a159c56f))
* **render:** zero-copy region render — render_region API (Issue [#86](https://github.com/matyushkin/djvu-rs/issues/86)) ([#111](https://github.com/matyushkin/djvu-rs/issues/111)) ([b2aa2a8](https://github.com/matyushkin/djvu-rs/commit/b2aa2a860dc28a63409785af8ef2be55cca40a11))


### Performance Improvements

* **bzz:** parallel inverse-BWT via rayon (Issue [#89](https://github.com/matyushkin/djvu-rs/issues/89)) ([#110](https://github.com/matyushkin/djvu-rs/issues/110)) ([eb5bab0](https://github.com/matyushkin/djvu-rs/commit/eb5bab0024029e494a7ab069db46425e8e75b2f9))
* **iw44:** SIMD row pass — 8 rows at a time with i32x8 ([#107](https://github.com/matyushkin/djvu-rs/issues/107)) ([1418ff4](https://github.com/matyushkin/djvu-rs/commit/1418ff4f3c2cdfd1e0ee7a1210bc3852d0240239))

## [0.6.0](https://github.com/matyushkin/djvu-rs/compare/v0.5.0...v0.6.0) (2026-04-06)


### Features

* hOCR and ALTO XML export for text layer (Issue [#75](https://github.com/matyushkin/djvu-rs/issues/75)) ([#98](https://github.com/matyushkin/djvu-rs/issues/98)) ([263cf14](https://github.com/matyushkin/djvu-rs/commit/263cf1492b57caa2b1d986a7eec8fd4a6cc8305b))
* implement ImageDecoder trait for image-rs integration (Issue [#80](https://github.com/matyushkin/djvu-rs/issues/80)) ([#97](https://github.com/matyushkin/djvu-rs/issues/97)) ([d7e4a64](https://github.com/matyushkin/djvu-rs/commit/d7e4a64e427454f4353f5124d1d03ba4ae31fe8c))
* serde support for metadata, annotations, bookmarks, and text zones (Issue [#82](https://github.com/matyushkin/djvu-rs/issues/82)) ([#96](https://github.com/matyushkin/djvu-rs/issues/96)) ([e872ecd](https://github.com/matyushkin/djvu-rs/commit/e872ecdefbee38e0862c899da3955c2ee98ca233))


### Bug Fixes

* **ci:** use core::mem::take in no_std context; fix clippy redundant-Some in ocr_export test ([#101](https://github.com/matyushkin/djvu-rs/issues/101)) ([cc1cdf1](https://github.com/matyushkin/djvu-rs/commit/cc1cdf136e4eaaf9311170a20cd1f3b5ffd4ce54))
* **jb2:** correct regression test comment for fuzz2 fix ([ee380ae](https://github.com/matyushkin/djvu-rs/commit/ee380ae87d3f589627182b5a1350ae76072eb901))
* **jb2:** guard blit against negative symbol dimensions ([49a3792](https://github.com/matyushkin/djvu-rs/commit/49a3792c764e25594165a10b127612a446d7a732))
* **jb2:** reduce MAX_RECORDS and MAX_SYMBOL_PIXELS to prevent fuzz timeouts ([3292193](https://github.com/matyushkin/djvu-rs/commit/3292193237d733976ea24c879ade958b1021caaa))


### Performance Improvements

* **iw44:** allocate chroma planes at half resolution when chroma_half=true (Issue [#85](https://github.com/matyushkin/djvu-rs/issues/85)) ([#99](https://github.com/matyushkin/djvu-rs/issues/99)) ([927e7c0](https://github.com/matyushkin/djvu-rs/commit/927e7c01580412e45a1487ddb98d62b524eed059))
* **jb2:** reuse scratch buffer across symbol decodes to eliminate per-symbol heap allocations (Issue [#90](https://github.com/matyushkin/djvu-rs/issues/90)) ([#100](https://github.com/matyushkin/djvu-rs/issues/100)) ([12575d0](https://github.com/matyushkin/djvu-rs/commit/12575d095e73e650a5b04f4a5a56624b15c541f9))
* **jb2:** shared dict cache + split_at_mut inner loop (Issue [#87](https://github.com/matyushkin/djvu-rs/issues/87)) ([#106](https://github.com/matyushkin/djvu-rs/issues/106)) ([08ca0f4](https://github.com/matyushkin/djvu-rs/commit/08ca0f43f557024411e765afd9f419c2681f6275))
* **render:** 66% speedup on 600 dpi bilevel pages (Issue [#104](https://github.com/matyushkin/djvu-rs/issues/104)) ([#105](https://github.com/matyushkin/djvu-rs/issues/105)) ([8e5a2f4](https://github.com/matyushkin/djvu-rs/commit/8e5a2f42fdb0872b5a13d2560330346b0dc09989))
* **render:** NEON bilinear vertical pass + 4-byte RGBX stride ([#93](https://github.com/matyushkin/djvu-rs/issues/93)) ([b0dfdb8](https://github.com/matyushkin/djvu-rs/commit/b0dfdb8de78e34f5f7478bc06bf3c3dfad21d1df))
* **render:** precomputed coord tables, zero-copy BG path, remove PageMapper ([cf1a8e9](https://github.com/matyushkin/djvu-rs/commit/cf1a8e99eebf86d47c35fa403603354cbd23a5d7))

## [0.5.3] (unreleased)


### Performance Improvements

* **jb2:** cache shared symbol dictionary to avoid re-decoding Djbz on every `decode_mask()` call — `render_large_doc_first_page` 14.5 ms → 10.5 ms (−28%), `render_large_doc_mid_page` 43.9 ms → 36.2 ms (−18%) (closes [#87](https://github.com/matyushkin/djvu-rs/issues/87))
  - `Document::get_or_decode_dict`: `RwLock<HashMap<usize, Arc<JB2Dict>>>` keyed by Djbz data pointer — multi-page documents decode the shared dictionary once across all pages
  - `decode_bitmap_direct`: `split_at_mut` look-ahead row access eliminates per-pixel `row * width` multiply and 4-comparison bounds checks; `jb2_decode` small-page benchmark: 245 µs → 189 µs (−23%)


## [0.5.2](https://github.com/matyushkin/djvu-rs/compare/v0.5.1...v0.5.2) (2026-04-06)


### Performance Improvements

* **render:** 66% speedup on 600 dpi bilevel pages — `render_large_doc_first_page` 42.7 ms → 14.5 ms (closes [#104](https://github.com/matyushkin/djvu-rs/issues/104))
  - `Pixmap::new`: replaced per-pixel push loop with bulk fill — 18 ms → 0.8 ms (−95%) for a 2649×4530 buffer
  - `composite_bilevel`: row-slice writes + rayon `par_chunks_mut` under `--features parallel`
  - Skip `apply_gamma` for pure bilevel pages (0/255 values, gamma is a mathematical no-op)
  - Parallel Y/Cb/Cr wavelet reconstruction via `rayon::join` under `--features parallel`
  - Parallel bilinear scaler passes under `--features parallel`


## [0.5.0](https://github.com/matyushkin/djvu-rs/compare/v0.4.2...v0.5.0) (2026-04-05)


### Features

* **fuzz:** add render to fuzz_full, add CI fuzz workflow (60 s/target) ([7e3e4eb](https://github.com/matyushkin/djvu-rs/commit/7e3e4eb0d51404d0c460b71ac5a359d4eac6da8b))
* **mmap:** add memory-mapped I/O via MmapDocument ([387a2ea](https://github.com/matyushkin/djvu-rs/commit/387a2ea40696d88906dc5ead848154cf42189c6a)), closes [#70](https://github.com/matyushkin/djvu-rs/issues/70)
* **render:** add rayon-based parallel page rendering ([3dc06f9](https://github.com/matyushkin/djvu-rs/commit/3dc06f991d7e26099ea4623580ebded7022f8775)), closes [#69](https://github.com/matyushkin/djvu-rs/issues/69)


### Bug Fixes

* **clippy:** use `contains()` instead of `iter().any()` in tiff_export ([f9b4c2b](https://github.com/matyushkin/djvu-rs/commit/f9b4c2b7b9ad3aadbc9539aec09ef651f5545312))
* **jb2,iw44:** cap comment bytes and IW44 pixel limit to prevent fuzz timeouts ([49c7b1b](https://github.com/matyushkin/djvu-rs/commit/49c7b1bd29505528d53b70e7ab820e5a9c0eae2e))
* **jb2,iw44:** prevent DoS via refinement bitmaps and uncapped total pixel budget ([3e72cf6](https://github.com/matyushkin/djvu-rs/commit/3e72cf6c33d21661db1198013d789217d8978580))
* **jb2:** add blit-pixel budget to prevent type-7 dict-copy DoS ([1c03505](https://github.com/matyushkin/djvu-rs/commit/1c0350543b870c3b29fe87c1b59370410ba5e464))
* **jb2:** cap decode loop at 1 M records to prevent infinite spin on exhausted ZP input ([0b84f2d](https://github.com/matyushkin/djvu-rs/commit/0b84f2dcadaf4cbbae75bd2e53cb82f7f99d4f2d))
* **jb2:** guard blit fast path against i32 overflow and data buffer overread ([be72d29](https://github.com/matyushkin/djvu-rs/commit/be72d29584170afb0f12a951c10d3f24859ae02f))
* **jb2:** limit symbol bitmap size to 4 MP to prevent DoS via crafted input ([943f25e](https://github.com/matyushkin/djvu-rs/commit/943f25eaacc7c91234caea2e99ff87950f7d632f))


### Performance Improvements

* **iw44:** SIMD-accelerate inverse wavelet transform column pass ([2ac4318](https://github.com/matyushkin/djvu-rs/commit/2ac4318c2c6e56af93ad5fe52670e032a70d378f)), closes [#68](https://github.com/matyushkin/djvu-rs/issues/68)

## [0.4.2](https://github.com/matyushkin/djvu-rs/compare/v0.4.1...v0.4.2) (2026-04-05)

### Documentation

* Rewrite README — DjVuDocument API, CLI examples, PDF/TIFF/async sections

## [0.4.1](https://github.com/matyushkin/djvu-rs/compare/v0.4.0...v0.4.1) (2026-04-05)

### Documentation

* remove stale next-up block from roadmap section

## [0.4.0](https://github.com/matyushkin/djvu-rs/compare/djvu-rs-v0.3.0...djvu-rs-v0.4.0) (2026-04-05)


### Features

* add fit_to_width/height/box to RenderOptions ([#33](https://github.com/matyushkin/djvu-rs/issues/33)) ([b371a93](https://github.com/matyushkin/djvu-rs/commit/b371a93099276cab573244cc262dc6ba093276cf))
* **api:** raw_chunk / all_chunks / chunk_ids on DjVuPage and DjVuDocument (Issue [#43](https://github.com/matyushkin/djvu-rs/issues/43)) ([#54](https://github.com/matyushkin/djvu-rs/issues/54)) ([3135627](https://github.com/matyushkin/djvu-rs/commit/31356279ad2739ae13ab36a144fbaabe5b5f63ab))
* **async:** async render API via tokio::task::spawn_blocking (Issue [#51](https://github.com/matyushkin/djvu-rs/issues/51)) ([#61](https://github.com/matyushkin/djvu-rs/issues/61)) ([452636f](https://github.com/matyushkin/djvu-rs/commit/452636f143c56f4fc674968be5d5a4d8bd15d14a))
* **bench:** add render_scaled and pdf_export benchmarks + BENCHMARKS.md (Issue [#52](https://github.com/matyushkin/djvu-rs/issues/52)) ([#62](https://github.com/matyushkin/djvu-rs/issues/62)) ([a8523c7](https://github.com/matyushkin/djvu-rs/commit/a8523c711c2fc3fc12d1089c5becf1b68af25595))
* **cli:** implement djvu info/render/text — 24/24 tests green ([eb2e9d6](https://github.com/matyushkin/djvu-rs/commit/eb2e9d61f0a12285f9c6d7de4a4665b31f19a32a))
* **cos-djvu:** benchmark suite, corpus infrastructure, BENCHMARKS.md (closes [#282](https://github.com/matyushkin/djvu-rs/issues/282)) ([#332](https://github.com/matyushkin/djvu-rs/issues/332)) ([50b6933](https://github.com/matyushkin/djvu-rs/commit/50b69330c73e5883a2954fe646f2cc7b7ec4e654))
* **cos-djvu:** phase 1 — IFF parser, typed errors, MIT skeleton (closes [#267](https://github.com/matyushkin/djvu-rs/issues/267)) ([#277](https://github.com/matyushkin/djvu-rs/issues/277)) ([1943f3f](https://github.com/matyushkin/djvu-rs/commit/1943f3f1cbef880038065ea377ccdfdff4ee33d0))
* **cos-djvu:** phase 2a — ZP arithmetic coder + BZZ decompressor (closes [#268](https://github.com/matyushkin/djvu-rs/issues/268)) ([#279](https://github.com/matyushkin/djvu-rs/issues/279)) ([4983056](https://github.com/matyushkin/djvu-rs/commit/498305678a0d13947e6fe5473d2bc6250383595d))
* **cos-djvu:** phase-5 rendering pipeline — compositing, gamma, scaling, AA (closes [#273](https://github.com/matyushkin/djvu-rs/issues/273)) ([7f5e161](https://github.com/matyushkin/djvu-rs/commit/7f5e161dd7f13c94ed1fb680966416e339eb80d5))
* **cos-djvu:** phase-6 quality — fuzz targets, benchmarks, no_std, full docs (closes [#274](https://github.com/matyushkin/djvu-rs/issues/274)) ([#324](https://github.com/matyushkin/djvu-rs/issues/324)) ([67fab7f](https://github.com/matyushkin/djvu-rs/commit/67fab7fdce945d972c574f61f9e460c32998a189))
* **cos-djvu:** text layer + annotations extraction (closes [#272](https://github.com/matyushkin/djvu-rs/issues/272)) ([#316](https://github.com/matyushkin/djvu-rs/issues/316)) ([5beeba9](https://github.com/matyushkin/djvu-rs/commit/5beeba96034a55396769d044ff1c20f20dc379a6))
* djvu render --format pdf|cbz, roadmap v0.1 finalised ([7d823f6](https://github.com/matyushkin/djvu-rs/commit/7d823f634a1efbc75f743d5d5a8a4f6056e0b0a0))
* DjVu to PDF converter with text, bookmarks, and hyperlinks ([#2](https://github.com/matyushkin/djvu-rs/issues/2)-[#6](https://github.com/matyushkin/djvu-rs/issues/6)) ([#29](https://github.com/matyushkin/djvu-rs/issues/29)) ([a6f0a74](https://github.com/matyushkin/djvu-rs/commit/a6f0a7486d85146e677ae094396e96b44675e894))
* document model — DjVuDocument, Page, DIRM, NAVM (closes [#271](https://github.com/matyushkin/djvu-rs/issues/271)) ([#283](https://github.com/matyushkin/djvu-rs/issues/283)) ([e36fd41](https://github.com/matyushkin/djvu-rs/commit/e36fd4169b591cb5f4146fc58bd3aaacf464d82b))
* import cos-djvu history, remove GPL legacy code ([0f33110](https://github.com/matyushkin/djvu-rs/commit/0f33110d1846e7114c6a46726c9e088cbef25bea))
* IW44 wavelet decoder with planar YCbCr (closes [#270](https://github.com/matyushkin/djvu-rs/issues/270)) ([#281](https://github.com/matyushkin/djvu-rs/issues/281)) ([f799e70](https://github.com/matyushkin/djvu-rs/commit/f799e7098dfbffdabada8e0c19fea2e31cdac351))
* JB2 bilevel decoder (closes [#269](https://github.com/matyushkin/djvu-rs/issues/269)) ([#280](https://github.com/matyushkin/djvu-rs/issues/280)) ([e2a6898](https://github.com/matyushkin/djvu-rs/commit/e2a6898618765fe96a07ddaac51a40b665b64efb))
* **jb2:** DJVI shared dictionary support via INCL chunks (Issue [#45](https://github.com/matyushkin/djvu-rs/issues/45)) ([#56](https://github.com/matyushkin/djvu-rs/issues/56)) ([86a63cb](https://github.com/matyushkin/djvu-rs/commit/86a63cb975303c14159340da4718ed3e23182e3e))
* mask and foreground/background layer extraction API ([#36](https://github.com/matyushkin/djvu-rs/issues/36)) ([d4c6527](https://github.com/matyushkin/djvu-rs/commit/d4c6527eb03aa9397a681ccdf03a27cf9ed77b0b))
* **metadata:** METa/METz document metadata parsing (Issue [#44](https://github.com/matyushkin/djvu-rs/issues/44)) ([#55](https://github.com/matyushkin/djvu-rs/issues/55)) ([eb4515b](https://github.com/matyushkin/djvu-rs/commit/eb4515b49819c3b75824738989c07153a7c2c0d6))
* **pdf:** DCTDecode background encoding — smaller PDF output (Issue [#49](https://github.com/matyushkin/djvu-rs/issues/49)) ([#59](https://github.com/matyushkin/djvu-rs/issues/59)) ([de90a9f](https://github.com/matyushkin/djvu-rs/commit/de90a9fd94ef98fdeb8822aef174e945ebe5a3ea))
* progressive DjVu rendering, multi-book cache, cos-diagnostics crate ([32432d8](https://github.com/matyushkin/djvu-rs/commit/32432d8c240f4a4673310a70158cf12cb9643635))
* **render:** BGjp/FGjp JPEG background/foreground decoder (Issue [#47](https://github.com/matyushkin/djvu-rs/issues/47)) ([#57](https://github.com/matyushkin/djvu-rs/issues/57)) ([b65bd81](https://github.com/matyushkin/djvu-rs/commit/b65bd817270c21248aa3ec46b140b6fb97a9b683))
* **render:** grayscale output mode — GrayPixmap + render_gray8 ([c13ebb7](https://github.com/matyushkin/djvu-rs/commit/c13ebb75ffa0673e670530bdd7ebe53f311a5044))
* **render:** grayscale output mode — GrayPixmap + render_gray8 (Issue [#15](https://github.com/matyushkin/djvu-rs/issues/15)) ([75d7b37](https://github.com/matyushkin/djvu-rs/commit/75d7b37aed6ce0a6d4d118abc8050b731089a8bf))
* **render:** Lanczos-3 separable resampling (Issue [#50](https://github.com/matyushkin/djvu-rs/issues/50)) ([#60](https://github.com/matyushkin/djvu-rs/issues/60)) ([56817d1](https://github.com/matyushkin/djvu-rs/commit/56817d162a335fe9597d2e65f84e0778ee147c65))
* **render:** permissive render mode — skip corrupted chunks ([dc5734a](https://github.com/matyushkin/djvu-rs/commit/dc5734a088f82b6c5bf7b6cfc06a599a2f342a2b))
* **render:** permissive render mode — skip corrupted chunks (Issue [#19](https://github.com/matyushkin/djvu-rs/issues/19)) ([df5a8d7](https://github.com/matyushkin/djvu-rs/commit/df5a8d715ba8534856d50f570752b8722118c2a0))
* **text:** TextLayer::transform — rotate + scale zone rects for rendered pages (Issue [#46](https://github.com/matyushkin/djvu-rs/issues/46)) ([#53](https://github.com/matyushkin/djvu-rs/issues/53)) ([c4a514e](https://github.com/matyushkin/djvu-rs/commit/c4a514e8bbdd4bccdb0032130b949580ef5306cc))
* **tiff:** TIFF export — multi-page color and bilevel modes (Issue [#48](https://github.com/matyushkin/djvu-rs/issues/48)) ([#58](https://github.com/matyushkin/djvu-rs/issues/58)) ([dc90cc0](https://github.com/matyushkin/djvu-rs/commit/dc90cc049ee7bd299ce6156c9c390c8616bdabca))
* transfer from cos-djvu, remove legacy GPL code, add PD corpus, benchmarks ([33fd496](https://github.com/matyushkin/djvu-rs/commit/33fd4969a691b5445c708b6c5f1ae2f877304f73))
* **ui:** table of contents navigation panel (closes [#60](https://github.com/matyushkin/djvu-rs/issues/60)) ([#298](https://github.com/matyushkin/djvu-rs/issues/298)) ([3fb0b2a](https://github.com/matyushkin/djvu-rs/commit/3fb0b2a94ff19891d6469f95aa381dcf66b7b712))
* user-controllable rotation in RenderOptions ([#35](https://github.com/matyushkin/djvu-rs/issues/35)) ([e0f79a8](https://github.com/matyushkin/djvu-rs/commit/e0f79a80bd3d3b2cc43933debb9a0b290aaea285))


### Bug Fixes

* add missing chunk_data binding in iw44_new doctest ([d1a210b](https://github.com/matyushkin/djvu-rs/commit/d1a210b8b61fabc5c7634282f0bfb8062503dfa3))
* apply gamma correction in all legacy render paths ([#9](https://github.com/matyushkin/djvu-rs/issues/9)) ([#22](https://github.com/matyushkin/djvu-rs/issues/22)) ([dfba614](https://github.com/matyushkin/djvu-rs/commit/dfba614c510d8da150ee76cf62f629f89cff48bc))
* apply page rotation from INFO chunk in render_pixmap and render_coarse ([#10](https://github.com/matyushkin/djvu-rs/issues/10)) ([#24](https://github.com/matyushkin/djvu-rs/issues/24)) ([adec5ee](https://github.com/matyushkin/djvu-rs/commit/adec5eed27bf5f096bad4187a2d88a5349bd07a4))
* **ci:** IJG license allowlist, no_std BTreeMap, clippy errors ([6a2a391](https://github.com/matyushkin/djvu-rs/commit/6a2a39199dffd1aa60cbe916bd2b28a516185dcd))
* clippy errors and fmt — let-chain, ref on let, line wrapping ([b4ba2f8](https://github.com/matyushkin/djvu-rs/commit/b4ba2f87acc234e7b7467f394169775b846c03b5))
* exclude .cargo/config.toml from published package (fixes docs.rs build) ([b9dd0da](https://github.com/matyushkin/djvu-rs/commit/b9dd0dafac62f0d6e12064f431d6b962b6a93e08))
* FGbz multi-color foreground palette — use per-glyph blit index ([#12](https://github.com/matyushkin/djvu-rs/issues/12)) ([#26](https://github.com/matyushkin/djvu-rs/issues/26)) ([7897164](https://github.com/matyushkin/djvu-rs/commit/789716408799e39c0e78e3caeedb051f913d26ac))
* **hard-rule:** eliminate last 5 .expect()/.unwrap() in production code (Issue [#443](https://github.com/matyushkin/djvu-rs/issues/443)) ([#444](https://github.com/matyushkin/djvu-rs/issues/444)) ([e4247ea](https://github.com/matyushkin/djvu-rs/commit/e4247eafc1eabadfac42fb04c318252ac0ebcc71))
* remove deprecated [[licenses.deny]] syntax from deny.toml (cargo-deny v2) ([7971e44](https://github.com/matyushkin/djvu-rs/commit/7971e448cdeb82d8be78910e9f275ecc1b975d65))
* replace all internal cos-djvu/cos_djvu references with djvu-rs/djvu_rs ([03fb17a](https://github.com/matyushkin/djvu-rs/commit/03fb17ae4460ca6baff50235993c6f005ddc08e4))
* update MSRV to 1.88 (let-chains stabilized in 1.88) ([8d5b94f](https://github.com/matyushkin/djvu-rs/commit/8d5b94f9d84c9065662e2464003aa75a95613421))
* vendor djvu-rs into crates/cos-djvu and fix production panics ([5f6d7fe](https://github.com/matyushkin/djvu-rs/commit/5f6d7fecadb7ea3bdcfa5cd530215ff28ea5e133)), closes [#4](https://github.com/matyushkin/djvu-rs/issues/4)


### Performance Improvements

* area-averaging downscale for better quality when rendering at reduced size ([#13](https://github.com/matyushkin/djvu-rs/issues/13)) ([#28](https://github.com/matyushkin/djvu-rs/issues/28)) ([b822ded](https://github.com/matyushkin/djvu-rs/commit/b822ded71372b0f70071f8245768d09b89e62a17))
* **bitmap:** packed bitwise dilation with ping-pong buffers ([2887689](https://github.com/matyushkin/djvu-rs/commit/288768968e910eccfe313785aa316ef8eb0fbdac))
* **bitmap:** packed bitwise dilation with ping-pong buffers (Issue [#17](https://github.com/matyushkin/djvu-rs/issues/17)) ([0814f55](https://github.com/matyushkin/djvu-rs/commit/0814f5519475073c4b426ca91360491c8ad69830))
* eliminate redundant mask sampling in 3-layer composite ([#14](https://github.com/matyushkin/djvu-rs/issues/14)) ([#27](https://github.com/matyushkin/djvu-rs/issues/27)) ([f601036](https://github.com/matyushkin/djvu-rs/commit/f601036e8988c2ea0c4f2a5742cd4b1321bc8065))
* **iw44:** SIMD YCbCr→RGB using wide::i32x8 (Issue [#1](https://github.com/matyushkin/djvu-rs/issues/1)) ([#64](https://github.com/matyushkin/djvu-rs/issues/64)) ([abceef4](https://github.com/matyushkin/djvu-rs/commit/abceef47d2bca524a20d13f4926f4dbf84e3c79b))
* **render:** eliminate redundant mask sampling in 3-layer composite (Issue [#14](https://github.com/matyushkin/djvu-rs/issues/14)) ([#37](https://github.com/matyushkin/djvu-rs/issues/37)) ([585991d](https://github.com/matyushkin/djvu-rs/commit/585991d961978277b8fdaf2b87236f6d1b825ac0))

## [Unreleased]

## [0.3.0] — 2026-04-05

### Added

- **TIFF export** — `djvu_to_tiff` converts DjVu to multi-page TIFF in color (RGB8) or bilevel
  (Gray8) modes; CLI: `djvu render --format tiff`; feature-gated: `--features tiff`
- **BGjp/FGjp JPEG decoder** — DjVu pages with JPEG-encoded background or foreground now render
  correctly; uses `zune-jpeg` (pure Rust, no libjpeg)
- **Async render API** — `djvu_async::render_pixmap_async` / `render_gray8_async` delegate
  CPU-bound IW44/JB2 work to `tokio::task::spawn_blocking`; feature-gated: `--features async`
- **Document metadata** — `metadata::parse_metadata` / `parse_metadata_bzz` extract METa/METz
  chunks; `DjVuMetadata` struct with title, author, date, and arbitrary key-value fields
- **Chunk introspection API** — `DjVuPage::raw_chunk`, `all_chunks`, `chunk_ids`;
  `DjVuDocument::raw_chunk`, `all_chunks` for direct access to IFF chunk data
- **DJVI shared dictionary** — `Sjbz` pages that reference a shared JB2 dictionary via `INCL`
  chunks now decode correctly; fixes rendering of multi-page documents with shared symbol sets
- **TextLayer coordinate transform** — `TextLayer::transform(scale, rotation)` maps zone rectangles
  to the rendered page coordinate system; simplifies hit-testing in viewer applications
- **DCTDecode PDF export** — `pdf::djvu_to_pdf_with_options` encodes page images as JPEG
  (DCTDecode) instead of raw RGB (FlateDecode); typically 5–10× smaller output; `PdfOptions`
  controls JPEG quality (default 80)
- **Lanczos-3 resampling** — `RenderOptions { resampling: Resampling::Lanczos3, .. }` applies a
  two-pass separable 6-tap Lanczos kernel after rendering; sharper thumbnails at the cost of ~5×
  render time vs `Bilinear`
- **Grayscale output** — `djvu_render::render_gray8` returns a `GrayPixmap` (1 byte/pixel);
  CLI: `djvu render --gray`
- **Permissive render mode** — `RenderOptions::permissive = true` skips corrupted or unsupported
  chunks instead of returning an error; useful for broken files in the wild
- **Benchmark suite** — `benches/render.rs` gains `render_scaled` (Bilinear vs Lanczos-3) and
  `pdf_export` benchmarks; `BENCHMARKS.md` documents results on Apple M1 Max and comparison vs
  DjVuLibre 3.5.29
- **Benchmark CI** — `.github/workflows/bench.yml` runs `cargo bench` on `ubuntu-latest` and
  `macos-latest` on every release tag; Criterion HTML reports uploaded as artifacts

### Performance

- **SIMD YCbCr→RGB** — `Iw44Image::to_rgb` now processes 8 pixels per iteration using
  `wide::i32x8` (maps to AVX2 on x86_64, NEON on ARM64, scalar fallback elsewhere); eliminates
  per-pixel overhead in the full-resolution color conversion hot path
- **Packed bitwise mask dilation** — `Bitmap::dilate` uses bitwise OR on packed `u64` words
  instead of per-pixel loops; 2–4× faster for bold-text rendering
- **Composite optimisation** — eliminated redundant mask sampling in the 3-layer composite loop

### Fixed

- **Permissive mode robustness** — decode pipeline no longer panics on documents with missing or
  truncated BG44/FG44 chunks when `permissive = true`

## [0.2.1] — 2026-04-04

### Fixed

- Exclude `.cargo/config.toml` from published package — it contained `-D warnings` which caused
  docs.rs builds to fail silently

## [0.2.0] — 2026-04-04

### Added

- **Structural PDF export** — `djvu render --format pdf` now produces searchable PDFs with selectable
  text (from TXTz/TXTa), bookmarks (NAVM → PDF outline), and hyperlinks (ANTz → PDF link annotations)
- **Mask / layer extraction API** — `DjVuPage::extract_mask()`, `extract_foreground()`,
  `extract_background()`; CLI: `djvu render --layer mask|fg|bg`
- **`RenderOptions::fit_to_width` / `fit_to_height` / `fit_to_box`** — aspect-preserving smart scaling
  helpers that respect page rotation
- **User-controllable rotation** — `RenderOptions::rotation` overrides the INFO chunk value

### Fixed

- **Gamma correction** — gamma LUT now applied in all render paths (`render_pixmap`, `render_coarse`,
  `render_progressive`, rotation branches)
- **Page rotation** — `render_pixmap` and `render_coarse` now apply the rotation from the INFO chunk;
  output dimensions swap correctly for 90°/270° pages
- **FGbz multi-color foreground** — per-glyph blit index is now used when compositing; documents with
  multi-color foreground (stamps, colored annotations) render correctly

### Performance

- **Area-averaging downscale** — render at scale < 1.0 now uses box-filter averaging instead of
  bilinear; better anti-aliasing and ~2× faster for thumbnail/overview sizes
- **Composite optimisation** — eliminated redundant mask sampling in 3-layer composite loop

### Refactored

- **Removed `ouroboros` dependency** — `Document` is now a fully owned struct; no self-referential
  proc-macro required; `lib.rs` is now truly `unsafe`-free

## [0.1.0] — 2026-04-04

### Added

- **IFF container parser** — zero-copy, borrowing slices from input (`iff::parse_form`)
- **JB2 bilevel image decoder** — ZP adaptive arithmetic coding with symbol dictionary (`jb2_new`)
- **IW44 wavelet image decoder** — planar YCbCr storage, progressive multi-chunk refinement (`iw44_new`)
- **BZZ decompressor** — ZP + MTF + BWT for DIRM, NAVM, ANTz chunks (`bzz_new`)
- **Text layer extraction** — TXTz/TXTa chunk parsing with full zone hierarchy (`text`)
- **Annotation parsing** — ANTz/ANTa chunks: hyperlinks, map areas, background color (`annotation`)
- **Bookmarks** — NAVM table-of-contents parsing (`DjVuDocument::bookmarks`)
- **Multi-page documents** — DJVM bundle format with DIRM directory chunk
- **Page rendering** — composite foreground mask + background wavelet into RGBA output
- **Progressive rendering** — incremental BG44 wavelet refinement (`Page::render_scaled_progressive`)
- **Thumbnails** — TH44 embedded thumbnail extraction (`Page::thumbnail`)
- **High-level API** — `Document` / `Page` (requires `std` feature)
- **New document model** — `DjVuDocument` / `DjVuPage` built on clean-room codecs
- **CLI tool** — `djvu info`, `djvu render --format png|pdf|cbz`, `djvu text` subcommands
- **Rasterized PDF export** — `djvu render --format pdf` embeds each page as an RGB image (FlateDecode)
- **CBZ export** — `djvu render --format cbz` produces a comic-book ZIP with PNG pages
- **`no_std` support** — IFF/BZZ/JB2/IW44/ZP modules work with `alloc` only

[Unreleased]: https://github.com/matyushkin/djvu-rs/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/matyushkin/djvu-rs/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/matyushkin/djvu-rs/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/matyushkin/djvu-rs/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/matyushkin/djvu-rs/releases/tag/v0.1.0
