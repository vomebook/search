//! Benchmarks for full DjVu page rendering at various DPI settings.
//!
//! Uses real DjVu test files from the references/ and tests/corpus/ directories.
//! Benchmarks are skipped gracefully if the test files are not found.

// These harnesses build `RenderOptions` literals that still name the deprecated
// `scale` field (now ignored — the pipeline derives the decode scale from
// `width`; see #377). Allowed here so the perf harness keeps building while the
// back-compat field exists.
#![allow(deprecated)]

use std::hint::black_box;
use std::time::Duration;

use criterion::{BenchmarkId, Criterion, criterion_group, criterion_main};
use std::path::PathBuf;

fn assets_path() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("references/djvujs/library/assets")
}

fn corpus_path() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/corpus")
}

fn render_opts(width: u32, height: u32, scale: f32) -> djvu_rs::djvu_render::RenderOptions {
    djvu_rs::djvu_render::RenderOptions {
        width,
        height,
        scale,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    }
}

/// Load a DjVuDocument from a test file, returning None if not found.
fn load_doc(filename: &str) -> Option<djvu_rs::DjVuDocument> {
    let path = assets_path().join(filename);
    let data = std::fs::read(&path).ok()?;
    djvu_rs::DjVuDocument::parse(&data).ok()
}

fn bench_render_at_dpi(c: &mut Criterion) {
    let doc = match load_doc("boy.djvu") {
        Some(d) => d,
        None => {
            eprintln!("skipping bench_render_at_dpi: boy.djvu not found");
            return;
        }
    };

    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => {
            eprintln!("skipping bench_render_at_dpi: failed to get page 0");
            return;
        }
    };

    let native_w = page.width() as u32;
    let native_h = page.height() as u32;
    let native_dpi = page.dpi() as f32;

    let mut group = c.benchmark_group("render_page");

    for &dpi in &[72u32, 144u32, 300u32, 600u32] {
        let scale = dpi as f32 / native_dpi;
        let w = ((native_w as f32 * scale).round() as u32).max(1);
        let h = ((native_h as f32 * scale).round() as u32).max(1);

        let opts = djvu_rs::djvu_render::RenderOptions {
            width: w,
            height: h,
            scale,
            bold: 0,
            aa: false,
            rotation: djvu_rs::djvu_render::UserRotation::None,
            permissive: false,
            resampling: djvu_rs::djvu_render::Resampling::Bilinear,
            mask_aa: false,
        };

        group.bench_with_input(BenchmarkId::new("dpi", dpi), &opts, |b, opts| {
            b.iter(|| {
                let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(opts));
            });
        });
    }

    group.finish();
}

fn bench_render_coarse(c: &mut Criterion) {
    let doc = match load_doc("boy.djvu") {
        Some(d) => d,
        None => {
            eprintln!("skipping bench_render_coarse: boy.djvu not found");
            return;
        }
    };

    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => {
            eprintln!("skipping bench_render_coarse: failed to get page 0");
            return;
        }
    };

    let opts = djvu_rs::djvu_render::RenderOptions {
        width: page.width() as u32,
        height: page.height() as u32,
        scale: 1.0,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    };

    let request = djvu_rs::djvu_render::RenderRequest::new(opts)
        .quality(djvu_rs::djvu_render::Quality::Coarse);
    c.bench_function("render_coarse", |b| {
        b.iter(|| {
            let _ = black_box(&request).pixmap(black_box(page));
        });
    });
}

/// Benchmark rendering a color page from the public domain corpus.
fn bench_render_corpus_color(c: &mut Criterion) {
    let path = corpus_path().join("watchmaker.djvu");
    let data = match std::fs::read(&path) {
        Ok(d) => d,
        Err(_) => {
            eprintln!(
                "skipping bench_render_corpus_color: watchmaker.djvu not found in tests/corpus/"
            );
            return;
        }
    };
    let doc = match djvu_rs::DjVuDocument::parse(&data) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("skipping bench_render_corpus_color: failed to parse watchmaker.djvu");
            return;
        }
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => {
            eprintln!("skipping bench_render_corpus_color: failed to get page 0");
            return;
        }
    };
    let opts = djvu_rs::djvu_render::RenderOptions {
        width: page.width() as u32,
        height: page.height() as u32,
        scale: 1.0,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    };
    c.bench_function("render_corpus_color", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts));
        });
    });
}

/// Benchmark rendering a bilevel (JB2-only) page from the public domain corpus.
fn bench_render_corpus_bilevel(c: &mut Criterion) {
    let path = corpus_path().join("cable_1973_100133.djvu");
    let data = match std::fs::read(&path) {
        Ok(d) => d,
        Err(_) => {
            eprintln!(
                "skipping bench_render_corpus_bilevel: cable_1973_100133.djvu not found in tests/corpus/"
            );
            return;
        }
    };
    let doc = match djvu_rs::DjVuDocument::parse(&data) {
        Ok(d) => d,
        Err(_) => {
            eprintln!(
                "skipping bench_render_corpus_bilevel: failed to parse cable_1973_100133.djvu"
            );
            return;
        }
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => {
            eprintln!("skipping bench_render_corpus_bilevel: failed to get page 0");
            return;
        }
    };
    let opts = djvu_rs::djvu_render::RenderOptions {
        width: page.width() as u32,
        height: page.height() as u32,
        scale: 1.0,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    };
    c.bench_function("render_corpus_bilevel", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts));
        });
    });
}

/// Stage-level breakdown for the native-resolution corpus pages used in the
/// DjVuLibre comparison matrix.
///
/// The `render_pixmap` case includes output pixmap allocation and any adapter
/// copies; `render_into_reuse_buffer` isolates strict compositing into an
/// already-allocated RGBA buffer; `render_streaming_discard` measures the
/// row-streaming path without retaining the full output image. The decode stages
/// explain how much of the native color/bilevel gap is codec work vs output
/// materialization.
fn bench_render_native_stage_breakdown(c: &mut Criterion) {
    let cases = [
        ("watchmaker_color", "watchmaker.djvu"),
        ("cable_bilevel", "cable_1973_100133.djvu"),
    ];

    let mut group = c.benchmark_group("render_native_stages");
    // Diagnostic stage breakdown — used when actively optimizing a stage, not as
    // the per-PR regression gate. Reduced sampling keeps PR bench time tractable;
    // the end-to-end render benches carry the regression signal at full fidelity.
    group.sample_size(10);
    group.warm_up_time(Duration::from_secs(1));
    group.measurement_time(Duration::from_secs(2));

    for (label, filename) in cases {
        let path = corpus_path().join(filename);
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping render_native_stages/{label}: {filename} not found");
                continue;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping render_native_stages/{label}: parse failed");
                continue;
            }
        };
        let page = match doc.page(0) {
            Ok(p) => p,
            Err(_) => continue,
        };
        let opts = djvu_rs::djvu_render::RenderOptions {
            width: page.width() as u32,
            height: page.height() as u32,
            scale: 1.0,
            bold: 0,
            aa: false,
            rotation: djvu_rs::djvu_render::UserRotation::None,
            permissive: false,
            resampling: djvu_rs::djvu_render::Resampling::Bilinear,
            mask_aa: false,
        };
        let buf_len = opts.width as usize * opts.height as usize * 4;

        // Warm page-level decode caches so the render stages focus on hot render
        // work, matching the DjVuLibre render-only comparison harness.
        let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts));

        group.bench_function(BenchmarkId::new("render_pixmap", label), |b| {
            b.iter(|| {
                black_box(
                    djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts))
                        .expect("render_pixmap"),
                );
            });
        });

        let mut buf = vec![0u8; buf_len];
        group.bench_function(BenchmarkId::new("render_into_reuse_buffer", label), |b| {
            b.iter(|| {
                djvu_rs::djvu_render::RenderRequest::new(black_box(&opts).clone())
                    .write_rgba(black_box(page), black_box(buf.as_mut_slice()))
                    .expect("render_into");
                black_box(&buf);
            });
        });

        group.bench_function(BenchmarkId::new("render_streaming_discard", label), |b| {
            b.iter(|| {
                let mut bytes = 0usize;
                djvu_rs::djvu_render::RenderRequest::new(black_box(&opts).clone())
                    .rows(black_box(page), |_, row| {
                        bytes = bytes.wrapping_add(row.len())
                    })
                    .expect("render_streaming");
                black_box(bytes);
            });
        });

        if page.find_chunk(b"Sjbz").is_some() {
            group.bench_function(BenchmarkId::new("mask_decode", label), |b| {
                b.iter(|| {
                    black_box(page.extract_mask().expect("mask decode"));
                });
            });
        }

        if page.find_chunk(b"BG44").is_some() {
            group.bench_function(BenchmarkId::new("bg_to_rgb_warm", label), |b| {
                b.iter(|| {
                    if let Some(img) = page.decoded_bg44() {
                        black_box(img.to_rgb_subsample(1).expect("BG44 to RGB"));
                    }
                });
            });
        }
    }

    group.finish();
}

/// Compositor-only baselines for cached pages.
///
/// Each case first runs `render_pixmap` once to populate page-level decode
/// caches, then measures strict `render_into` into a reused RGBA buffer. These
/// benches intentionally exclude parse/decode setup and output allocation.
fn bench_render_compositor_only(c: &mut Criterion) {
    let cases = [
        (
            "color_native_cached",
            corpus_path().join("watchmaker.djvu"),
            1.0_f32,
        ),
        (
            "bilevel_native_cached",
            corpus_path().join("cable_1973_100133.djvu"),
            1.0_f32,
        ),
        (
            "color_downscale_cached",
            assets_path().join("colorbook.djvu"),
            150.0_f32 / 400.0_f32,
        ),
        (
            "color_downscale_mixed_cached",
            corpus_path().join("watchmaker.djvu"),
            150.0_f32 / 300.0_f32,
        ),
        (
            "small_color_downscale_cached",
            assets_path().join("boy.djvu"),
            0.5_f32,
        ),
        (
            // FGbz-palette page: exercises the cached indexed-mask + blit-map
            // path (decoded_mask_indexed). 2550×3300, native resolution.
            "palette_native_cached",
            PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/navm_fgbz.djvu"),
            1.0_f32,
        ),
    ];

    let mut group = c.benchmark_group("render_compositor_only");
    // Diagnostic compositor baseline — reduced sampling (see render_native_stages).
    group.sample_size(10);
    group.warm_up_time(Duration::from_secs(1));
    group.measurement_time(Duration::from_secs(2));

    for (label, path, scale) in cases {
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!(
                    "skipping render_compositor_only/{label}: {} not found",
                    path.display()
                );
                continue;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping render_compositor_only/{label}: parse failed");
                continue;
            }
        };
        let page = match doc.page(0) {
            Ok(p) => p,
            Err(_) => {
                eprintln!("skipping render_compositor_only/{label}: page 0 missing");
                continue;
            }
        };

        let width = ((page.width() as f32 * scale).round() as u32).max(1);
        let height = ((page.height() as f32 * scale).round() as u32).max(1);
        let opts = render_opts(width, height, scale);
        let mut buf = vec![0u8; width as usize * height as usize * 4];

        djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts))
            .expect("warm render caches");

        group.bench_function(label, |b| {
            b.iter(|| {
                djvu_rs::djvu_render::RenderRequest::new(black_box(&opts).clone())
                    .write_rgba(black_box(page), black_box(buf.as_mut_slice()))
                    .expect("render_into");
                black_box(&buf);
            });
        });
    }

    group.finish();
}

/// A/B current direct `render_into` against a row-scratch adapter that copies
/// `render_streaming` rows into the final RGBA buffer. This is intentionally a
/// measurement harness for #294; render behavior is unchanged by the bench.
fn bench_render_row_scratch_ab(c: &mut Criterion) {
    let cases = [
        (
            "thumbnail_dpi72",
            assets_path().join("boy.djvu"),
            72.0_f32 / 100.0_f32,
        ),
        (
            "thumbnail_half_bilinear",
            assets_path().join("boy.djvu"),
            0.5_f32,
        ),
        (
            "colorbook_downscale",
            assets_path().join("colorbook.djvu"),
            150.0_f32 / 400.0_f32,
        ),
        (
            "corpus_color_native",
            corpus_path().join("watchmaker.djvu"),
            1.0_f32,
        ),
        (
            "corpus_bilevel_native",
            corpus_path().join("cable_1973_100133.djvu"),
            1.0_f32,
        ),
    ];

    let mut group = c.benchmark_group("render_row_scratch_ab");
    group.sample_size(10);
    group.warm_up_time(Duration::from_secs(1));
    group.measurement_time(Duration::from_secs(2));

    for (label, path, scale) in cases {
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!(
                    "skipping render_row_scratch_ab/{label}: {} not found",
                    path.display()
                );
                continue;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping render_row_scratch_ab/{label}: parse failed");
                continue;
            }
        };
        let page = match doc.page(0) {
            Ok(p) => p,
            Err(_) => {
                eprintln!("skipping render_row_scratch_ab/{label}: page 0 missing");
                continue;
            }
        };

        let width = ((page.width() as f32 * scale).round() as u32).max(1);
        let height = ((page.height() as f32 * scale).round() as u32).max(1);
        let opts = render_opts(width, height, scale);
        let mut direct_buf = vec![0u8; width as usize * height as usize * 4];
        let mut scratch_buf = vec![0u8; direct_buf.len()];

        djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts))
            .expect("warm render caches");

        group.bench_function(BenchmarkId::new("direct_render_into", label), |b| {
            b.iter(|| {
                djvu_rs::djvu_render::RenderRequest::new(black_box(&opts).clone())
                    .write_rgba(black_box(page), black_box(direct_buf.as_mut_slice()))
                    .expect("render_into");
                black_box(&direct_buf);
            });
        });

        group.bench_function(BenchmarkId::new("row_scratch_copy", label), |b| {
            b.iter(|| {
                djvu_rs::djvu_render::RenderRequest::new(black_box(&opts).clone())
                    .rows(black_box(page), |y, row| {
                        let start = y * width as usize * 4;
                        scratch_buf[start..start + row.len()].copy_from_slice(row);
                    })
                    .expect("render_streaming");
                black_box(&scratch_buf);
            });
        });
    }

    group.finish();
}

/// Benchmark 0.5× scaling with Bilinear vs Lanczos3 resampling on a color page.
///
/// Lanczos3 re-renders at native resolution first, so the difference reveals
/// the cost of the two-pass separable kernel vs the built-in bilinear compositor.
fn bench_render_scaled(c: &mut Criterion) {
    let doc = match load_doc("boy.djvu") {
        Some(d) => d,
        None => {
            eprintln!("skipping bench_render_scaled: boy.djvu not found");
            return;
        }
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => {
            eprintln!("skipping bench_render_scaled: failed to get page 0");
            return;
        }
    };

    let native_w = page.width() as u32;
    let native_h = page.height() as u32;
    let half_w = (native_w / 2).max(1);
    let half_h = (native_h / 2).max(1);

    let mut group = c.benchmark_group("render_scaled_0.5x");

    let opts_bilinear = djvu_rs::djvu_render::RenderOptions {
        width: half_w,
        height: half_h,
        scale: 0.5,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    };
    group.bench_function("bilinear", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts_bilinear));
        });
    });

    let opts_lanczos = djvu_rs::djvu_render::RenderOptions {
        width: half_w,
        height: half_h,
        scale: 0.5,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Lanczos3,
        mask_aa: false,
    };
    group.bench_function("lanczos3", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts_lanczos));
        });
    });

    group.finish();
}

/// Benchmark Lanczos-3 downscale on a LARGE colour page (colorbook, 2260×3669).
///
/// `render_scaled_0.5x` uses boy.djvu (192×256) — far too small to show the
/// PAR_LANCZOS row-parallel win. This scales colorbook to half (1130×1834),
/// where the separable Lanczos passes do real work. `bilinear` is the control
/// (same decode, no Lanczos post-pass); the `lanczos3 − bilinear` gap is the
/// resampling cost being parallelised. Run under `--features parallel` to see
/// the row-parallel speedup vs the default sequential build.
fn bench_render_scaled_large(c: &mut Criterion) {
    let doc = match load_doc("colorbook.djvu") {
        Some(d) => d,
        None => {
            eprintln!("skipping bench_render_scaled_large: colorbook.djvu not found");
            return;
        }
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => return,
    };
    let nw = page.width() as u32;
    let nh = page.height() as u32;
    let (hw, hh) = ((nw / 2).max(1), (nh / 2).max(1));

    // Warm decode caches so we measure the resampling passes, not cold decode.
    let _ = djvu_rs::djvu_render::render_pixmap(page, &render_opts(hw, hh, 0.5));

    let mut group = c.benchmark_group("render_scaled_large_colorbook");
    group.sample_size(20);
    let mut o_bilin = render_opts(hw, hh, 0.5);
    o_bilin.resampling = djvu_rs::djvu_render::Resampling::Bilinear;
    let mut o_lancz = render_opts(hw, hh, 0.5);
    o_lancz.resampling = djvu_rs::djvu_render::Resampling::Lanczos3;
    group.bench_function("bilinear", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&o_bilin));
        });
    });
    group.bench_function("lanczos3", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&o_lancz));
        });
    });
    group.finish();
}

/// Benchmark rendering a large color page available in the references directory.
///
/// Uses `colorbook.djvu` (2260×3669 px, 400 dpi, color IW44), rendered at 150 dpi
/// so the output (848×1377 px) is representative of a typical document-viewer request
/// and comparable to the corpus `watchmaker.djvu` benchmark.
fn bench_render_colorbook(c: &mut Criterion) {
    let doc = match load_doc("colorbook.djvu") {
        Some(d) => d,
        None => {
            eprintln!("skipping bench_render_colorbook: colorbook.djvu not found");
            return;
        }
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => {
            eprintln!("skipping bench_render_colorbook: failed to get page 0");
            return;
        }
    };

    let native_dpi = page.dpi() as f32;
    let target_dpi = 150_f32;
    let scale = target_dpi / native_dpi;
    let w = ((page.width() as f32 * scale).round() as u32).max(1);
    let h = ((page.height() as f32 * scale).round() as u32).max(1);

    let opts = djvu_rs::djvu_render::RenderOptions {
        width: w,
        height: h,
        scale,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    };

    c.bench_function("render_colorbook", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts));
        });
    });
}

/// Micro-benchmarks for individual render pipeline stages on colorbook page 0.
///
/// Separates: background decode, mask decode, FG44 decode, composite.
fn bench_render_colorbook_stages(c: &mut Criterion) {
    let path = assets_path().join("colorbook.djvu");
    let data = match std::fs::read(&path) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("skipping bench_render_colorbook_stages: colorbook.djvu not found");
            return;
        }
    };
    let doc = match djvu_rs::DjVuDocument::parse(&data) {
        Ok(d) => d,
        Err(_) => return,
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => return,
    };
    let native_dpi = page.dpi() as f32;
    let target_dpi = 150_f32;
    let scale = target_dpi / native_dpi;
    let w = ((page.width() as f32 * scale).round() as u32).max(1);
    let h = ((page.height() as f32 * scale).round() as u32).max(1);
    let opts = djvu_rs::djvu_render::RenderOptions {
        width: w,
        height: h,
        scale,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    };

    // Warm the bg cache (decoded_bg44_partial) — we want to measure each stage in isolation.
    let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts));

    let mut group = c.benchmark_group("render_colorbook_stages");
    // Diagnostic stage breakdown — reduced sampling (see render_native_stages).
    group.sample_size(10);
    group.warm_up_time(Duration::from_secs(1));
    group.measurement_time(Duration::from_secs(2));

    // Stage 1: full render (reference)
    group.bench_function("full_render", |b| {
        b.iter(|| {
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts));
        });
    });

    // Stage 2: background only (BG44 → pixmap, warm cache)
    group.bench_function("bg_only_warm", |b| {
        b.iter(|| {
            let _ = page.decoded_bg44_partial();
        });
    });

    // Stage 3: JB2 mask decode only
    group.bench_function("mask_decode", |b| {
        b.iter(|| {
            let _ = black_box(page.extract_mask());
        });
    });

    group.finish();
}

/// Cold-path benchmark: parse document + render at 150 dpi inside the loop.
///
/// Each iteration recreates the document (and therefore the IW44 decode cache),
/// measuring the true first-render cost: ZP arithmetic decode + wavelet + RGB.
/// This is the scenario that benefits most from partial chunk decode.
fn bench_render_colorbook_cold(c: &mut Criterion) {
    let path = assets_path().join("colorbook.djvu");
    let data = match std::fs::read(&path) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("skipping bench_render_colorbook_cold: colorbook.djvu not found");
            return;
        }
    };

    // Parse once to read page geometry; re-parse inside iter to reset caches.
    let doc0 = match djvu_rs::DjVuDocument::parse(&data) {
        Ok(d) => d,
        Err(_) => return,
    };
    let page0 = match doc0.page(0) {
        Ok(p) => p,
        Err(_) => return,
    };
    let native_dpi = page0.dpi() as f32;
    let target_dpi = 150_f32;
    let scale = target_dpi / native_dpi;
    let w = ((page0.width() as f32 * scale).round() as u32).max(1);
    let h = ((page0.height() as f32 * scale).round() as u32).max(1);

    let opts = djvu_rs::djvu_render::RenderOptions {
        width: w,
        height: h,
        scale,
        bold: 0,
        aa: false,
        rotation: djvu_rs::djvu_render::UserRotation::None,
        permissive: false,
        resampling: djvu_rs::djvu_render::Resampling::Bilinear,
        mask_aa: false,
    };

    c.bench_function("render_colorbook_cold", |b| {
        b.iter(|| {
            // Re-parse to get a fresh page with empty caches.
            let doc = djvu_rs::DjVuDocument::parse(black_box(&data)).unwrap();
            let page = doc.page(0).unwrap();
            let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(&opts));
        });
    });
}

/// Benchmark full DjVu→PDF export pipeline (render + DCTDecode JPEG compression).
/// Only compiled/run with `--features pdf` (the module is feature-gated); the
/// body is a no-op otherwise so registration stays unconditional.
#[allow(unused_variables)]
fn bench_pdf_export(c: &mut Criterion) {
    #[cfg(feature = "pdf")]
    {
        let path = corpus_path().join("watchmaker.djvu");
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping bench_pdf_export: watchmaker.djvu not found in tests/corpus/");
                return;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping bench_pdf_export: failed to parse watchmaker.djvu");
                return;
            }
        };

        c.bench_function("pdf_export_sequential", |b| {
            b.iter(|| {
                let _ = djvu_rs::pdf::djvu_to_pdf(black_box(&doc));
            });
        });

        // pdf_export_parallel calls the same API as pdf_export_sequential; the difference
        // is that this binary was compiled with --features parallel, so djvu_to_pdf uses
        // rayon internally. To compare the two, run each in a separate cargo bench invocation:
        //   cargo bench --bench render --features std          -- pdf_export_sequential
        //   cargo bench --bench render --features std,parallel -- pdf_export_parallel
        #[cfg(feature = "parallel")]
        c.bench_function("pdf_export_parallel", |b| {
            b.iter(|| {
                let _ = djvu_rs::pdf::djvu_to_pdf(black_box(&doc));
            });
        });
    }
}

/// Benchmark bilevel corpus page at multiple DPIs to measure anti-aliased downscale.
///
/// Unlike `bench_render_corpus_bilevel` (which renders at 1:1 and never enters the
/// downscale path), this benchmark covers 72 and 150 DPI where `mask_box_coverage`
/// is active in `composite_rows_bilevel_one`.
fn bench_render_corpus_bilevel_dpi(c: &mut Criterion) {
    let path = corpus_path().join("cable_1973_100133.djvu");
    let data = match std::fs::read(&path) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("skipping bench_render_corpus_bilevel_dpi: cable_1973_100133.djvu not found");
            return;
        }
    };
    let doc = match djvu_rs::DjVuDocument::parse(&data) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("skipping bench_render_corpus_bilevel_dpi: parse failed");
            return;
        }
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => {
            eprintln!("skipping bench_render_corpus_bilevel_dpi: no page 0");
            return;
        }
    };

    let native_w = page.width() as u32;
    let native_h = page.height() as u32;
    let native_dpi = page.dpi() as f32;

    let mut group = c.benchmark_group("render_corpus_bilevel_dpi");
    group.measurement_time(Duration::from_secs(8));

    for &dpi in &[72u32, 150u32, 300u32] {
        let scale = dpi as f32 / native_dpi;
        let w = ((native_w as f32 * scale).round() as u32).max(1);
        let h = ((native_h as f32 * scale).round() as u32).max(1);
        let opts = render_opts(w, h, scale);
        group.bench_with_input(BenchmarkId::new("dpi", dpi), &opts, |b, opts| {
            b.iter(|| {
                let _ = djvu_rs::djvu_render::render_pixmap(black_box(page), black_box(opts));
            });
        });
    }

    group.finish();
}

/// Render a byte-aligned bilevel viewport via `render_region`. Exercises the
/// generalized P2 BILEVEL_RGBA fast path for `offset_x % 8 == 0` (#433).
fn bench_render_region_bilevel(c: &mut Criterion) {
    let path = corpus_path().join("cable_1973_100133.djvu");
    let data = match std::fs::read(&path) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("skipping bench_render_region_bilevel: cable not found");
            return;
        }
    };
    let doc = match djvu_rs::DjVuDocument::parse(&data) {
        Ok(d) => d,
        Err(_) => return,
    };
    let page = match doc.page(0) {
        Ok(p) => p,
        Err(_) => return,
    };
    let full_w = page.width() as u32;
    let full_h = page.height() as u32;
    let opts = render_opts(full_w, full_h, 1.0);
    // Warm decode caches.
    let _ = djvu_rs::djvu_render::render_pixmap(page, &opts);
    // A tall byte-aligned viewport down the middle of the page.
    let region = djvu_rs::djvu_render::RenderRect {
        x: 1024,
        y: 0,
        width: 512,
        height: full_h,
    };
    let request = djvu_rs::djvu_render::RenderRequest::new(opts).region(region);
    c.bench_function("render_region_bilevel", |b| {
        b.iter(|| {
            let _ = black_box(&request).pixmap(black_box(page));
        });
    });
}

/// PDF export with lossless FlateDecode (`jpeg_quality: None`) instead of the
/// default JPEG backgrounds. Isolates the RGBA→RGB conversion + deflate path
/// (where JPEG CPU no longer dominates), so `export_common::rgba_row_to_rgb` and
/// the deflate glue become the measurable cost. Multi-page watchmaker.
/// Only compiled/run with `--features pdf`; no-op body otherwise.
#[allow(unused_variables)]
fn bench_pdf_export_flatdecode(c: &mut Criterion) {
    #[cfg(feature = "pdf")]
    {
        let path = corpus_path().join("watchmaker.djvu");
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping bench_pdf_export_flatdecode: watchmaker.djvu not found");
                return;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => return,
        };
        let opts = djvu_rs::pdf::PdfOptions {
            mrc: false,
            jpeg_quality: None,
            output_dpi: 150,
            adaptive_raster: false,
            ccitt_g4: false,
        };
        let mut group = c.benchmark_group("export");
        group.sample_size(10);
        group.bench_function("pdf_flatdecode", |b| {
            b.iter(|| {
                let _ = djvu_rs::pdf::djvu_to_pdf_with_options(black_box(&doc), black_box(&opts));
            });
        });
        group.finish();
    }
}

/// EPUB export (`djvu_to_epub`) — per-page render → PNG encode → ZIP assembly.
/// Only compiled/run with `--features epub` (the module is feature-gated); the
/// body is a no-op otherwise so registration stays unconditional. Multi-page
/// watchmaker.
#[allow(unused_variables)]
fn bench_epub_export(c: &mut Criterion) {
    #[cfg(feature = "epub")]
    {
        let path = corpus_path().join("watchmaker.djvu");
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping bench_epub_export: watchmaker.djvu not found");
                return;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => return,
        };
        let opts = djvu_rs::epub::EpubOptions::default();
        let mut group = c.benchmark_group("export");
        group.sample_size(10);
        group.bench_function("epub", |b| {
            b.iter(|| {
                let _ = djvu_rs::epub::djvu_to_epub(black_box(&doc), black_box(&opts));
            });
        });
        group.finish();
    }
}

/// TIFF export (`djvu_to_tiff`) — per-page render → RGB strip → multi-IFD TIFF.
/// Only compiled/run with `--features tiff`; the body is a no-op otherwise so
/// registration stays unconditional. Multi-page watchmaker, color mode.
#[allow(unused_variables)]
fn bench_tiff_export(c: &mut Criterion) {
    #[cfg(feature = "tiff")]
    {
        let path = corpus_path().join("watchmaker.djvu");
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping bench_tiff_export: watchmaker.djvu not found");
                return;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => return,
        };
        let opts = djvu_rs::tiff_export::TiffOptions::default();
        let mut group = c.benchmark_group("export");
        group.sample_size(10);
        group.bench_function("tiff", |b| {
            b.iter(|| {
                let _ = djvu_rs::tiff_export::djvu_to_tiff(black_box(&doc), black_box(&opts));
            });
        });
        group.finish();
    }
}

/// CBZ export (`djvu_to_cbz`) — per-page render → PNG encode → stored ZIP.
/// Only compiled/run with `--features cbz`; page building parallelises under
/// `parallel` (#598). Multi-page watchmaker at the 150-dpi default.
#[allow(unused_variables)]
fn bench_cbz_export(c: &mut Criterion) {
    #[cfg(feature = "cbz")]
    {
        let path = corpus_path().join("watchmaker.djvu");
        let data = match std::fs::read(&path) {
            Ok(d) => d,
            Err(_) => {
                eprintln!("skipping bench_cbz_export: watchmaker.djvu not found");
                return;
            }
        };
        let doc = match djvu_rs::DjVuDocument::parse(&data) {
            Ok(d) => d,
            Err(_) => return,
        };
        let opts = djvu_rs::cbz::CbzOptions::default();
        let mut group = c.benchmark_group("export");
        group.sample_size(10);
        group.bench_function("cbz", |b| {
            b.iter(|| {
                let _ = djvu_rs::cbz::djvu_to_cbz(black_box(&doc), black_box(&opts));
            });
        });
        group.finish();
    }
}

criterion_group!(
    benches,
    bench_render_region_bilevel,
    bench_render_at_dpi,
    bench_render_coarse,
    bench_render_colorbook,
    bench_render_colorbook_stages,
    bench_render_colorbook_cold,
    bench_render_corpus_color,
    bench_render_corpus_bilevel,
    bench_render_corpus_bilevel_dpi,
    bench_render_native_stage_breakdown,
    bench_render_compositor_only,
    bench_render_row_scratch_ab,
    bench_render_scaled,
    bench_render_scaled_large,
    bench_pdf_export,
    bench_pdf_export_flatdecode,
    bench_epub_export,
    bench_tiff_export,
    bench_cbz_export,
);
criterion_main!(benches);
