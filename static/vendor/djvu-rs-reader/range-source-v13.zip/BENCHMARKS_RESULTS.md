# Benchmark Results

Platform: Apple Silicon (`arm64`)
OS: macOS 26.3.1 (Darwin 25.3)
Rust: 1.92.0 stable (edition 2024)
Profile: release (opt-level 3, lto = thin)
Date: 2026-05-17

Primary command: `cargo bench --workspace --features cli,tiff`
Render correction command: `cargo bench --bench render -- 'render_corpus_color|render_colorbook' --output-format bencher`
Additional render correction command: `cargo bench --bench render -- 'render_page/dpi|render_corpus_bilevel|render_native_stages' --output-format bencher`

Most Criterion benchmarks use 100 samples, 3 s warm-up, and 5 s measurement;
the bounded `render_row_scratch_ab/*` A/B group uses 10 samples and 1 s warm-up
to keep full-run time practical. Codec, document, and PDF rows below report
Criterion mean point estimates from the post-roadmap full workspace run.
Render rows use targeted reruns after the initial full-workspace render rows
proved non-representative.

Rejected full-workspace render artifact preserved for context:

| Benchmark | Mean | 95% confidence interval |
|-----------|-----:|------------------------:|
| `render_page/dpi/300` | 6.96 ms | 6.01-8.00 ms |
| `render_page/dpi/600` | 42.1 ms | 36.2-48.4 ms |
| `render_colorbook` | 8.78 ms | 7.99-9.73 ms |
| `render_colorbook_cold` | 48.9 ms | 41.1-57.3 ms |
| `render_corpus_color` | 151 ms | 129-175 ms |
| `render_native_stages/render_streaming_discard/watchmaker_color` | 195 ms | 174-218 ms |

Targeted reruns on the same code returned the render rows below to the expected
range. The rejected artifact remains recorded in `PERF_EXPERIMENTS.md` and is
not used for public render claims.

---

## Encoder parity scorecard (#684, 2026-07-13)

The reproducible harness is [`examples/encoder_parity_scorecard.rs`](examples/encoder_parity_scorecard.rs);
methodology and the JSON schema are documented in
[`docs/encoder-parity.md`](docs/encoder-parity.md). It renders each checked-in
corpus page to the same PPM/PBM input, measures DjVuLibre 3.5.29's `c44` or
`cjb2` against the matching archival-safe `PageEncoder` profile, and decodes
both outputs with `ddjvu` for the fidelity gate.

Command used for the measured table:

```sh
cargo run --release --example encoder_parity_scorecard -- \
  --case watchmaker-color --case goody-twoshoes-color \
  --case cable-bilevel --case map-atlas-bilevel \
  --case chinese-cookbook-bilevel --no-ocr --repeats 3 \
  --output target/encoder-parity-2026-07-13.json
```

Platform: macOS Darwin 25.5 / Apple Silicon arm64, Rust 1.92.0,
repository SHA `94636e5`, DjVuLibre 3.5.29. Times are median milliseconds;
RSS is KiB. `c44`/`cjb2` and djvu-rs outputs all passed dimensions and their
mode-specific fidelity gate; the optional Tesseract probe is recorded in the
methodology document.

| Case | Mode | Baseline B | djvu-rs B | Ratio | Baseline ms | djvu-rs ms | Baseline RSS | djvu-rs RSS | Fidelity |
|------|------|-----------:|----------:|------:|------------:|------------:|-------------:|------------:|----------|
| watchmaker | IW44 / `c44` | 665,625 | 692,182 | 1.040× | 481.4 | 269.3 | 145,712 | 161,600 | PSNR 45.28 / 38.73 dB; SSIM 0.9950 / 0.9899 |
| goody two-shoes | IW44 / `c44` | 327,798 | 440,864 | 1.345× | 367.3 | 375.0 | 135,648 | 265,408 | PSNR 40.83 / 26.39 dB; SSIM 0.9808 / 0.9142 |
| cable | JB2 / `cjb2` | 2,248 | 4,720 | 2.100× | 27.2 | 16.6 | 17,088 | 7,824 | pixel-exact / pixel-exact |
| map atlas | JB2 / `cjb2` | 145,592 | 138,672 | 0.952× | 348.6 | 29.6 | 33,792 | 6,736 | pixel-exact / pixel-exact |
| Chinese cookbook | JB2 / `cjb2` | 67 | 140 | 2.090× | 23.1 | 14.1 | 15,104 | 6,320 | pixel-exact / pixel-exact |

`big_scanned_page.djvu` is 62,023,440 pixels and is explicitly skipped by the
default 20M-pixel safety bound. The current result is diagnostic: it records
the gap and guards, but promotes no lossy or experimental JB2 refinement and
does not alter the default archival/lossless bitstream.

---

## Cross-architecture benchmark matrix

Use this table for architecture-sensitive benchmark updates. Every row must
identify the operating system, CPU, Rust toolchain, `target_arch`, relevant
`target_feature`s, and `RUSTFLAGS`; missing architecture cells are kept explicit
so follow-up SIMD work can fill them without changing the schema.

### Platform metadata template

```md
**Platform.**
- OS:
- CPU:
- target_arch:
- target_feature(s):
- Rust:
- RUSTFLAGS:
- Source artifact:
```

### Seed matrix (2026-05-17)

| Target family | OS | CPU / runner | target_arch | target_feature(s) | Rust | RUSTFLAGS | Source artifact | Status |
|---------------|----|--------------|-------------|-------------------|------|-----------|-----------------|--------|
| Apple ARM64 | macOS 26.3.1 (Darwin 25.3) | Apple M1 Max, 10 cores | `aarch64` | ARM64 baseline; NEON available on Apple Silicon | 1.92.0 stable | unset | Post-roadmap full run plus targeted render rerun (2026-05-17) | Current broad Apple ARM64 baseline |
| Linux x86_64 baseline | Ubuntu GitHub-hosted runner | `ubuntu-latest` | `x86_64` | baseline x86-64 codegen | stable from workflow | unset | #189 artifact run `25299920836` from `.github/workflows/bench.yml` `bench-x86-64-v3` validation | Current selected IW44/render baseline |
| Linux x86_64-v3 / AVX2 | Ubuntu GitHub-hosted runner | `ubuntu-latest` | `x86_64` | `avx2` via x86-64-v3 codegen | stable from workflow | `-C target-cpu=x86-64-v3` | `.github/workflows/bench.yml` `bench-x86-64-v3` job; #189 artifact run `25299920836` | Current AVX2 validation exists for selected IW44/render benches |
| wasm32 scalar | macOS 26.3.1 host / Node.js v26.0.0 | Apple M1 Max host running Node.js wasm | `wasm32` | scalar | 1.92.0 stable | unset | `scripts/bench_wasm_simd128.sh` local run (#306) | Current small-fixture wasm baseline |
| wasm32 simd128 | macOS 26.3.1 host / Node.js v26.0.0 | Apple M1 Max host running Node.js wasm | `wasm32` | `simd128` | 1.92.0 stable | `-C target-feature=+simd128` | `scripts/bench_wasm_simd128.sh` local run (#306) | Current small-fixture wasm simd128 baseline |
| Linux aarch64 | Ubuntu GitHub-hosted arm64 runner | `ubuntu-24.04-arm` | `aarch64` | NEON baseline | stable from workflow | unset | `.github/workflows/ci.yml` `Linux aarch64 smoke` job (#305) | CI smoke coverage only; benchmark numbers still missing |

### Architecture-sensitive seed numbers

These rows intentionally cover only measurements that already have trustworthy
source artifacts. Later issues should add rows instead of changing the platform
metadata format.

| Benchmark | Apple ARM64 local | Linux x86_64 baseline | Linux x86_64-v3 / AVX2 | wasm32 scalar | wasm32 simd128 | Linux aarch64 |
|-----------|------------------:|----------------------:|-----------------------:|--------------:|----------------:|--------------:|
| `iw44_decode_corpus_color` | **655 µs** | 1,385,461 ns | 1,123,865 ns | missing | missing | missing |
| `iw44_decode_first_chunk` | **592 µs** | 765,703 ns | 728,565 ns | missing | missing | missing |
| `iw44_to_rgb_colorbook/sub1_full_decode` | **5.73 ms** | 9,231,033 ns | 9,129,333 ns | missing | missing | missing |
| `iw44_to_rgb_colorbook/sub2_partial_decode` | **1.34 ms** | 2,164,523 ns | 2,199,280 ns | missing | missing | missing |
| `iw44_to_rgb_colorbook/sub4_partial_decode` | **347 µs** | 565,640 ns | 583,519 ns | missing | missing | missing |
| `render_colorbook` | **7.22 ms** | 13,072,440 ns | 12,826,562 ns | missing | missing | missing |
| `render_colorbook_cold` | **18.8 ms** | 28,127,606 ns | 27,105,326 ns | missing | missing | missing |
| `render_colorbook_stages/mask_decode` | **4.39 ms** | 5,325,125 ns | 5,107,550 ns | missing | missing | missing |
| `render_corpus_color` | **71.2 ms** | 133,813,976 ns | 133,185,634 ns | missing | missing | missing |
| `wasm_render_150dpi_fresh_doc` | n/a | n/a | n/a | 2.715 ms | 2.548 ms | n/a |
| `wasm_render_150dpi_cached_page` | n/a | n/a | n/a | 2.685 ms | 2.491 ms | n/a |
| `wasm_progressive_150dpi_chunk0` | n/a | n/a | n/a | 2.693 ms | 2.463 ms | n/a |

Notes:

- Apple ARM64 codec values come from the 2026-05-17 post-roadmap full local
  run on Apple M1 Max. Render values come from the targeted rerun after the
  initial full-workspace render rows were rejected as noisy.
- Linux x86_64 baseline and x86_64-v3 values come from the #189 AVX2 validation
  artifact recorded in `PERF_EXPERIMENTS.md`.
- The wasm32 rows come from the Node.js harness added in #306 and are not
  directly comparable to native Criterion rows. Linux aarch64 benchmark cells
  remain missing after #308; #305 only records Linux aarch64 build/test smoke
  coverage, and a future benchmark artifact is needed before filling those
  cells.

### Browser wasm vs djvu.js head-to-head (#596)

Headless Chrome 150.0.0.0 on macOS/Darwin 25.5, same machine, 100 dpi output,
5 measured iterations after 2 warmups. Harness:
`node scripts/bench_wasm_djvujs.mjs --iterations 5 --warmup 2 --json`.
`djvu.js` is `djvujs-dist` 0.5.4 built locally from the npm tarball because this
repo vendors only the shared djvu.js assets under `references/djvujs`, not the
runtime bundle. `simd128` was supported by Chrome. The djvu.js path renders at
native resolution and scales through Canvas to the target dpi; wasm renders
directly at the target dpi. Wasm linear memory reached 446.8 MiB by the end of
the corpus run; Chrome `performance.memory` heap deltas were noisy and are kept
in the raw JSON artifact rather than used as a peak claim.

Selected corpus page, full decode + render:

| Fixture | Class | Output MiB | wasm scalar ms | wasm simd128 ms | djvu.js ms | scalar speedup | simd speedup |
|---|---|---:|---:|---:|---:|---:|---:|
| `tests/corpus/big_scanned_page.djvu` | photo | 36.7 | 849.5 | 617.7 | 6588.2 | 7.8x | 10.7x |
| `tests/corpus/map_atlas_sample.djvu` | line-art | 2.5 | 67.9 | 65.6 | 441.6 | 6.5x | 6.7x |
| `tests/corpus/goody_twoshoes.djvu` | mixed | 1.2 | 35.5 | 30.8 | 269.4 | 7.6x | 8.7x |
| `tests/corpus/chinese_cookbook_sample.djvu` | cjk | 1.2 | 18.9 | 14.6 | 196.3 | 10.4x | 13.4x |
| `tests/corpus/cyrillic_simonovich_co2.djvu` | cyrillic | 1.9 | 2.4 | 2.4 | 21.3 | 8.9x | 8.9x |
| `tests/corpus/war_1812.djvu` | newspaper | 3.5 | 52.2 | 46.0 | 346.0 | 6.6x | 7.5x |
| `references/djvujs/library/assets/colorbook.djvu` | iw44-color | 2.0 | 26.8 | 22.2 | 250.0 | 9.3x | 11.3x |
| `references/djvujs/library/assets/carte.djvu` | carte | 4.6 | 74.5 | 66.8 | 497.5 | 6.7x | 7.4x |
| `references/djvujs/library/assets/boy_jb2.djvu` | jb2-small | 0.0 | 0.3 | 0.3 | 4.6 | 15.3x | 15.3x |

First-page latency on the same fixtures:

| Fixture | wasm scalar ms | wasm simd128 ms | djvu.js ms | scalar speedup | simd speedup |
|---|---:|---:|---:|---:|---:|
| `tests/corpus/big_scanned_page.djvu` | 853.8 | 583.8 | 6610.5 | 7.7x | 11.3x |
| `tests/corpus/map_atlas_sample.djvu` | 67.7 | 64.9 | 443.0 | 6.5x | 6.8x |
| `tests/corpus/goody_twoshoes.djvu` | 35.8 | 31.1 | 266.8 | 7.5x | 8.6x |
| `tests/corpus/chinese_cookbook_sample.djvu` | 18.6 | 14.6 | 198.8 | 10.7x | 13.6x |
| `tests/corpus/cyrillic_simonovich_co2.djvu` | 2.3 | 2.4 | 21.2 | 9.2x | 8.8x |
| `tests/corpus/war_1812.djvu` | 54.0 | 44.7 | 345.0 | 6.4x | 7.7x |
| `references/djvujs/library/assets/colorbook.djvu` | 27.0 | 22.3 | 250.5 | 9.3x | 11.2x |
| `references/djvujs/library/assets/carte.djvu` | 74.2 | 66.8 | 495.1 | 6.7x | 7.4x |
| `references/djvujs/library/assets/boy_jb2.djvu` | 0.3 | 0.3 | 6.9 | 23.0x | 23.0x |

---

## Codec benchmarks (`cargo bench --bench codecs`)

Test files: `references/djvujs/library/assets/` and `tests/corpus/`

| Benchmark | File | Payload | Time (Criterion mean) | Notes |
|-----------|------|---------|--------------|-------|
| `bzz_decode` | navm_fgbz.djvu NAVM | 89 bytes | **70.4 ns** | ZP + MTF + BWT; tiny NAVM chunk |
| `jb2_decode` | boy_jb2.djvu Sjbz | — | **132 µs** | Bilevel JB2 decode, small page |
| `iw44_decode_first_chunk` | boy.djvu BG44 | — | **592 µs** | Single IW44 wavelet chunk |
| `jb2_decode_corpus_bilevel` | cable_1973_100133.djvu Sjbz | — | **427 µs** | Larger bilevel scan |
| `iw44_decode_corpus_color` | watchmaker.djvu first BG44 | — | **655 µs** | Color IW44 chunk |
| `jb2_decode_large_600dpi` | pathogenic_bacteria_1896.djvu page mask | 11,438 bytes | **2.18 µs** | Large-page JB2 mask fast path |
| `iw44_to_rgb_colorbook/sub1_full_decode` | colorbook.djvu | — | **5.73 ms** | Full decode + RGB |
| `iw44_to_rgb_colorbook/sub2_partial_decode` | colorbook.djvu | — | **1.34 ms** | Partial decode at sub=2 |
| `iw44_to_rgb_colorbook/sub4_partial_decode` | colorbook.djvu | — | **347 µs** | Partial decode at sub=4 |
| `iw44_encode_color` | synthetic color page | — | **1.83 ms** | IW44 color encode |
| `iw44_encode_large_1024x1024` | synthetic 1024×1024 page | — | **17.4 ms** | IW44 large encode |
| `jb2_encode` | synthetic bilevel page | — | **174 µs** | JB2 encode |

Note: `bzz_decode` measures the 89-byte NAVM payload in navm_fgbz.djvu. BZZ performance
scales with payload size (BWT requires a full-block sort); large payloads (e.g. 6 KB DIRM
in a 520-page document) take ~1–5 ms.

### JB2 encoder quality baseline (#295)

Measured with `examples/encode_quality_jb2.rs` and
`examples/encode_quality_djbz.rs` on 2026-05-17. See `PERF_EXPERIMENTS.md`
for commands, platform metadata, and failure buckets.

Page-level JB2 corpus refresh:

| Mode | Pages | Bytes | bpp | vs original | Round-trip |
|------|------:|------:|----:|------------:|------------|
| Original `Sjbz` | 692 | 26,569,542 | 0.0263 | 1.000x | source |
| Direct `encode_jb2` | 692 | 46,252,033 | 0.0457 | 1.741x | 464 ok, 228 decode errors |
| Dict `encode_jb2_dict` | 692 | 36,016,741 | 0.0356 | 1.356x | 692 ok |

Shared-Djbz multi-page refresh:

| Mode | Files/pages | Bytes | bpp | vs original | Round-trip |
|------|------------:|------:|----:|------------:|------------|
| Original `Sjbz` totals | 6 / 688 | 26,424,220 | 0.0262 | 1.000x | source |
| Independent dict pages | 6 / 688 | 35,963,419 | 0.0356 | 1.361x | all pages ok |
| Bundled shared-Djbz | 6 / 688 | 34,986,136 | 0.0347 | 1.324x | all bundles ok |

Shared-Djbz is `0.973x` of independent dict output on this run, but the
current safe encoder family remains larger than the source `Sjbz` corpus
overall. The old `483/553` dict round-trip number is stale: dict encoding now
round-trips every refreshed page.

---

## Render benchmarks (`cargo bench --bench render`)

Test file: `references/djvujs/library/assets/boy.djvu` (192×256 px, 100 dpi)
Corpus files: `tests/corpus/`, colorbook: `references/djvujs/library/assets/colorbook.djvu`

### DPI scaling — boy.djvu (IW44 color page, 192×256 native)

| DPI | Approx output size | Time (Criterion mean) |
|-----|--------------------|--------------|
| 72 dpi | ~138×184 px | **246 µs** |
| 144 dpi | ~276×368 px | **938 µs** |
| 300 dpi | ~576×768 px | **3.59 ms** |
| 600 dpi | ~1152×1536 px | **13.9 ms** |

### Full-resolution corpus render

| Benchmark | File | Native size | Time (Criterion mean) | Notes |
|-----------|------|-------------|--------------|-------|
| `render_coarse` | boy.djvu | 192×256 | **3.41 ms** | |
| `render_colorbook` | colorbook.djvu | 2260×3669 (400 dpi) | **7.22 ms** | 150 dpi, warm (sub=4 mask + partial BG44) |
| `render_colorbook_stages/full_render` | colorbook.djvu | 2260×3669 (400 dpi) | **7.26 ms** | Warm full render stage |
| `render_colorbook_stages/mask_decode` | colorbook.djvu | 2260×3669 (400 dpi) | **4.39 ms** | JB2 mask decode stage |
| `render_colorbook_cold` | colorbook.djvu | 2260×3669 (400 dpi) | **18.8 ms** | cold (ZP + wavelet + RGB, first render) |
| `render_corpus_color` | watchmaker.djvu | 2550×3301 | **71.2 ms** | native 600 dpi, full IW44 |
| `render_corpus_bilevel` | cable_1973_100133.djvu | 2550×3301 | **75.4 ms** | native 600 dpi, bilevel JB2 |
| `render_scaled_0.5x/bilinear` | boy.djvu | 0.5× output | **149 µs** | Built-in bilinear downscale |
| `render_scaled_0.5x/lanczos3` | boy.djvu | 0.5× output | **3.85 ms** | Higher quality separable Lanczos3 |
| `pdf_export_sequential` | watchmaker.djvu | — | **821 ms** | 12 pages, `output_dpi=150`, DCTDecode JPEG-80 |
| `pdf_export_parallel` | watchmaker.djvu | — | — | Not measured in this run |

Note: The `render_colorbook` benchmark renders at 150 dpi (848×1376 output). For sub=4
renders djvu-rs applies a cascade of optimizations: (1) partial BG44 decode (first chunk
only), (2) cached 1/4-res max-pool mask pyramid (single bit lookup per pixel), (3)
bit-shift instead of UDIV for bg/mask coordinate transforms.  Cold render includes
document setup, ZP arithmetic decode for the first BG44 chunk, wavelet, and composite.

### Native render stage breakdown (#281)

Measured as part of the full `cargo bench --workspace --features cli,tiff` run.
These benches are diagnostic: `render_pixmap` is the public allocation-returning
API, `render_into_reuse_buffer` composites into a caller-owned buffer, and
`render_streaming_discard` measures row generation without retaining output.

| Benchmark | Page | Time (Criterion mean) | Notes |
|-----------|------|--------------:|-------|
| `render_native_stages/render_pixmap` | watchmaker color | **71.5 ms** | public `Pixmap` path, warm decode caches |
| `render_native_stages/render_into_reuse_buffer` | watchmaker color | **70.5 ms** | caller-owned RGBA buffer |
| `render_native_stages/render_streaming_discard` | watchmaker color | **70.2 ms** | row streaming, no retained output |
| `render_native_stages/mask_decode` | watchmaker color | **2.74 ms** | JB2 mask decode only |
| `render_native_stages/bg_to_rgb_warm` | watchmaker color | **2.96 ms** | cached IW44 inverse + RGB |
| `render_native_stages/render_pixmap` | cable mixed bilevel | **85.1 ms** | public `Pixmap` path, warm decode caches |
| `render_native_stages/render_into_reuse_buffer` | cable mixed bilevel | **71.6 ms** | caller-owned RGBA buffer |
| `render_native_stages/render_streaming_discard` | cable mixed bilevel | **71.0 ms** | row streaming, no retained output |
| `render_native_stages/mask_decode` | cable mixed bilevel | **427 µs** | JB2 mask decode only |
| `render_native_stages/bg_to_rgb_warm` | cable mixed bilevel | **2.91 ms** | cached IW44 inverse + RGB |

The diagnostic split shows the native-resolution gap is dominated by compositor
sampling and output materialization, not by warm JB2/IW44 decode alone.

---

## Document benchmarks (`cargo bench --bench document`)

Test file: `tests/corpus/pathogenic_bacteria_1896.djvu` (520 pages, 25 MB, bilevel JB2 at 600 dpi)
Text layer: `tests/corpus/watchmaker.djvu` (TXTz present)

| Benchmark | Time (Criterion mean) | Notes |
|-----------|--------------|-------|
| `parse_multipage_520p` | **2.29 ms** | Parse DJVM directory + all page descriptors, 520 pages |
| `iterate_pages_520p` | **1.52 µs** | Read width/height/dpi for all 520 pages (no render) |
| `render_large_doc_first_page` | **10.6 ms** | Render page 1 of 520 at native 600 dpi |
| `render_large_doc_mid_page` | **10.6 ms** | Render page 260 of 520 — dense text, large JB2 |
| `decode_mask_large_600dpi` | **2.53 ms** | Decode JB2 mask only, page 1 |
| `decode_mask_mid_600dpi` | **16.0 ms** | Decode JB2 mask only, page 260 |
| `text_extraction_single_page` | **168 µs** | TXTz parse + plain text output, watchmaker.djvu |

---

## Comparison with DjVuLibre 3.5.29

The benchmark workflow keeps this comparison active:
`.github/workflows/bench.yml` runs `scripts/bench_djvulibre.sh` on the same
machine as Criterion and formats the result with `scripts/djvulibre_compare.py`.
The benchmark dashboard workflow also publishes a DjVuLibre overlay.

Current local run (2026-10-03, macOS arm64, Apple M1 Max, Rust 1.98,
djvu-rs `3e64096`):

- `boy.djvu`: small color IW44 downscale
- `colorbook.djvu`: large color IW44 downscale
- `watchmaker.djvu`: native-resolution color corpus page
- `cable_1973_100133.djvu`: native-resolution bilevel JB2 corpus page

> libdjvulibre C API is render-only with the page already decoded in memory.
> djvu-rs is the warm Criterion `render_pixmap` of the same page.
> `ddjvu` CLI includes process startup and PPM output to `/dev/null`.

| Benchmark | djvu-rs | libdjvulibre C API | ddjvu CLI | Ratio | Ratio 2026-06-18 |
|-----------|--------:|-------------------:|----------:|------:|-----------------:|
| `boy.djvu` @ 72 dpi, small color IW44 | **61.7 µs** | **124 µs** | **33.0 ms** | djvu-rs **2.0x faster** | 1.4x slower |
| `colorbook.djvu` @ 150 dpi, color IW44 | **4.46 ms** | **6.37 ms** | **70.1 ms** | djvu-rs **1.4x faster** | 1.2x slower |
| `watchmaker.djvu` @ 300 dpi, native color corpus | **26.8 ms** | **37.8 ms** | **85.6 ms** | djvu-rs **1.4x faster** | 2.0x slower |
| `cable_1973_100133.djvu` @ 300 dpi, native bilevel JB2 corpus | **22.6 ms** | **36.8 ms** | **76.8 ms** | djvu-rs **1.6x faster** | 2.1x slower |

Cold path: Criterion `render_colorbook_cold` (parse + first render) is
**13.7 ms**; the libdjvulibre harness reports **35.3 ms** open+decode plus
**6.37 ms** render for the same page (41.6 ms). The two are close but not
identical measurements. Stage breakdown (`render_native_stages`): watchmaker
mask decode 2.79 ms, background to RGB 3.04 ms; cable mask decode 0.62 ms.
The libdjvulibre C API harness intentionally avoids upscale cases because
`ddjvu_page_render` can return a zero buffer when the requested output
rectangle is larger than the native page.

### Encode (encoder parity scorecard, re-run 2026-10-06)

`cargo run --release --example encoder_parity_scorecard -- --no-ocr --repeats 5`;
median wall time, see [`docs/encoder-parity.md`](docs/encoder-parity.md).
Re-run after the encoder speed-ups #937 (ZP bit coder inlined in the IW44
passes), #938 (the same in BZZ) and #939 (NEON zigzag scatter of IW44
blocks); `PERF_EXPERIMENTS.md` IW44_ENC_BIT_INLINE, BZZ_ENC_BIT_INLINE,
IW44_ENC_SCATTER_NEON. The previous run, after #933 and #935, had
watchmaker 156.4 ms, goody two-shoes 123.5 ms, map atlas 103.8 ms and cable
7.6 ms. Output sizes are unchanged. The machine was under background load
(load average about 10); each djvu-rs / DjVuLibre pair ran back to back, so
the ratios compare like with like. A second run agreed within 5% on every
case above 100 ms; the table shows the first, lower-ratio run.

| Case | DjVuLibre | djvu-rs | Speed | Size ratio |
|------|----------:|--------:|------:|-----------:|
| watchmaker, IW44 vs `c44` | 473.8 ms | 150.7 ms | djvu-rs **3.1x faster** | 1.025x |
| goody two-shoes, IW44 vs `c44` | 364.7 ms | 111.7 ms | djvu-rs **3.3x faster** | 1.040x |
| cable, JB2 lossless vs `cjb2` | 26.6 ms | 7.0 ms | djvu-rs **3.8x faster** | 1.011x |
| map atlas, JB2 lossless vs `cjb2` | 352.7 ms | 102.0 ms | djvu-rs **3.5x faster** | 0.952x |
| Chinese cookbook, JB2 lossless vs `cjb2` | 23.9 ms | 5.4 ms | djvu-rs **4.4x faster** | 0.985x |

### Summary

| Scenario | Winner | Margin |
|----------|--------|--------|
| Downscaled render (< native DPI), warm | **djvu-rs** | 1.4-2.0x faster |
| Native-resolution corpus render, warm | **djvu-rs** | 1.4-1.6x faster |
| Cold colorbook render | **djvu-rs** | 13.7 ms vs 41.6 ms (not identical measurements) |
| `ddjvu` CLI subprocess baseline | slower than either library call | 33.0-85.6 ms across measured cases |
| Encode (IW44 photo, JB2 lossless) | **djvu-rs** | 3.1-4.4x faster; size 0.952-1.040x |
| Document open / parse | **djvu-rs** | `parse_multipage_520p`: 2.29 ms |

---

## Notes

- JB2 and IW44 pure decode are sub-millisecond to low-millisecond for typical pages.
- Full native-resolution render (2550×3301 px): ~71-75 ms in the corrected
  2026-05-17 local render baseline.
- Corpus benchmarks use public domain files from Internet Archive.
- PDF export baseline for `tests/corpus/watchmaker.djvu` (12 pages, 150 dpi,
  JPEG-80, Apple M1 Max / macOS arm64, Rust 1.92, 2026-05-17):
  `pdf_export_sequential` mean **955 ms**, `pdf_export_parallel` mean
  **154 ms**. Memory probe peak RSS: sequential **76.7 MiB**, parallel
  **228.9 MiB**. See `PERF_EXPERIMENTS.md` entry #298 for commands and
  per-stage byte counts.
- PDF color row streaming (#299, same fixture/platform): sequential
  `pdf_export_sequential` mean **812 ms**; parallel probe peak RSS improved
  from **228.9 MiB** to **169.5 MiB** with unchanged PDF bytes. See
  `PERF_EXPERIMENTS.md` entry #299 for the noisy parallel Criterion runs and
  full command log.
- `render_large_doc_first_page` improved from ~43 ms → 10.4 ms across v0.5.2–v0.5.3:
  - `Pixmap::new` fill changed from per-pixel push to `vec![fill; n]`
  - JB2 symbol dictionary cached via `RwLock<HashMap<usize, Arc<JB2Dict>>>`
  - `decode_bitmap_direct` inner loop: `split_at_mut` eliminates per-pixel multiply

**ZP decoder u32 widening (#180, 2026-04-15):** widening `a`, `c`, `fence` from u16 to u32
eliminates casts in the inner decode loop, enabling better register allocation and removing
the `leading_ones()` u16 truncation in `renormalize`. Results:
- `jb2_decode_corpus_bilevel`: 3.36 ms → 423 µs (**8× faster**)
- `decode_mask_large_600dpi`: 8.43 ms → 2.38 ms (**3.5× faster**)
- `decode_mask_mid_600dpi`: 30.8 ms → 15.0 ms (**2× faster**)
- `render_large_doc_mid_page`: 35.6 ms → 10.8 ms (**3.3× faster**)
